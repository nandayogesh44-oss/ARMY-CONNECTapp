# ARMY CONNECT — Installation, Worldwide Remote Access & Hosting Guide

Zero coding knowledge is needed to run ARMY CONNECT on your own computer/server, connect devices from anywhere in the world across different Wi-Fi and mobile data networks, and build your Android APK.

---

## Option A: Connect Anywhere in the World Right Now (Mobile Browser or Android App)

1. Open the ARMY CONNECT Web Dashboard on your computer and create an account.
2. Click **Pair Device** to show your QR Code and 6-digit Pairing Code.
3. On your Android phone (even if it is on **4G/5G mobile data** or a completely different Wi-Fi network in another city):
   - Open Chrome and visit the **Companion URL** under the QR code (or tap **Pair This Device**), **or** scan the QR code inside the ARMY CONNECT Android app.
4. Click **Approve Device** on your Web Dashboard.
   - No remote commands, WebRTC streams, or file transfers are allowed until you explicitly approve the device.
5. Your phone and computer now communicate over **HTTPS + Encrypted WebSockets (WSS)** and **DTLS-encrypted WebRTC** across any internet connection, and automatically reconnect whenever you switch between Wi-Fi and mobile data.

---

## Option B: Self-Host Worldwide on Your Own Computer or VPS

### 1. Free $0/month Setup on Your Own PC (Zero Port-Forwarding)
1. Install free **Node.js 22+**, unzip `army-connect-complete-source.zip`, and run:
   ```bash
   npm install
   npm run build
   npm start
   ```
2. Expose `http://localhost:3000` over HTTPS with a free **Cloudflare Tunnel** (`cloudflared tunnel --url http://localhost:3000`) or **Tailscale Funnel**.
3. Set `APP_URL` to your `https://...` tunnel URL so QR codes work from mobile data anywhere in the world.

### 2. Always-On 24/7 Self-Hosted Server with Automatic HTTPS + Coturn TURN (Docker)
Included in this project are `Dockerfile`, `docker-compose.yml`, `Caddyfile`, and `coturn/turnserver.conf`:
1. Point your domain (e.g. `connect.yourdomain.com`) to a Linux server with Docker installed.
2. Copy `.env.example` to `.env`, set `ARMY_DOMAIN=connect.yourdomain.com`, `JWT_SECRET`, and `TURN_SHARED_SECRET`.
3. Run:
   ```bash
   docker compose up -d
   ```
   Caddy automatically issues a free **Let's Encrypt HTTPS/WSS certificate**, and **Coturn** provides your own private STUN + TURN relay for strict cellular carrier NATs.

---

## Hosting & TURN Server Cost Breakdown

- **ARMY CONNECT Software**: **$0** (100% self-hosted, no subscriptions, no third-party cloud lock-in).
- **STUN Servers (Google & Cloudflare)**: **$0/month** (free public STUN resolves ~80–85% of Wi-Fi & home ISP connections directly P2P).
- **WSS + HTTPS Encrypted Relay**: **$0/month** on your own PC via Cloudflare Tunnel / Tailscale Funnel, or included in any VPS.
- **Self-Hosted VPS + Private Coturn TURN Server** *(optional, only needed for 24/7 uptime without leaving your home PC on, or strict corporate/mobile CGNAT where P2P UDP is blocked)*:
  - **Oracle Cloud Always Free ARM VM**: **$0/month** (free tier includes generous bandwidth).
  - **Standard Entry VPS (Hetzner / DigitalOcean / Linode / Vultr)**: **~$4–$6/month** (1 vCPU, 1–2 GB RAM runs Node.js + Caddy HTTPS + Coturn TURN effortlessly).
  - **Managed TURN Providers** *(if you prefer not running Coturn yourself)*: Metered.ca / Cloudflare Calls / Twilio typically offer **free starter quotas (5–50 GB/month)**, then ~$0.40–$1.00 per GB only when traffic cannot go direct P2P and falls back to TURN video relay.

---

## Option C: Build Installable Android Debug & Release APKs (Zero Coding)

1. Download `army-connect-complete-source.zip` from the **Security & APK** tab or homepage.
2. Upload the unzipped project to a free GitHub repository and run the **Build ARMY CONNECT Android APKs** workflow under the **Actions** tab (~3 minutes).
3. Download `ArmyConnect-debug.apk` or `ArmyConnect.apk` from the workflow artifacts and install it on your Android phone.
