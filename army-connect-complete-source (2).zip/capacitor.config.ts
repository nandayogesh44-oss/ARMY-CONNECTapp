import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.armyconnect.app',
  appName: 'ARMY CONNECT',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: true,
  },
  android: {
    path: 'android',
    allowMixedContent: true,
    backgroundColor: '#090B09',
  },
};

export default config;
