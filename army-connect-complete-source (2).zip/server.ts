import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { ZipArchive } from 'archiver';
import dotenv from 'dotenv';
import express from 'express';
import multer from 'multer';
import QRCode from 'qrcode';
import { createServer as createViteServer } from 'vite';
import {
  type AuthedRequest,
  hashSecret,
  requireAuth,
  signUserToken,
  verifySecret,
} from './server/auth.ts';
import {
  DEFAULT_PERMISSIONS,
  DOWNLOADS_DIR,
  UPLOADS_DIR,
  db,
  logConnectionEvent,
} from './server/db.ts';
import { WsHub } from './server/wsHub.ts';
import { DEFAULT_PUBLIC_STUN_URLS, buildIceConfigForUser } from './server/webrtc.ts';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '25mb' }));
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, x-device-token');
  }
  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }
  next();
});

const server = http.createServer(app);
const wsHub = new WsHub(server);

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, _file, cb) => {
      const deviceId = String(req.params.id || 'shared').replace(/[^a-zA-Z0-9_-]/g, '');
      const dest = path.join(UPLOADS_DIR, deviceId);
      fs.mkdirSync(dest, { recursive: true });
      cb(null, dest);
    },
    filename: (_req, file, cb) => {
      const safeName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
      cb(null, `${Date.now()}_${crypto.randomBytes(4).toString('hex')}_${safeName}`);
    },
  }),
  limits: { fileSize: 250 * 1024 * 1024 },
});

function categorizeMime(mime: string, name: string): string {
  const lower = name.toLowerCase();
  if (mime.startsWith('image/') || /\.(jpg|jpeg|png|gif|webp|heic|bmp)$/.test(lower)) return 'photo';
  if (mime.startsWith('video/') || /\.(mp4|mkv|webm|mov|avi|3gp)$/.test(lower)) return 'video';
  if (mime.startsWith('audio/') || /\.(mp3|wav|ogg|m4a|flac|aac)$/.test(lower)) return 'audio';
  return 'document';
}

function getBaseUrl(req: express.Request): string {
  if (process.env.APP_URL && process.env.APP_URL !== 'MY_APP_URL') {
    return process.env.APP_URL.replace(/\/$/, '');
  }
  const proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'http';
  const host = (req.headers['x-forwarded-host'] as string) || req.get('host') || `localhost:${PORT}`;
  return `${proto}://${host}`;
}

function getDeviceForUser(deviceId: string, userId: string) {
  return db
    .prepare('SELECT * FROM devices WHERE id = ? AND user_id = ?')
    .get(deviceId, userId) as Record<string, unknown> | undefined;
}

function getDeviceByToken(req: express.Request) {
  const header = req.headers['x-device-token'];
  const token = typeof header === 'string' ? header : '';
  if (!token) return undefined;
  return db.prepare('SELECT * FROM devices WHERE device_token = ?').get(token) as
    | Record<string, unknown>
    | undefined;
}

function getApprovedDeviceByToken(
  req: express.Request,
  res: express.Response
): Record<string, unknown> | undefined {
  const device = getDeviceByToken(req);
  if (!device) {
    res.status(401).json({ error: 'Invalid device token' });
    return undefined;
  }
  if (!device.approved) {
    res.status(403).json({ error: 'Device awaits explicit approval on the Web Dashboard' });
    return undefined;
  }
  return device;
}

// ---------- HEALTH ----------
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'ARMY CONNECT', timestamp: Date.now() });
});

// ---------- AUTH & SESSIONS ----------
app.post('/api/auth/register', (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const name = String(req.body?.name || '').trim();
  const password = String(req.body?.password || '');
  const pin = req.body?.pin ? String(req.body.pin).trim() : '';

  if (!email || !name || password.length < 6) {
    res.status(400).json({ error: 'Name, valid email, and password (6+ chars) are required.' });
    return;
  }

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    res.status(409).json({ error: 'An account with this email already exists.' });
    return;
  }

  const userId = crypto.randomUUID();
  const now = Date.now();
  const pinHash = pin && /^\d{4,6}$/.test(pin) ? hashSecret(pin) : null;

  db.prepare(
    'INSERT INTO users (id, email, name, password_hash, pin_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(userId, email, name, hashSecret(password), pinHash, now);

  db.prepare('INSERT INTO server_settings (user_id) VALUES (?)').run(userId);

  const sessionId = crypto.randomUUID();
  const ttlHours = 168;
  const expiresAt = now + ttlHours * 3600 * 1000;
  db.prepare(
    'INSERT INTO sessions (id, user_id, label, ip_address, user_agent, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(
    sessionId,
    userId,
    'Web Dashboard',
    req.ip || '',
    String(req.headers['user-agent'] || '').slice(0, 180),
    now,
    expiresAt
  );

  const token = signUserToken({ userId, email, sessionId }, ttlHours);
  res.status(201).json({
    token,
    sessionId,
    user: { id: userId, email, name, hasPin: Boolean(pinHash) },
  });
});

app.post('/api/auth/login', (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const label = String(req.body?.label || 'Web Browser');

  const user = db
    .prepare('SELECT id, email, name, password_hash, pin_hash FROM users WHERE email = ?')
    .get(email) as
    | { id: string; email: string; name: string; password_hash: string; pin_hash: string | null }
    | undefined;

  if (!user || !verifySecret(password, user.password_hash)) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  const settings = db
    .prepare('SELECT session_ttl_hours FROM server_settings WHERE user_id = ?')
    .get(user.id) as { session_ttl_hours: number } | undefined;
  const ttlHours = settings?.session_ttl_hours || 168;

  const sessionId = crypto.randomUUID();
  const now = Date.now();
  const expiresAt = now + ttlHours * 3600 * 1000;

  db.prepare(
    'INSERT INTO sessions (id, user_id, label, ip_address, user_agent, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(
    sessionId,
    user.id,
    label,
    req.ip || '',
    String(req.headers['user-agent'] || '').slice(0, 180),
    now,
    expiresAt
  );

  const token = signUserToken({ userId: user.id, email: user.email, sessionId }, ttlHours);
  res.json({
    token,
    sessionId,
    user: { id: user.id, email: user.email, name: user.name, hasPin: Boolean(user.pin_hash) },
  });
});

app.post('/api/auth/logout', requireAuth, (req: AuthedRequest, res) => {
  db.prepare('UPDATE sessions SET revoked_at = ? WHERE id = ? AND user_id = ?').run(
    Date.now(),
    req.auth!.sessionId,
    req.auth!.userId
  );
  wsHub.revokeUserSession(req.auth!.sessionId);
  res.json({ ok: true });
});

app.get('/api/auth/me', requireAuth, (req: AuthedRequest, res) => {
  const user = db
    .prepare('SELECT id, email, name, pin_hash, created_at FROM users WHERE id = ?')
    .get(req.auth!.userId) as
    | { id: string; email: string; name: string; pin_hash: string | null; created_at: number }
    | undefined;
  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }
  res.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      hasPin: Boolean(user.pin_hash),
      createdAt: user.created_at,
    },
    sessionId: req.auth!.sessionId,
  });
});

app.post('/api/auth/pin/set', requireAuth, (req: AuthedRequest, res) => {
  const pin = String(req.body?.pin || '').trim();
  if (!/^\d{4,6}$/.test(pin)) {
    res.status(400).json({ error: 'Security PIN must be 4 to 6 digits.' });
    return;
  }
  db.prepare('UPDATE users SET pin_hash = ? WHERE id = ?').run(hashSecret(pin), req.auth!.userId);
  res.json({ ok: true, hasPin: true });
});

app.post('/api/auth/pin/verify', requireAuth, (req: AuthedRequest, res) => {
  const pin = String(req.body?.pin || '').trim();
  const user = db.prepare('SELECT pin_hash FROM users WHERE id = ?').get(req.auth!.userId) as
    | { pin_hash: string | null }
    | undefined;
  if (!user?.pin_hash) {
    res.json({ ok: true, required: false });
    return;
  }
  if (!verifySecret(pin, user.pin_hash)) {
    res.status(403).json({ error: 'Incorrect Security PIN.' });
    return;
  }
  res.json({ ok: true });
});

app.get('/api/auth/sessions', requireAuth, (req: AuthedRequest, res) => {
  const rows = db
    .prepare(
      'SELECT id, label, ip_address, user_agent, created_at, expires_at, revoked_at FROM sessions WHERE user_id = ? ORDER BY created_at DESC LIMIT 30'
    )
    .all(req.auth!.userId);
  res.json({ sessions: rows, currentSessionId: req.auth!.sessionId });
});

app.delete('/api/auth/sessions/:sessionId', requireAuth, (req: AuthedRequest, res) => {
  const targetId = String(req.params.sessionId);
  db.prepare('UPDATE sessions SET revoked_at = ? WHERE id = ? AND user_id = ?').run(
    Date.now(),
    targetId,
    req.auth!.userId
  );
  wsHub.revokeUserSession(targetId);
  res.json({ ok: true });
});

// ---------- QR PAIRING & DEVICE ENROLLMENT ----------
app.post('/api/pairing/create', requireAuth, async (req: AuthedRequest, res) => {
  const now = Date.now();
  const expiresAt = now + 10 * 60 * 1000;
  const code = String(crypto.randomInt(100000, 999999));
  const token = crypto.randomBytes(24).toString('hex');

  db.prepare(
    'INSERT INTO pairing_tokens (code, token, user_id, created_at, expires_at) VALUES (?, ?, ?, ?, ?)'
  ).run(code, token, req.auth!.userId, now, expiresAt);

  const serverUrl = getBaseUrl(req);
  const payload = JSON.stringify({
    app: 'ARMY_CONNECT',
    version: 1,
    serverUrl,
    code,
    token,
  });

  const qrDataUrl = await QRCode.toDataURL(payload, {
    width: 320,
    margin: 2,
    color: { dark: '#0B120C', light: '#F4F6F3' },
  });

  res.json({
    code,
    token,
    serverUrl,
    companionUrl: `${serverUrl}/?pair=${encodeURIComponent(code)}`,
    qrDataUrl,
    expiresAt,
  });
});

app.post('/api/pairing/claim', (req, res) => {
  const code = String(req.body?.code || '').trim();
  const token = String(req.body?.token || '').trim();
  const deviceName = String(req.body?.name || 'Android Device').trim();
  const manufacturer = String(req.body?.manufacturer || 'Android');
  const model = String(req.body?.model || 'Handheld');
  const androidVersion = String(req.body?.androidVersion || '16');
  const apiLevel = Number(req.body?.apiLevel || 36);
  const existingDeviceId = req.body?.deviceId ? String(req.body.deviceId) : null;

  const pairing = (
    token
      ? db.prepare('SELECT * FROM pairing_tokens WHERE token = ?').get(token)
      : db.prepare('SELECT * FROM pairing_tokens WHERE code = ?').get(code)
  ) as
    | { code: string; token: string; user_id: string; expires_at: number; claimed_device_id: string | null }
    | undefined;

  if (!pairing) {
    res.status(404).json({ error: 'Invalid pairing code or QR token.' });
    return;
  }
  if (pairing.expires_at < Date.now()) {
    res.status(410).json({ error: 'Pairing code expired. Generate a new QR code on your dashboard.' });
    return;
  }

  const settings = db
    .prepare('SELECT require_device_approval FROM server_settings WHERE user_id = ?')
    .get(pairing.user_id) as { require_device_approval: number } | undefined;

  const needsApproval = settings ? Boolean(settings.require_device_approval) : true;
  const deviceId = existingDeviceId || crypto.randomUUID();
  const deviceToken = crypto.randomBytes(32).toString('hex');
  const fingerprint = crypto
    .createHash('sha256')
    .update(`${deviceId}:${deviceToken}`)
    .digest('hex')
    .slice(0, 16)
    .toUpperCase()
    .match(/.{1,4}/g)!
    .join('-');
  const now = Date.now();

  const existing = db
    .prepare('SELECT id FROM devices WHERE id = ? AND user_id = ?')
    .get(deviceId, pairing.user_id);

  if (existing) {
    db.prepare(
      'UPDATE devices SET name = ?, manufacturer = ?, model = ?, android_version = ?, api_level = ?, device_token = ?, approved = ?, last_seen = ?, e2ee_fingerprint = ? WHERE id = ?'
    ).run(
      deviceName,
      manufacturer,
      model,
      androidVersion,
      apiLevel,
      deviceToken,
      needsApproval ? 0 : 1,
      now,
      fingerprint,
      deviceId
    );
  } else {
    db.prepare(`
      INSERT INTO devices (
        id, user_id, name, manufacturer, model, android_version, api_level,
        device_token, approved, online, last_seen, permissions_json,
        e2ee_enabled, e2ee_fingerprint, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, 1, ?, ?)
    `).run(
      deviceId,
      pairing.user_id,
      deviceName,
      manufacturer,
      model,
      androidVersion,
      apiLevel,
      deviceToken,
      needsApproval ? 0 : 1,
      now,
      JSON.stringify(DEFAULT_PERMISSIONS),
      fingerprint,
      now
    );
  }

  db.prepare('UPDATE pairing_tokens SET claimed_device_id = ? WHERE code = ?').run(deviceId, pairing.code);

  logConnectionEvent({
    id: crypto.randomUUID(),
    userId: pairing.user_id,
    deviceId,
    deviceName,
    event: needsApproval ? 'pairing_requested' : 'paired',
    ipAddress: req.ip || '',
    details: needsApproval ? 'Waiting for dashboard approval' : 'Paired via QR code',
  });

  wsHub.broadcastToUser(pairing.user_id, {
    type: 'device:paired',
    device: {
      id: deviceId,
      name: deviceName,
      manufacturer,
      model,
      androidVersion,
      approved: !needsApproval,
      e2eeFingerprint: fingerprint,
    },
  });

  res.json({
    deviceId,
    deviceToken,
    approved: !needsApproval,
    e2eeFingerprint: fingerprint,
    serverUrl: getBaseUrl(req),
  });
});

// ---------- DEVICES & TELEMETRY ----------
app.get('/api/devices', requireAuth, (req: AuthedRequest, res) => {
  const rows = db
    .prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY last_seen DESC')
    .all(req.auth!.userId) as Array<Record<string, unknown>>;

  const devices = rows.map((d) => ({
    ...d,
    device_token: undefined,
    approved: Boolean(d.approved),
    online: wsHub.isDeviceOnline(String(d.id)),
    is_charging: Boolean(d.is_charging),
    e2ee_enabled: Boolean(d.e2ee_enabled),
    permissions: JSON.parse(String(d.permissions_json || '{}')),
  }));
  res.json({ devices });
});

app.post('/api/devices/:id/approve', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) {
    res.status(404).json({ error: 'Device not found' });
    return;
  }
  db.prepare('UPDATE devices SET approved = 1 WHERE id = ?').run(device.id);
  logConnectionEvent({
    id: crypto.randomUUID(),
    userId: req.auth!.userId,
    deviceId: String(device.id),
    deviceName: String(device.name),
    event: 'approved',
    ipAddress: req.ip || '',
    details: 'Device approved by account owner',
  });
  wsHub.approveDevice(String(device.id));
  wsHub.broadcastToUser(req.auth!.userId, { type: 'device:status', deviceId: device.id, approved: true });
  res.json({ ok: true });
});

app.post('/api/devices/:id/reject', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) {
    res.status(404).json({ error: 'Device not found' });
    return;
  }
  wsHub.disconnectDevice(String(device.id), 'Pairing rejected by owner');
  logConnectionEvent({
    id: crypto.randomUUID(),
    userId: req.auth!.userId,
    deviceId: String(device.id),
    deviceName: String(device.name),
    event: 'rejected',
    ipAddress: req.ip || '',
    details: 'Pairing rejected and device removed',
  });
  db.prepare('DELETE FROM devices WHERE id = ?').run(device.id);
  res.json({ ok: true });
});

app.post('/api/devices/:id/disconnect', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) {
    res.status(404).json({ error: 'Device not found' });
    return;
  }
  wsHub.disconnectDevice(String(device.id), 'Securely disconnected from dashboard');
  logConnectionEvent({
    id: crypto.randomUUID(),
    userId: req.auth!.userId,
    deviceId: String(device.id),
    deviceName: String(device.name),
    event: 'remote_disconnect',
    ipAddress: req.ip || '',
    details: 'Remote session terminated from dashboard',
  });
  wsHub.broadcastToUser(req.auth!.userId, {
    type: 'device:status',
    deviceId: device.id,
    online: false,
    lastSeen: Date.now(),
  });
  res.json({ ok: true });
});

app.delete('/api/devices/:id', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) {
    res.status(404).json({ error: 'Device not found' });
    return;
  }
  wsHub.disconnectDevice(String(device.id), 'Device unpaired');
  db.prepare('DELETE FROM devices WHERE id = ?').run(device.id);
  logConnectionEvent({
    id: crypto.randomUUID(),
    userId: req.auth!.userId,
    deviceId: null,
    deviceName: String(device.name),
    event: 'unpaired',
    ipAddress: req.ip || '',
    details: 'Device permanently unpaired',
  });
  res.json({ ok: true });
});

app.patch('/api/devices/:id/permissions', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) {
    res.status(404).json({ error: 'Device not found' });
    return;
  }
  const current = JSON.parse(String(device.permissions_json || '{}'));
  const updated = { ...DEFAULT_PERMISSIONS, ...current, ...(req.body?.permissions || {}) };
  db.prepare('UPDATE devices SET permissions_json = ? WHERE id = ?').run(
    JSON.stringify(updated),
    device.id
  );
  wsHub.sendToDevice(String(device.id), { type: 'permissions:updated', permissions: updated });
  res.json({ permissions: updated });
});

app.post('/api/devices/:id/command', requireAuth, async (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) {
    res.status(404).json({ error: 'Device not found' });
    return;
  }
  if (!device.approved) {
    res.status(403).json({ error: 'Device has not been approved yet.' });
    return;
  }
  const command = String(req.body?.command || '');
  const payload = (req.body?.payload || {}) as Record<string, unknown>;
  if (!command) {
    res.status(400).json({ error: 'Command name required' });
    return;
  }

  try {
    const result = await wsHub.sendCommand(String(device.id), command, payload);
    res.json({ ok: true, result });
  } catch (err) {
    res.status(503).json({
      error: err instanceof Error ? err.message : 'Unable to reach device',
    });
  }
});

app.post('/api/devices/:id/ping', requireAuth, async (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) {
    res.status(404).json({ error: 'Device not found' });
    return;
  }
  if (!device.approved) {
    res.status(403).json({ error: 'Device has not been approved yet.' });
    return;
  }
  const started = performance.now();
  try {
    const result = (await wsHub.sendCommand(
      String(device.id),
      'device:ping',
      { sentAt: Date.now() },
      5000
    )) as Record<string, unknown> | undefined;
    const serverToDeviceMs = Math.max(1, Math.round(performance.now() - started));
    res.json({
      ok: true,
      serverToDeviceMs,
      pongAt: typeof result?.pongAt === 'number' ? result.pongAt : Date.now(),
      checkedAt: Date.now(),
    });
  } catch (err) {
    res.status(503).json({
      error: err instanceof Error ? err.message : 'Device is offline or timed out',
    });
  }
});

app.post('/api/device/telemetry', (req, res) => {
  const device = getApprovedDeviceByToken(req, res);
  if (!device) return;
  const p = req.body || {};
  db.prepare(`
    UPDATE devices SET
      last_seen = ?,
      battery_level = COALESCE(?, battery_level),
      is_charging = COALESCE(?, is_charging),
      storage_used = COALESCE(?, storage_used),
      storage_total = COALESCE(?, storage_total),
      wifi_ssid = COALESCE(?, wifi_ssid),
      network_type = COALESCE(?, network_type),
      latitude = COALESCE(?, latitude),
      longitude = COALESCE(?, longitude),
      location_accuracy = COALESCE(?, location_accuracy),
      location_updated_at = CASE WHEN ? IS NOT NULL THEN ? ELSE location_updated_at END
    WHERE id = ?
  `).run(
    Date.now(),
    typeof p.batteryLevel === 'number' ? p.batteryLevel : null,
    typeof p.isCharging === 'boolean' ? (p.isCharging ? 1 : 0) : null,
    typeof p.storageUsed === 'number' ? p.storageUsed : null,
    typeof p.storageTotal === 'number' ? p.storageTotal : null,
    typeof p.wifiSsid === 'string' ? p.wifiSsid : null,
    typeof p.networkType === 'string' ? p.networkType : null,
    typeof p.latitude === 'number' ? p.latitude : null,
    typeof p.longitude === 'number' ? p.longitude : null,
    typeof p.locationAccuracy === 'number' ? p.locationAccuracy : null,
    typeof p.latitude === 'number' ? Date.now() : null,
    Date.now(),
    device.id
  );
  res.json({ ok: true });
});

app.get('/api/history', requireAuth, (req: AuthedRequest, res) => {
  const rows = db
    .prepare('SELECT * FROM connection_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 100')
    .all(req.auth!.userId);
  res.json({ history: rows });
});

// ---------- FILES & MEDIA VAULT ----------
app.get('/api/devices/:id/files', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) {
    res.status(404).json({ error: 'Device not found' });
    return;
  }
  const category = req.query.category ? String(req.query.category) : '';
  const folder = req.query.folder ? String(req.query.folder) : '';

  let rows;
  if (category && category !== 'all') {
    rows = db
      .prepare('SELECT * FROM device_files WHERE device_id = ? AND category = ? ORDER BY updated_at DESC')
      .all(device.id, category);
  } else if (folder) {
    rows = db
      .prepare('SELECT * FROM device_files WHERE device_id = ? AND folder = ? ORDER BY is_directory DESC, name ASC')
      .all(device.id, folder);
  } else {
    rows = db
      .prepare('SELECT * FROM device_files WHERE device_id = ? ORDER BY is_directory DESC, updated_at DESC')
      .all(device.id);
  }
  res.json({ files: rows });
});

app.post(
  '/api/devices/:id/files/upload',
  requireAuth,
  upload.single('file'),
  (req: AuthedRequest, res) => {
    const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
    if (!device) {
      res.status(404).json({ error: 'Device not found' });
      return;
    }
    if (!req.file) {
      res.status(400).json({ error: 'No file attached' });
      return;
    }

    const folder = String(req.body?.folder || '/Transfers');
    const now = Date.now();
    const id = crypto.randomUUID();
    const category = categorizeMime(req.file.mimetype, req.file.originalname);
    const fullPath = `${folder.replace(/\/$/, '')}/${req.file.originalname}`;

    db.prepare(`
      INSERT INTO device_files (id, device_id, user_id, folder, name, path, size, mime_type, category, stored_filename, is_directory, source, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'vault', ?, ?)
    `).run(
      id,
      device.id,
      req.auth!.userId,
      folder,
      req.file.originalname,
      fullPath,
      req.file.size,
      req.file.mimetype,
      category,
      req.file.filename,
      now,
      now
    );

    const record = db.prepare('SELECT * FROM device_files WHERE id = ?').get(id);
    wsHub.sendToDevice(String(device.id), {
      type: 'file:incoming',
      file: record,
      downloadUrl: `${getBaseUrl(req)}/api/device/files/${id}/download`,
    });
    wsHub.broadcastToUser(req.auth!.userId, { type: 'file:added', deviceId: device.id, file: record });
    res.status(201).json({ file: record });
  }
);

app.post('/api/device/files/upload', upload.single('file'), (req, res) => {
  const device = getApprovedDeviceByToken(req, res);
  if (!device) return;
  if (!req.file) {
    res.status(400).json({ error: 'No file attached' });
    return;
  }

  const targetDir = path.join(UPLOADS_DIR, String(device.id));
  fs.mkdirSync(targetDir, { recursive: true });
  const finalPath = path.join(targetDir, req.file.filename);
  if (req.file.path !== finalPath) {
    fs.renameSync(req.file.path, finalPath);
  }

  const folder = String(req.body?.folder || '/PhoneUploads');
  const now = Date.now();
  const id = crypto.randomUUID();
  const category = categorizeMime(req.file.mimetype, req.file.originalname);

  db.prepare(`
    INSERT INTO device_files (id, device_id, user_id, folder, name, path, size, mime_type, category, stored_filename, is_directory, source, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'device', ?, ?)
  `).run(
    id,
    device.id,
    device.user_id,
    folder,
    req.file.originalname,
    `${folder.replace(/\/$/, '')}/${req.file.originalname}`,
    req.file.size,
    req.file.mimetype,
    category,
    req.file.filename,
    now,
    now
  );

  const record = db.prepare('SELECT * FROM device_files WHERE id = ?').get(id);
  wsHub.broadcastToUser(String(device.user_id), { type: 'file:added', deviceId: device.id, file: record });
  res.status(201).json({ file: record });
});

app.get('/api/devices/:id/files/:fileId/download', requireAuth, (req: AuthedRequest, res) => {
  const file = db
    .prepare('SELECT * FROM device_files WHERE id = ? AND device_id = ? AND user_id = ?')
    .get(String(req.params.fileId), String(req.params.id), req.auth!.userId) as
    | Record<string, unknown>
    | undefined;

  if (!file || !file.stored_filename) {
    res.status(404).json({ error: 'File not found in transfer storage' });
    return;
  }

  const diskPath = path.join(UPLOADS_DIR, String(file.device_id), String(file.stored_filename));
  if (!fs.existsSync(diskPath)) {
    res.status(404).json({ error: 'File missing on disk' });
    return;
  }

  const inline = req.query.inline === '1';
  res.setHeader('Content-Type', String(file.mime_type || 'application/octet-stream'));
  res.setHeader(
    'Content-Disposition',
    `${inline ? 'inline' : 'attachment'}; filename="${encodeURIComponent(String(file.name))}"`
  );
  fs.createReadStream(diskPath).pipe(res);
});

app.get('/api/device/files', (req, res) => {
  const device = getApprovedDeviceByToken(req, res);
  if (!device) return;
  const files = db
    .prepare(
      'SELECT id, name, folder, size, mime_type AS mimeType, source, created_at AS createdAt FROM device_files WHERE device_id = ? AND stored_filename IS NOT NULL ORDER BY created_at DESC LIMIT 100'
    )
    .all(device.id);
  res.json({ files });
});

app.get('/api/device/files/:fileId/download', (req, res) => {
  const device = getApprovedDeviceByToken(req, res);
  if (!device) return;
  const file = db
    .prepare('SELECT * FROM device_files WHERE id = ? AND device_id = ?')
    .get(String(req.params.fileId), device.id) as Record<string, unknown> | undefined;
  if (!file || !file.stored_filename) {
    res.status(404).json({ error: 'File not found' });
    return;
  }
  const diskPath = path.join(UPLOADS_DIR, String(file.device_id), String(file.stored_filename));
  if (!fs.existsSync(diskPath)) {
    res.status(404).json({ error: 'File missing on disk' });
    return;
  }
  res.download(diskPath, String(file.name));
});

app.delete('/api/devices/:id/files/:fileId', requireAuth, (req: AuthedRequest, res) => {
  const file = db
    .prepare('SELECT * FROM device_files WHERE id = ? AND device_id = ? AND user_id = ?')
    .get(String(req.params.fileId), String(req.params.id), req.auth!.userId) as
    | Record<string, unknown>
    | undefined;
  if (!file) {
    res.status(404).json({ error: 'File not found' });
    return;
  }
  if (file.stored_filename) {
    const diskPath = path.join(UPLOADS_DIR, String(file.device_id), String(file.stored_filename));
    if (fs.existsSync(diskPath)) fs.unlinkSync(diskPath);
  }
  db.prepare('DELETE FROM device_files WHERE id = ?').run(file.id);
  res.json({ ok: true });
});

app.post('/api/device/files/sync', (req, res) => {
  const device = getApprovedDeviceByToken(req, res);
  if (!device) return;
  const entries = Array.isArray(req.body?.entries) ? req.body.entries : [];
  const stmt = db.prepare(`
    INSERT OR REPLACE INTO device_files
    (id, device_id, user_id, folder, name, path, size, mime_type, category, stored_filename, is_directory, source, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, 'device_index', ?, ?)
  `);
  const tx = db.transaction((items: Array<Record<string, unknown>>) => {
    const now = Date.now();
    for (const item of items) {
      const name = String(item.name || 'Unnamed');
      const filePath = String(item.path || `/${name}`);
      const folder = String(item.folder || path.posix.dirname(filePath) || '/');
      const mime = String(item.mimeType || 'application/octet-stream');
      const id = crypto
        .createHash('sha1')
        .update(`${device.id}:${filePath}`)
        .digest('hex');
      stmt.run(
        id,
        device.id,
        device.user_id,
        folder,
        name,
        filePath,
        Number(item.size || 0),
        mime,
        categorizeMime(mime, name),
        item.isDirectory ? 1 : 0,
        now,
        Number(item.updatedAt || now)
      );
    }
  });
  tx(entries);
  res.json({ ok: true, count: entries.length });
});

// ---------- CONTACTS, SMS, CALLS, NOTIFICATIONS ----------
app.get('/api/devices/:id/contacts', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) return res.status(404).json({ error: 'Device not found' });
  const contacts = db
    .prepare('SELECT * FROM device_contacts WHERE device_id = ? ORDER BY name ASC')
    .all(device.id);
  res.json({ contacts });
});

app.post('/api/devices/:id/contacts', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) return res.status(404).json({ error: 'Device not found' });
  const name = String(req.body?.name || '').trim();
  const phone = String(req.body?.phone || '').trim();
  if (!name || !phone) return res.status(400).json({ error: 'Name and phone are required' });

  const id = crypto.randomUUID();
  db.prepare(
    'INSERT INTO device_contacts (id, device_id, name, phone, email, organization, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(id, device.id, name, phone, String(req.body?.email || ''), String(req.body?.organization || ''), Date.now());
  wsHub.sendToDevice(String(device.id), { type: 'contacts:upsert', contact: { id, name, phone } });
  const contact = db.prepare('SELECT * FROM device_contacts WHERE id = ?').get(id);
  res.status(201).json({ contact });
});

app.delete('/api/devices/:id/contacts/:contactId', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) return res.status(404).json({ error: 'Device not found' });
  db.prepare('DELETE FROM device_contacts WHERE id = ? AND device_id = ?').run(
    String(req.params.contactId),
    device.id
  );
  res.json({ ok: true });
});

app.post('/api/device/contacts/sync', (req, res) => {
  const device = getApprovedDeviceByToken(req, res);
  if (!device) return;
  const list = Array.isArray(req.body?.contacts) ? req.body.contacts : [];
  const stmt = db.prepare(
    'INSERT OR REPLACE INTO device_contacts (id, device_id, name, phone, email, organization, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  );
  const tx = db.transaction((items: Array<Record<string, unknown>>) => {
    const now = Date.now();
    for (const c of items) {
      const id = String(c.id || crypto.createHash('sha1').update(`${device.id}:${c.phone}`).digest('hex'));
      stmt.run(
        id,
        device.id,
        String(c.name || 'Unknown'),
        String(c.phone || ''),
        String(c.email || ''),
        String(c.organization || ''),
        now
      );
    }
  });
  tx(list);
  res.json({ ok: true, count: list.length });
});

app.get('/api/devices/:id/sms', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) return res.status(404).json({ error: 'Device not found' });
  const messages = db
    .prepare('SELECT * FROM device_messages WHERE device_id = ? ORDER BY timestamp DESC LIMIT 300')
    .all(device.id);
  res.json({ messages });
});

app.post('/api/devices/:id/sms/send', requireAuth, async (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) return res.status(404).json({ error: 'Device not found' });
  const address = String(req.body?.address || '').trim();
  const body = String(req.body?.body || '').trim();
  if (!address || !body) return res.status(400).json({ error: 'Recipient number and message body are required' });

  const id = crypto.randomUUID();
  const now = Date.now();
  let status = 'queued';
  if (wsHub.isDeviceOnline(String(device.id))) {
    try {
      await wsHub.sendCommand(String(device.id), 'sms:send', { address, body });
      status = 'sent';
    } catch {
      status = 'pending_device';
    }
  }
  db.prepare(
    'INSERT INTO device_messages (id, device_id, address, contact_name, body, direction, status, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(id, device.id, address, String(req.body?.contactName || address), body, 'outgoing', status, now);

  const msg = db.prepare('SELECT * FROM device_messages WHERE id = ?').get(id);
  res.status(201).json({ message: msg });
});

app.post('/api/device/sms/sync', (req, res) => {
  const device = getApprovedDeviceByToken(req, res);
  if (!device) return;
  const list = Array.isArray(req.body?.messages) ? req.body.messages : [];
  const stmt = db.prepare(
    'INSERT OR REPLACE INTO device_messages (id, device_id, address, contact_name, body, direction, status, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  );
  const tx = db.transaction((items: Array<Record<string, unknown>>) => {
    for (const m of items) {
      const id = String(m.id || crypto.randomUUID());
      stmt.run(
        id,
        device.id,
        String(m.address || ''),
        String(m.contactName || ''),
        String(m.body || ''),
        String(m.direction || 'incoming'),
        String(m.status || 'received'),
        Number(m.timestamp || Date.now())
      );
    }
  });
  tx(list);
  res.json({ ok: true, count: list.length });
});

app.get('/api/devices/:id/calls', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) return res.status(404).json({ error: 'Device not found' });
  const calls = db
    .prepare('SELECT * FROM device_calls WHERE device_id = ? ORDER BY timestamp DESC LIMIT 200')
    .all(device.id);
  res.json({ calls });
});

app.post('/api/device/calls/sync', (req, res) => {
  const device = getApprovedDeviceByToken(req, res);
  if (!device) return;
  const list = Array.isArray(req.body?.calls) ? req.body.calls : [];
  const stmt = db.prepare(
    'INSERT OR REPLACE INTO device_calls (id, device_id, number, contact_name, call_type, duration_sec, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)'
  );
  const tx = db.transaction((items: Array<Record<string, unknown>>) => {
    for (const c of items) {
      stmt.run(
        String(c.id || crypto.randomUUID()),
        device.id,
        String(c.number || ''),
        String(c.contactName || ''),
        String(c.callType || 'incoming'),
        Number(c.durationSec || 0),
        Number(c.timestamp || Date.now())
      );
    }
  });
  tx(list);
  res.json({ ok: true, count: list.length });
});

app.get('/api/devices/:id/notifications', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) return res.status(404).json({ error: 'Device not found' });
  const notifications = db
    .prepare(
      'SELECT * FROM device_notifications WHERE device_id = ? AND dismissed = 0 ORDER BY timestamp DESC LIMIT 100'
    )
    .all(device.id);
  res.json({ notifications });
});

app.delete('/api/devices/:id/notifications/:notifId', requireAuth, (req: AuthedRequest, res) => {
  const device = getDeviceForUser(String(req.params.id), req.auth!.userId);
  if (!device) return res.status(404).json({ error: 'Device not found' });
  const notifId = String(req.params.notifId);
  if (notifId === 'all') {
    db.prepare('UPDATE device_notifications SET dismissed = 1 WHERE device_id = ?').run(device.id);
  } else {
    db.prepare('UPDATE device_notifications SET dismissed = 1 WHERE id = ? AND device_id = ?').run(
      notifId,
      device.id
    );
  }
  wsHub.sendToDevice(String(device.id), { type: 'notification:dismiss', notificationId: notifId });
  res.json({ ok: true });
});

// ---------- CLIPBOARD ----------
app.get('/api/clipboard', requireAuth, (req: AuthedRequest, res) => {
  const items = db
    .prepare('SELECT * FROM clipboard_items WHERE user_id = ? ORDER BY created_at DESC LIMIT 40')
    .all(req.auth!.userId);
  res.json({ items });
});

app.post('/api/clipboard', requireAuth, (req: AuthedRequest, res) => {
  const content = String(req.body?.content || '');
  const deviceId = req.body?.deviceId ? String(req.body.deviceId) : null;
  if (!content) return res.status(400).json({ error: 'Clipboard content is empty' });

  const item = {
    id: crypto.randomUUID(),
    user_id: req.auth!.userId,
    device_id: deviceId,
    source: 'Web Dashboard',
    content,
    encrypted: req.body?.encrypted ? 1 : 0,
    created_at: Date.now(),
  };

  db.prepare(
    'INSERT INTO clipboard_items (id, user_id, device_id, source, content, encrypted, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(item.id, item.user_id, item.device_id, item.source, item.content, item.encrypted, item.created_at);

  if (deviceId) {
    wsHub.sendToDevice(deviceId, { type: 'clipboard:set', content });
  }
  wsHub.broadcastToUser(req.auth!.userId, { type: 'clipboard:new', item });
  res.status(201).json({ item });
});

// ---------- SETTINGS, WEBRTC ICE & DOWNLOADS ----------
app.get('/api/webrtc/ice-servers', requireAuth, (req: AuthedRequest, res) => {
  res.json(buildIceConfigForUser(req.auth!.userId));
});

app.get('/api/device/webrtc/ice-servers', (req, res) => {
  const device = getApprovedDeviceByToken(req, res);
  if (!device) return;
  res.json(buildIceConfigForUser(String(device.user_id)));
});

app.get('/api/network/diagnostics', requireAuth, (req: AuthedRequest, res) => {
  const publicUrl = getBaseUrl(req);
  const wsEndpoint = publicUrl.replace(/^https:/, 'wss:').replace(/^http:/, 'ws:') + '/ws';
  const isHttps = publicUrl.startsWith('https://');
  const iceConfig = buildIceConfigForUser(req.auth!.userId);
  const deviceId = req.query.deviceId ? String(req.query.deviceId) : '';
  const device = deviceId ? getDeviceForUser(deviceId, req.auth!.userId) : undefined;
  const deviceSession = device ? wsHub.getDeviceSessionInfo(String(device.id)) : null;

  res.json({
    publicUrl,
    wsEndpoint,
    isHttps,
    iceConfig,
    deviceSession,
    serverTime: Date.now(),
  });
});

app.get('/api/settings', requireAuth, (req: AuthedRequest, res) => {
  let row = db
    .prepare('SELECT * FROM server_settings WHERE user_id = ?')
    .get(req.auth!.userId) as Record<string, unknown> | undefined;

  if (!row) {
    db.prepare('INSERT INTO server_settings (user_id) VALUES (?)').run(req.auth!.userId);
    row = db.prepare('SELECT * FROM server_settings WHERE user_id = ?').get(req.auth!.userId) as Record<
      string,
      unknown
    >;
  }

  let stunUrls = DEFAULT_PUBLIC_STUN_URLS;
  try {
    const parsed = JSON.parse(String(row.stun_urls || '[]'));
    if (Array.isArray(parsed) && parsed.length > 0) stunUrls = parsed;
  } catch {
    // Keep public STUN fallback
  }

  res.json({
    settings: {
      stunUrls,
      turnUrl: String(row.turn_url || ''),
      turnUsername: String(row.turn_username || ''),
      turnCredential: '',
      hasTurnCredential: Boolean(
        row.turn_credential || process.env.TURN_CREDENTIAL || process.env.TURN_SHARED_SECRET
      ),
      envTurnConfigured: Boolean(process.env.TURN_URL),
      sessionTtlHours: Number(row.session_ttl_hours || 168),
      requireDeviceApproval: Boolean(row.require_device_approval),
      requirePinSensitive: Boolean(row.require_pin_sensitive),
    },
  });
});

app.put('/api/settings', requireAuth, (req: AuthedRequest, res) => {
  const s = req.body || {};
  const existing = db
    .prepare('SELECT turn_credential FROM server_settings WHERE user_id = ?')
    .get(req.auth!.userId) as { turn_credential: string | null } | undefined;

  const nextTurnCredential = s.clearTurnCredential
    ? ''
    : typeof s.turnCredential === 'string' && s.turnCredential.trim().length > 0
    ? s.turnCredential.trim()
    : existing?.turn_credential || '';

  const stunList = Array.isArray(s.stunUrls)
    ? s.stunUrls.map((u: unknown) => String(u).trim()).filter(Boolean)
    : [];

  db.prepare(`
    UPDATE server_settings SET
      stun_urls = ?,
      turn_url = ?,
      turn_username = ?,
      turn_credential = ?,
      session_ttl_hours = ?,
      require_device_approval = ?,
      require_pin_sensitive = ?
    WHERE user_id = ?
  `).run(
    JSON.stringify(stunList.length > 0 ? stunList : DEFAULT_PUBLIC_STUN_URLS),
    String(s.turnUrl || '').trim(),
    String(s.turnUsername || '').trim(),
    nextTurnCredential,
    Math.max(1, Math.min(720, Number(s.sessionTtlHours || 168))),
    s.requireDeviceApproval ? 1 : 0,
    s.requirePinSensitive ? 1 : 0,
    req.auth!.userId
  );
  res.json({ ok: true });
});

app.get('/api/downloads/info', (_req, res) => {
  const debugPath = path.join(DOWNLOADS_DIR, 'army-connect-debug.apk');
  const releasePath = path.join(DOWNLOADS_DIR, 'ArmyConnect.apk');
  const items = [
    {
      filename: 'army-connect-source.zip',
      available: true,
      size: 0,
      url: '/downloads/army-connect-source.zip',
    },
    {
      filename: 'army-connect-debug.apk',
      available: fs.existsSync(debugPath),
      size: fs.existsSync(debugPath) ? fs.statSync(debugPath).size : 0,
      url: '/downloads/army-connect-debug.apk',
    },
    {
      filename: 'ArmyConnect.apk',
      available: fs.existsSync(releasePath),
      size: fs.existsSync(releasePath) ? fs.statSync(releasePath).size : 0,
      url: '/downloads/ArmyConnect.apk',
    },
  ];
  res.json({ downloads: items });
});

function addFilesRecursively(
  archive: ZipArchive,
  absDir: string,
  relPrefix: string,
  ignoreSegment: (relPosix: string) => boolean
) {
  if (!fs.existsSync(absDir)) return;
  const entries = fs.readdirSync(absDir, { withFileTypes: true });
  for (const entry of entries) {
    const absPath = path.join(absDir, entry.name);
    const relPosix = relPrefix ? `${relPrefix}/${entry.name}` : entry.name;
    if (ignoreSegment(relPosix)) continue;
    if (entry.isDirectory()) {
      addFilesRecursively(archive, absPath, relPosix, ignoreSegment);
    } else if (entry.isFile()) {
      const mode = entry.name === 'gradlew' ? 0o755 : undefined;
      archive.file(absPath, mode ? { name: relPosix, mode } : { name: relPosix });
    }
  }
}

async function buildSourceZipBuffer(): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const archive = new ZipArchive({ zlib: { level: 9 } });
    const chunks: Buffer[] = [];

    archive.on('data', (chunk: Buffer) => chunks.push(chunk));
    archive.on('end', () => resolve(Buffer.concat(chunks)));
    archive.on('error', reject);

    const root = process.cwd();
    const shouldIgnore = (relPosix: string) =>
      relPosix.includes('/.gradle/') ||
      relPosix.endsWith('/.gradle') ||
      relPosix.includes('/build/') ||
      relPosix.endsWith('/build') ||
      relPosix.endsWith('/local.properties') ||
      relPosix.endsWith('.jks') ||
      relPosix.endsWith('.keystore') ||
      relPosix.endsWith('.DS_Store');

    for (const dir of ['src', 'server', 'android', 'android-app', '.github', 'coturn']) {
      addFilesRecursively(archive, path.join(root, dir), dir, shouldIgnore);
    }

    const includeFiles = [
      'package.json',
      'capacitor.config.ts',
      'server.ts',
      'tsconfig.json',
      'vite.config.ts',
      'index.html',
      'metadata.json',
      '.env.example',
      'Dockerfile',
      'docker-compose.yml',
      'Caddyfile',
      'INSTALLATION_AND_HOSTING.md',
    ];
    for (const file of includeFiles) {
      const full = path.join(root, file);
      if (fs.existsSync(full) && fs.statSync(full).isFile()) {
        archive.file(full, { name: file });
      }
    }

    archive.finalize();
  });
}

app.get('/downloads/army-connect-source.zip', async (req, res) => {
  try {
    const zipBuffer = await buildSourceZipBuffer();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="army-connect-complete-source.zip"');
    res.setHeader('Content-Length', String(zipBuffer.length));
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Disposition');
    if (req.method === 'HEAD') {
      res.status(200).end();
      return;
    }
    res.status(200).send(zipBuffer);
  } catch {
    if (!res.headersSent) {
      res.status(500).json({ error: 'Failed to generate source ZIP archive' });
    }
  }
});

app.get('/downloads/:filename', (req, res) => {
  const safe = path.basename(String(req.params.filename));
  const full = path.join(DOWNLOADS_DIR, safe);
  if (!fs.existsSync(full)) {
    res.status(404).json({ error: 'Artifact not found' });
    return;
  }
  if (safe.endsWith('.apk')) {
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  }
  res.download(full, safe);
});

// ---------- VITE / STATIC FRONTEND ----------
async function start() {
  if (IS_PROD) {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`ARMY CONNECT server listening on http://0.0.0.0:${PORT}`);
  });
}

start();
