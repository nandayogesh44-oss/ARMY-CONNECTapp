export interface User {
  id: string;
  email: string;
  name: string;
  hasPin: boolean;
  createdAt?: number;
}

export interface DevicePermissions {
  files: boolean;
  media: boolean;
  contacts: boolean;
  sms: boolean;
  calls: boolean;
  notifications: boolean;
  camera: boolean;
  screen: boolean;
  location: boolean;
  clipboard: boolean;
  ring: boolean;
}

export interface Device {
  id: string;
  user_id: string;
  name: string;
  manufacturer: string;
  model: string;
  android_version: string;
  api_level: number;
  approved: boolean;
  online: boolean;
  last_seen: number;
  battery_level: number;
  is_charging: boolean;
  battery_temp: number;
  storage_used: number;
  storage_total: number;
  ram_used: number;
  ram_total: number;
  wifi_ssid: string;
  wifi_strength: number;
  network_type: string;
  ip_address: string;
  latitude: number | null;
  longitude: number | null;
  location_accuracy: number | null;
  location_updated_at: number | null;
  permissions: DevicePermissions;
  e2ee_enabled: boolean;
  e2ee_fingerprint: string;
  created_at: number;
}

export interface FileItem {
  id: string;
  device_id: string;
  folder: string;
  name: string;
  path: string;
  size: number;
  mime_type: string;
  category: 'photo' | 'video' | 'audio' | 'document' | string;
  stored_filename: string | null;
  is_directory: number;
  source: string;
  created_at: number;
  updated_at: number;
}

export interface ContactItem {
  id: string;
  device_id: string;
  name: string;
  phone: string;
  email: string;
  organization: string;
  updated_at: number;
}

export interface SmsMessage {
  id: string;
  device_id: string;
  address: string;
  contact_name: string;
  body: string;
  direction: 'incoming' | 'outgoing' | string;
  status: string;
  timestamp: number;
}

export interface CallLogItem {
  id: string;
  device_id: string;
  number: string;
  contact_name: string;
  call_type: 'incoming' | 'outgoing' | 'missed' | string;
  duration_sec: number;
  timestamp: number;
}

export interface NotificationItem {
  id: string;
  device_id: string;
  app_name: string;
  package_name: string;
  title: string;
  text: string;
  timestamp: number;
}

export interface ClipboardItem {
  id: string;
  user_id: string;
  device_id: string | null;
  source: string;
  content: string;
  encrypted: number;
  created_at: number;
}

export interface ConnectionHistoryItem {
  id: string;
  device_id: string | null;
  device_name: string;
  event: string;
  ip_address: string;
  network_type: string;
  details: string;
  created_at: number;
}

export interface SessionItem {
  id: string;
  label: string;
  ip_address: string;
  user_agent: string;
  created_at: number;
  expires_at: number;
  revoked_at: number | null;
}

export interface ServerSettings {
  stunUrls: string[];
  turnUrl: string;
  turnUsername: string;
  turnCredential: string;
  hasTurnCredential?: boolean;
  envTurnConfigured?: boolean;
  clearTurnCredential?: boolean;
  sessionTtlHours: number;
  requireDeviceApproval: boolean;
  requirePinSensitive: boolean;
}

export interface WebRtcIceConfig {
  iceServers: RTCIceServer[];
  turnConfigured: boolean;
  fallbackMode: 'public-stun' | 'stun-and-turn';
}

export type WebRtcTransportMode =
  | 'direct-local'
  | 'direct-stun'
  | 'turn-relay'
  | 'wss-relay'
  | 'connecting';

export interface WebRtcStatsSnapshot {
  iceState: RTCIceConnectionState;
  connectionState: RTCPeerConnectionState;
  transportMode: WebRtcTransportMode;
  localCandidateType: string | null;
  remoteCandidateType: string | null;
  remoteAddress: string | null;
  rttMs: number | null;
}

export interface IceProbeResult {
  ok: boolean;
  hostFound: boolean;
  stunFound: boolean;
  turnRelayFound: boolean;
  publicReflexIp: string | null;
  gatheredMs: number;
  candidateCount: number;
  error?: string;
}

export interface NetworkDiagnostics {
  publicUrl: string;
  wsEndpoint: string;
  isHttps: boolean;
  iceConfig: WebRtcIceConfig;
  deviceSession: {
    online: boolean;
    approved: boolean;
    connectedAt: number | null;
    lastPongAt: number | null;
    ipAddress: string | null;
  } | null;
  serverTime: number;
}

export interface DeviceLatency {
  rttMs: number | null;
  serverDeviceMs: number | null;
  checkedAt: number | null;
  pinging: boolean;
  error?: string;
}

export interface DownloadArtifact {
  filename: string;
  available: boolean;
  size: number;
  updatedAt?: number;
  url: string;
}

export type ActiveTab =
  | 'overview'
  | 'files'
  | 'photos'
  | 'videos'
  | 'audio'
  | 'comms'
  | 'notifications'
  | 'vision'
  | 'location'
  | 'clipboard'
  | 'security';
