import React, { useEffect, useRef, useState } from 'react';
import {
  Bell,
  Camera,
  ClipboardCopy,
  Film,
  FolderOpen,
  Image as ImageIcon,
  LayoutGrid,
  LogOut,
  MapPin,
  Menu,
  MessageSquare,
  Moon,
  Music,
  QrCode,
  Shield,
  Smartphone,
  Sun,
  X,
} from 'lucide-react';
import { AuthScreen } from './components/AuthScreen';
import { DeviceCompanion } from './components/DeviceCompanion';
import { PairingModal } from './components/PairingModal';
import { PinPromptModal } from './components/PinPromptModal';
import { ClipboardView } from './components/views/ClipboardView';
import { CommsView } from './components/views/CommsView';
import { FileManagerView } from './components/views/FileManagerView';
import { LiveVisionView } from './components/views/LiveVisionView';
import { LocationView } from './components/views/LocationView';
import { MediaView } from './components/views/MediaView';
import { NotificationsView } from './components/views/NotificationsView';
import { OverviewView } from './components/views/OverviewView';
import { SecurityApkView } from './components/views/SecurityApkView';
import { apiFetch, buildWsUrl, getAuthToken, setAuthToken } from './lib/api';
import type {
  ActiveTab,
  ClipboardItem,
  ConnectionHistoryItem,
  Device,
  DeviceLatency,
  DevicePermissions,
  NotificationItem,
  ServerSettings,
  User,
} from './types';

export default function App() {
  const initialPairCode = new URLSearchParams(window.location.search).get('pair') || '';
  const [companionMode, setCompanionMode] = useState(Boolean(initialPairCode));
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('army_connect_theme');
    return saved ? saved === 'dark' : true;
  });

  const [user, setUser] = useState<User | null>(null);
  const [authChecking, setAuthChecking] = useState(true);
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [pairingOpen, setPairingOpen] = useState(false);

  const [devices, setDevices] = useState<Device[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string | null>(null);
  const [history, setHistory] = useState<ConnectionHistoryItem[]>([]);
  const [clipboard, setClipboard] = useState<ClipboardItem[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [settings, setSettings] = useState<ServerSettings | null>(null);

  const [cameraFrames, setCameraFrames] = useState<Record<string, string>>({});
  const [screenFrames, setScreenFrames] = useState<Record<string, string>>({});
  const [latencyByDevice, setLatencyByDevice] = useState<Record<string, DeviceLatency>>({});
  const [wsStatus, setWsStatus] = useState<'connected' | 'reconnecting'>('reconnecting');
  const [toast, setToast] = useState<string>('');
  const [emblemFailed, setEmblemFailed] = useState(false);

  const [pinChallenge, setPinChallenge] = useState<{
    open: boolean;
    label: string;
    action: (() => void) | null;
  }>({ open: false, label: '', action: null });

  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) root.classList.add('dark');
    else root.classList.remove('dark');
    localStorage.setItem('army_connect_theme', darkMode ? 'dark' : 'light');
  }, [darkMode]);

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast((cur) => (cur === msg ? '' : cur)), 3500);
  }

  async function refreshDashboardData() {
    const [devRes, histRes, clipRes, settRes] = await Promise.all([
      apiFetch<{ devices: Device[] }>('/api/devices'),
      apiFetch<{ history: ConnectionHistoryItem[] }>('/api/history'),
      apiFetch<{ items: ClipboardItem[] }>('/api/clipboard'),
      apiFetch<{ settings: ServerSettings }>('/api/settings'),
    ]);
    setDevices(devRes.devices);
    setHistory(histRes.history);
    setClipboard(clipRes.items);
    setSettings(settRes.settings);

    setSelectedDeviceId((cur) => {
      if (cur && devRes.devices.some((d) => d.id === cur)) return cur;
      return devRes.devices[0]?.id ?? null;
    });
  }

  async function loadDeviceNotifications(deviceId: string) {
    const res = await apiFetch<{ notifications: NotificationItem[] }>(
      `/api/devices/${deviceId}/notifications`
    );
    setNotifications(res.notifications);
  }

  useEffect(() => {
    const onUnauthorized = () => {
      setUser(null);
      setDevices([]);
    };
    window.addEventListener('army-connect:unauthorized', onUnauthorized);

    const token = getAuthToken();
    if (!token) {
      setAuthChecking(false);
    } else {
      apiFetch<{ user: User }>('/api/auth/me')
        .then(async (res) => {
          setUser(res.user);
          await refreshDashboardData();
        })
        .catch(() => {
          setAuthToken(null);
        })
        .finally(() => setAuthChecking(false));
    }

    return () => window.removeEventListener('army-connect:unauthorized', onUnauthorized);
  }, []);

  useEffect(() => {
    if (selectedDeviceId) {
      loadDeviceNotifications(selectedDeviceId).catch(() => {});
    } else {
      setNotifications([]);
    }
  }, [selectedDeviceId]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    let reconnectTimer: number | null = null;
    let pingTimer: number | null = null;
    let retryAttempt = 0;

    function clearTimers() {
      if (reconnectTimer) {
        window.clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
      if (pingTimer) {
        window.clearInterval(pingTimer);
        pingTimer = null;
      }
    }

    function connect() {
      clearTimers();
      const token = getAuthToken();
      if (!token || cancelled) return;
      const ws = new WebSocket(buildWsUrl('dashboard', token));
      wsRef.current = ws;

      ws.onopen = () => {
        retryAttempt = 0;
        setWsStatus('connected');
        refreshDashboardData().catch(() => {});
        pingTimer = window.setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'ping' }));
          }
        }, 20_000);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'session:revoked') {
            setAuthToken(null);
            setUser(null);
            return;
          }
          if (msg.type === 'device:paired' || msg.type === 'device:status') {
            refreshDashboardData().catch(() => {});
            if (msg.type === 'device:paired') {
              showToast(`Device paired: ${msg.device?.name || 'Android'}`);
            }
          } else if (msg.type === 'device:telemetry' && msg.deviceId) {
            const p = msg.payload || {};
            setDevices((prev) =>
              prev.map((d) =>
                d.id === msg.deviceId
                  ? {
                      ...d,
                      online: true,
                      last_seen: msg.lastSeen || Date.now(),
                      battery_level: p.batteryLevel ?? d.battery_level,
                      is_charging: p.isCharging ?? d.is_charging,
                      storage_used: p.storageUsed ?? d.storage_used,
                      storage_total: p.storageTotal ?? d.storage_total,
                      ram_used: p.ramUsed ?? d.ram_used,
                      ram_total: p.ramTotal ?? d.ram_total,
                      wifi_ssid: p.wifiSsid ?? d.wifi_ssid,
                      network_type: p.networkType ?? d.network_type,
                      latitude: p.latitude ?? d.latitude,
                      longitude: p.longitude ?? d.longitude,
                      location_accuracy: p.locationAccuracy ?? d.location_accuracy,
                      location_updated_at: p.latitude ? Date.now() : d.location_updated_at,
                    }
                  : d
              )
            );
          } else if (msg.type === 'notification:new' && msg.notification) {
            setNotifications((prev) => [msg.notification, ...prev]);
            showToast(`${msg.notification.appName || 'Notification'}: ${msg.notification.title}`);
          } else if (msg.type === 'clipboard:new' && msg.item) {
            setClipboard((prev) =>
              prev.some((c) => c.id === msg.item.id) ? prev : [msg.item, ...prev]
            );
          } else if (msg.type === 'file:added' && msg.deviceId && msg.file) {
            window.dispatchEvent(new CustomEvent('army-connect:file-added', { detail: msg }));
          } else if (msg.type === 'camera:frame' && msg.deviceId && msg.frame) {
            setCameraFrames((prev) => ({ ...prev, [msg.deviceId]: msg.frame }));
          } else if (msg.type === 'screen:frame' && msg.deviceId && msg.frame) {
            setScreenFrames((prev) => ({ ...prev, [msg.deviceId]: msg.frame }));
          } else if (
            typeof msg.type === 'string' &&
            msg.type.startsWith('webrtc:') &&
            msg.deviceId
          ) {
            window.dispatchEvent(new CustomEvent('army-connect:webrtc-signal', { detail: msg }));
          }
        } catch {
          // Ignore malformed WS messages
        }
      };

      ws.onclose = () => {
        clearTimers();
        setWsStatus('reconnecting');
        if (!cancelled) {
          const delayMs = Math.min(15_000, 1500 * Math.pow(2, retryAttempt));
          retryAttempt = Math.min(retryAttempt + 1, 5);
          reconnectTimer = window.setTimeout(connect, delayMs);
        }
      };
    }

    const handleNetworkChange = () => {
      if (cancelled) return;
      if (navigator.onLine) {
        retryAttempt = 0;
        if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
          connect();
        } else {
          wsRef.current.send(JSON.stringify({ type: 'ping' }));
          refreshDashboardData().catch(() => {});
        }
      } else {
        setWsStatus('reconnecting');
      }
    };

    window.addEventListener('online', handleNetworkChange);
    window.addEventListener('offline', handleNetworkChange);
    const navConn = (navigator as Navigator & { connection?: EventTarget }).connection;
    navConn?.addEventListener?.('change', handleNetworkChange);

    connect();
    return () => {
      cancelled = true;
      clearTimers();
      window.removeEventListener('online', handleNetworkChange);
      window.removeEventListener('offline', handleNetworkChange);
      navConn?.removeEventListener?.('change', handleNetworkChange);
      wsRef.current?.close();
    };
  }, [user?.id]);

  if (companionMode) {
    return (
      <DeviceCompanion
        initialCode={initialPairCode}
        onExit={() => {
          setCompanionMode(false);
          if (window.location.search) {
            window.history.replaceState({}, '', '/');
          }
        }}
      />
    );
  }

  if (authChecking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F4F6F3] dark:bg-[#090B09]">
        <div className="text-sm font-mono text-[#4E5A51] dark:text-[#97A399]">
          Loading ARMY CONNECT...
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <AuthScreen
        onAuthenticated={async (loggedUser) => {
          setUser(loggedUser);
          await refreshDashboardData();
        }}
        onOpenCompanion={() => setCompanionMode(true)}
        darkMode={darkMode}
        onToggleTheme={() => setDarkMode((d) => !d)}
      />
    );
  }

  const selectedDevice = devices.find((d) => d.id === selectedDeviceId) || null;

  function requirePinCheck(label: string, action: () => void) {
    if (settings?.requirePinSensitive && user?.hasPin) {
      setPinChallenge({ open: true, label, action });
    } else {
      action();
    }
  }

  async function handlePingDevice(deviceId: string) {
    setLatencyByDevice((prev) => ({
      ...prev,
      [deviceId]: {
        rttMs: prev[deviceId]?.rttMs ?? null,
        serverDeviceMs: prev[deviceId]?.serverDeviceMs ?? null,
        checkedAt: prev[deviceId]?.checkedAt ?? null,
        pinging: true,
        error: undefined,
      },
    }));

    const started = performance.now();
    try {
      const res = await apiFetch<{
        ok: boolean;
        serverToDeviceMs: number;
        checkedAt: number;
      }>(`/api/devices/${deviceId}/ping`, { method: 'POST' });
      const rttMs = Math.max(1, Math.round(performance.now() - started));
      setLatencyByDevice((prev) => ({
        ...prev,
        [deviceId]: {
          rttMs,
          serverDeviceMs: res.serverToDeviceMs,
          checkedAt: res.checkedAt,
          pinging: false,
        },
      }));
    } catch (err) {
      setLatencyByDevice((prev) => ({
        ...prev,
        [deviceId]: {
          rttMs: null,
          serverDeviceMs: null,
          checkedAt: Date.now(),
          pinging: false,
          error: err instanceof Error ? err.message : 'Ping failed',
        },
      }));
    }
  }

  async function handleCommand(
    deviceId: string,
    command: string,
    payload: Record<string, unknown> = {}
  ) {
    try {
      await apiFetch(`/api/devices/${deviceId}/command`, {
        method: 'POST',
        body: JSON.stringify({ command, payload }),
      });
      showToast(`Command sent: ${command}`);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Command failed');
    }
  }

  async function handleApprove(id: string) {
    await apiFetch(`/api/devices/${id}/approve`, { method: 'POST' });
    await refreshDashboardData();
    showToast('Device approved');
  }

  async function handleReject(id: string) {
    await apiFetch(`/api/devices/${id}/reject`, { method: 'POST' });
    await refreshDashboardData();
    showToast('Device rejected');
  }

  async function handleDisconnect(id: string) {
    await apiFetch(`/api/devices/${id}/disconnect`, { method: 'POST' });
    await refreshDashboardData();
    showToast('Device securely disconnected');
  }

  async function handleUnpair(id: string) {
    requirePinCheck('Unpair device permanently', async () => {
      await apiFetch(`/api/devices/${id}`, { method: 'DELETE' });
      await refreshDashboardData();
      showToast('Device unpaired');
    });
  }

  async function handleUpdatePermissions(id: string, permissions: DevicePermissions) {
    await apiFetch(`/api/devices/${id}/permissions`, {
      method: 'PATCH',
      body: JSON.stringify({ permissions }),
    });
    setDevices((prev) => prev.map((d) => (d.id === id ? { ...d, permissions } : d)));
    showToast('Permissions updated');
  }

  async function handleDismissNotification(notifId: string) {
    if (!selectedDevice) return;
    await apiFetch(`/api/devices/${selectedDevice.id}/notifications/${notifId}`, {
      method: 'DELETE',
    });
    if (notifId === 'all') setNotifications([]);
    else setNotifications((prev) => prev.filter((n) => n.id !== notifId));
  }

  async function handleLogout() {
    await apiFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
    setAuthToken(null);
    setUser(null);
  }

  const navItems: Array<{ id: ActiveTab; label: string; icon: React.ReactNode }> = [
    { id: 'overview', label: 'Devices & Status', icon: <LayoutGrid className="w-4 h-4" /> },
    { id: 'files', label: 'File Manager', icon: <FolderOpen className="w-4 h-4" /> },
    { id: 'photos', label: 'Photos', icon: <ImageIcon className="w-4 h-4" /> },
    { id: 'videos', label: 'Videos', icon: <Film className="w-4 h-4" /> },
    { id: 'audio', label: 'Music & Audio', icon: <Music className="w-4 h-4" /> },
    { id: 'comms', label: 'SMS, Contacts & Calls', icon: <MessageSquare className="w-4 h-4" /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell className="w-4 h-4" /> },
    { id: 'vision', label: 'Camera & Screen', icon: <Camera className="w-4 h-4" /> },
    { id: 'location', label: 'Location & Find', icon: <MapPin className="w-4 h-4" /> },
    { id: 'clipboard', label: 'Clipboard Sync', icon: <ClipboardCopy className="w-4 h-4" /> },
    { id: 'security', label: 'Security & APK', icon: <Shield className="w-4 h-4" /> },
  ];

  const activeNavLabel = navItems.find((i) => i.id === activeTab)?.label || 'Overview';

  return (
    <div className="min-h-screen flex bg-[#F4F6F3] dark:bg-[#090B09] text-[#111713] dark:text-[#EDF2EE]">
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-white dark:bg-[#0E120F] border-r border-[#D7DFD8] dark:border-[#1F2921] flex flex-col transition-transform lg:static lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="px-5 py-4 border-b border-[#D7DFD8] dark:border-[#1F2921] flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg overflow-hidden bg-[#111612] border border-[#2F5E38]/50 flex items-center justify-center shrink-0">
              {!emblemFailed ? (
                <img
                  src="/src/assets/images/army_connect_emblem_1795266698202.jpg"
                  alt="ARMY CONNECT emblem"
                  referrerPolicy="no-referrer"
                  onError={() => setEmblemFailed(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Shield className="w-4 h-4 text-[#3E7B4A]" />
              )}
            </div>
            <span className="font-display text-base font-bold tracking-tight whitespace-nowrap truncate">
              ARMY CONNECT
            </span>
          </div>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(false)}
            className="lg:hidden p-1 rounded hover:bg-[#E7ECE6] dark:hover:bg-[#161D17]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 border-b border-[#D7DFD8] dark:border-[#1F2921] space-y-1.5">
          <label className="block text-xs text-[#4E5A51] dark:text-[#97A399]">Active Device</label>
          <select
            value={selectedDeviceId || ''}
            onChange={(e) => setSelectedDeviceId(e.target.value || null)}
            className="w-full px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium"
          >
            {devices.length === 0 ? (
              <option value="">No paired devices</option>
            ) : (
              devices.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.online ? 'Online' : 'Offline'})
                </option>
              ))
            )}
          </select>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-[#1E4627] dark:bg-[#2F5E38] text-white'
                    : 'text-[#4E5A51] dark:text-[#97A399] hover:bg-[#E7ECE6] dark:hover:bg-[#161D17] hover:text-[#111713] dark:hover:text-[#EDF2EE]'
                }`}
              >
                {item.icon}
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-[#D7DFD8] dark:border-[#1F2921] space-y-3">
          <button
            type="button"
            onClick={() => setCompanionMode(true)}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium hover:bg-[#E7ECE6] dark:hover:bg-[#161D17]"
          >
            <Smartphone className="w-3.5 h-3.5 text-[#3E7B4A]" />
            Use This Device as Phone
          </button>
          <div className="flex items-center justify-between text-xs text-[#4E5A51] dark:text-[#97A399]">
            <span className="truncate">{user.name}</span>
            <button
              type="button"
              onClick={handleLogout}
              className="inline-flex items-center gap-1 text-red-600 dark:text-red-400 font-medium"
            >
              <LogOut className="w-3.5 h-3.5" />
              Logout
            </button>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 bg-[#F4F6F3]/90 dark:bg-[#090B09]/90 backdrop-blur-sm border-b border-[#D7DFD8] dark:border-[#1F2921] px-4 sm:px-8 py-3.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921]"
            >
              <Menu className="w-4 h-4" />
            </button>
            <div className="text-sm font-medium truncate">
              <span className="text-[#4E5A51] dark:text-[#97A399]">ARMY CONNECT</span>
              <span className="mx-2 text-[#4E5A51] dark:text-[#97A399]">/</span>
              <span>{activeNavLabel}</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <span className="hidden sm:inline-block text-xs font-mono text-[#4E5A51] dark:text-[#97A399] mr-2">
              {wsStatus === 'connected' ? 'Relay Connected' : 'Reconnecting'}
            </span>
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              aria-label="Toggle color theme"
              className="p-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] hover:bg-[#E7ECE6] dark:hover:bg-[#161D17]"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={() => setPairingOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold whitespace-nowrap shrink-0"
            >
              <QrCode className="w-3.5 h-3.5" />
              Pair Device
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-8 max-w-7xl w-full mx-auto">
          {toast && (
            <div className="mb-5 px-4 py-2.5 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-medium">
              {toast}
            </div>
          )}

          {activeTab === 'overview' && (
            <OverviewView
              devices={devices}
              selectedDevice={selectedDevice}
              history={history}
              latencyByDevice={latencyByDevice}
              onSelectDevice={setSelectedDeviceId}
              onPing={handlePingDevice}
              onApprove={handleApprove}
              onReject={handleReject}
              onDisconnect={handleDisconnect}
              onCommand={handleCommand}
              onOpenPairing={() => setPairingOpen(true)}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === 'files' && (
            <FileManagerView
              device={selectedDevice}
              onCommand={handleCommand}
              onSendSignal={(msg) => {
                if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                  wsRef.current.send(JSON.stringify(msg));
                }
              }}
            />
          )}

          {(activeTab === 'photos' || activeTab === 'videos' || activeTab === 'audio') && (
            <MediaView
              device={selectedDevice}
              category={
                activeTab === 'photos' ? 'photo' : activeTab === 'videos' ? 'video' : 'audio'
              }
            />
          )}

          {activeTab === 'comms' && (
            <CommsView device={selectedDevice} requirePinCheck={requirePinCheck} />
          )}

          {activeTab === 'notifications' && (
            <NotificationsView
              device={selectedDevice}
              notifications={notifications}
              onDismiss={handleDismissNotification}
            />
          )}

          {activeTab === 'vision' && (
            <LiveVisionView
              device={selectedDevice}
              cameraFrame={selectedDevice ? cameraFrames[selectedDevice.id] || null : null}
              screenFrame={selectedDevice ? screenFrames[selectedDevice.id] || null : null}
              onCommand={handleCommand}
              onSendSignal={(msg) => {
                if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                  wsRef.current.send(JSON.stringify(msg));
                }
              }}
              requirePinCheck={requirePinCheck}
            />
          )}

          {activeTab === 'location' && (
            <LocationView device={selectedDevice} onCommand={handleCommand} />
          )}

          {activeTab === 'clipboard' && (
            <ClipboardView
              device={selectedDevice}
              items={clipboard}
              onAdded={(item) =>
                setClipboard((prev) =>
                  prev.some((c) => c.id === item.id) ? prev : [item, ...prev]
                )
              }
            />
          )}

          {activeTab === 'security' && (
            <SecurityApkView
              user={user}
              device={selectedDevice}
              onUpdatePermissions={handleUpdatePermissions}
              onUnpairDevice={handleUnpair}
              onUserUpdated={setUser}
            />
          )}
        </main>
      </div>

      <PairingModal open={pairingOpen} onClose={() => setPairingOpen(false)} />

      <PinPromptModal
        open={pinChallenge.open}
        actionLabel={pinChallenge.label}
        onCancel={() => setPinChallenge({ open: false, label: '', action: null })}
        onSuccess={() => {
          const fn = pinChallenge.action;
          setPinChallenge({ open: false, label: '', action: null });
          fn?.();
        }}
      />
    </div>
  );
}
