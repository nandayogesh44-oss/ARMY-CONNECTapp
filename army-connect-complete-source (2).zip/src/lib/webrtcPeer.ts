import type {
  IceProbeResult,
  WebRtcIceConfig,
  WebRtcStatsSnapshot,
  WebRtcTransportMode,
} from '../types';

export const DEFAULT_PUBLIC_STUN_ICE: RTCIceServer[] = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun.cloudflare.com:3478' },
];

export const DEFAULT_ICE_CONFIG: WebRtcIceConfig = {
  iceServers: DEFAULT_PUBLIC_STUN_ICE,
  turnConfigured: false,
  fallbackMode: 'public-stun',
};

export function describeTransportMode(mode: WebRtcTransportMode): string {
  switch (mode) {
    case 'direct-local':
      return 'WebRTC P2P (Direct LAN)';
    case 'direct-stun':
      return 'WebRTC P2P (STUN Worldwide)';
    case 'turn-relay':
      return 'WebRTC TURN Relay (NAT Traversal)';
    case 'connecting':
      return 'WebRTC Negotiating ICE...';
    default:
      return 'Encrypted WSS Relay';
  }
}

export async function inspectPeerConnectionStats(
  pc: RTCPeerConnection
): Promise<WebRtcStatsSnapshot> {
  const fallback: WebRtcStatsSnapshot = {
    iceState: pc.iceConnectionState,
    connectionState: pc.connectionState,
    transportMode:
      pc.connectionState === 'connected' ? 'direct-stun' : 'connecting',
    localCandidateType: null,
    remoteCandidateType: null,
    remoteAddress: null,
    rttMs: null,
  };

  try {
    const stats = await pc.getStats();
    let selectedPair: Record<string, unknown> | null = null;
    const candidates = new Map<string, Record<string, unknown>>();

    stats.forEach((report) => {
      const rec = report as unknown as Record<string, unknown>;
      if (rec.type === 'local-candidate' || rec.type === 'remote-candidate') {
        candidates.set(String(rec.id), rec);
      } else if (
        rec.type === 'candidate-pair' &&
        (rec.nominated === true || rec.state === 'succeeded')
      ) {
        if (!selectedPair || rec.nominated === true) {
          selectedPair = rec;
        }
      }
    });

    if (!selectedPair) return fallback;

    const pair = selectedPair as Record<string, unknown>;
    const local = candidates.get(String(pair.localCandidateId || ''));
    const remote = candidates.get(String(pair.remoteCandidateId || ''));

    const localType = local?.candidateType ? String(local.candidateType) : null;
    const remoteType = remote?.candidateType ? String(remote.candidateType) : null;
    const remoteAddress = remote?.address
      ? `${String(remote.address)}${remote.port ? `:${String(remote.port)}` : ''}`
      : null;

    let transportMode: WebRtcTransportMode = 'connecting';
    if (localType === 'relay' || remoteType === 'relay') {
      transportMode = 'turn-relay';
    } else if (
      localType === 'srflx' ||
      remoteType === 'srflx' ||
      localType === 'prflx' ||
      remoteType === 'prflx'
    ) {
      transportMode = 'direct-stun';
    } else if (localType === 'host' && remoteType === 'host') {
      transportMode = 'direct-local';
    }

    const rttMs =
      typeof pair.currentRoundTripTime === 'number'
        ? Math.max(1, Math.round(pair.currentRoundTripTime * 1000))
        : null;

    return {
      iceState: pc.iceConnectionState,
      connectionState: pc.connectionState,
      transportMode,
      localCandidateType: localType,
      remoteCandidateType: remoteType,
      remoteAddress,
      rttMs,
    };
  } catch {
    return fallback;
  }
}

export async function testIceConnectivity(
  iceServers: RTCIceServer[],
  timeoutMs = 4500
): Promise<IceProbeResult> {
  const started = performance.now();
  if (typeof RTCPeerConnection === 'undefined') {
    return {
      ok: false,
      hostFound: false,
      stunFound: false,
      turnRelayFound: false,
      publicReflexIp: null,
      gatheredMs: 0,
      candidateCount: 0,
      error: 'WebRTC is unavailable in this browser.',
    };
  }

  return new Promise((resolve) => {
    let settled = false;
    let hostFound = false;
    let stunFound = false;
    let turnRelayFound = false;
    let publicReflexIp: string | null = null;
    let candidateCount = 0;

    let pc: RTCPeerConnection | null = null;
    try {
      pc = new RTCPeerConnection({
        iceServers: iceServers.length > 0 ? iceServers : DEFAULT_PUBLIC_STUN_ICE,
        iceCandidatePoolSize: 2,
      });
    } catch (err) {
      resolve({
        ok: false,
        hostFound: false,
        stunFound: false,
        turnRelayFound: false,
        publicReflexIp: null,
        gatheredMs: Math.round(performance.now() - started),
        candidateCount: 0,
        error: err instanceof Error ? err.message : 'Unable to create RTCPeerConnection',
      });
      return;
    }

    const finish = () => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timer);
      pc?.close();
      resolve({
        ok: hostFound || stunFound || turnRelayFound,
        hostFound,
        stunFound,
        turnRelayFound,
        publicReflexIp,
        gatheredMs: Math.max(1, Math.round(performance.now() - started)),
        candidateCount,
      });
    };

    const timer = window.setTimeout(finish, timeoutMs);

    pc.createDataChannel('ice-probe');
    pc.onicecandidate = (ev) => {
      if (!ev.candidate) {
        finish();
        return;
      }
      candidateCount += 1;
      const cand = ev.candidate.candidate || '';
      const type = ev.candidate.type;
      if (type === 'host' || cand.includes(' typ host')) hostFound = true;
      if (type === 'srflx' || cand.includes(' typ srflx')) {
        stunFound = true;
        if (!publicReflexIp && ev.candidate.address) {
          publicReflexIp = ev.candidate.address;
        }
      }
      if (type === 'relay' || cand.includes(' typ relay')) {
        turnRelayFound = true;
      }
    };

    pc.onicegatheringstatechange = () => {
      if (pc?.iceGatheringState === 'complete') finish();
    };

    pc.createOffer()
      .then((offer) => pc?.setLocalDescription(offer))
      .catch((err) => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        pc?.close();
        resolve({
          ok: false,
          hostFound: false,
          stunFound: false,
          turnRelayFound: false,
          publicReflexIp: null,
          gatheredMs: Math.round(performance.now() - started),
          candidateCount: 0,
          error: err instanceof Error ? err.message : 'ICE probe failed',
        });
      });
  });
}

const CHUNK_SIZE = 16 * 1024;

export async function sendFileOverDataChannel(
  dc: RTCDataChannel,
  file: File,
  onProgress?: (pct: number) => void
): Promise<void> {
  if (dc.readyState !== 'open') {
    throw new Error('WebRTC DataChannel is not open');
  }
  const transferId = crypto.randomUUID();
  dc.send(
    JSON.stringify({
      kind: 'file:meta',
      transferId,
      name: file.name,
      size: file.size,
      mimeType: file.type || 'application/octet-stream',
    })
  );

  const buffer = await file.arrayBuffer();
  const total = buffer.byteLength;
  let offset = 0;

  while (offset < total) {
    if (dc.readyState !== 'open') {
      throw new Error('WebRTC DataChannel closed during transfer');
    }
    if (dc.bufferedAmount > 512 * 1024) {
      await new Promise<void>((res) => {
        const check = () => {
          if (dc.bufferedAmount < 128 * 1024 || dc.readyState !== 'open') {
            dc.removeEventListener('bufferedamountlow', check);
            res();
          }
        };
        dc.bufferedAmountLowThreshold = 128 * 1024;
        dc.addEventListener('bufferedamountlow', check);
        window.setTimeout(check, 50);
      });
    }
    const slice = buffer.slice(offset, offset + CHUNK_SIZE);
    dc.send(slice);
    offset += slice.byteLength;
    onProgress?.(Math.min(100, Math.round((offset / Math.max(1, total)) * 100)));
  }

  dc.send(JSON.stringify({ kind: 'file:end', transferId }));
}

export interface IncomingP2pFile {
  name: string;
  size: number;
  mimeType: string;
  blob: Blob;
}

export function attachDataChannelFileReceiver(
  dc: RTCDataChannel,
  onFileReceived: (file: IncomingP2pFile) => void,
  onProgress?: (name: string, pct: number) => void
) {
  let activeMeta: { name: string; size: number; mimeType: string } | null = null;
  let chunks: ArrayBuffer[] = [];
  let receivedBytes = 0;

  dc.binaryType = 'arraybuffer';
  dc.onmessage = (ev) => {
    if (typeof ev.data === 'string') {
      try {
        const msg = JSON.parse(ev.data) as {
          kind: string;
          name?: string;
          size?: number;
          mimeType?: string;
        };
        if (msg.kind === 'file:meta') {
          activeMeta = {
            name: msg.name || 'transfer.bin',
            size: Number(msg.size || 0),
            mimeType: msg.mimeType || 'application/octet-stream',
          };
          chunks = [];
          receivedBytes = 0;
        } else if (msg.kind === 'file:end' && activeMeta) {
          const blob = new Blob(chunks, { type: activeMeta.mimeType });
          const finished = { ...activeMeta, blob };
          activeMeta = null;
          chunks = [];
          receivedBytes = 0;
          onFileReceived(finished);
        }
      } catch {
        // Ignore malformed control frame
      }
      return;
    }

    if (activeMeta && ev.data instanceof ArrayBuffer) {
      chunks.push(ev.data);
      receivedBytes += ev.data.byteLength;
      const pct = activeMeta.size > 0 ? Math.min(100, Math.round((receivedBytes / activeMeta.size) * 100)) : 100;
      onProgress?.(activeMeta.name, pct);
    }
  };
}
