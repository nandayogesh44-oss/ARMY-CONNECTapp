const TOKEN_KEY = 'army_connect_token';
const SERVER_URL_KEY = 'army_connect_server_url';
export const DEFAULT_CAPACITOR_SERVER_URL =
  'https://ais-dev-a67ydomazwa6yluzkluuqt-904967991585.asia-northeast1.run.app';

export function isNativeCapacitor(): boolean {
  const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  return Boolean(cap?.isNativePlatform?.()) || window.location.protocol === 'capacitor:';
}

export function getServerBaseUrl(): string {
  const saved = localStorage.getItem(SERVER_URL_KEY)?.trim().replace(/\/+$/, '');
  if (saved && /^https?:\/\//i.test(saved)) {
    return saved;
  }
  if (isNativeCapacitor()) {
    return DEFAULT_CAPACITOR_SERVER_URL;
  }
  return '';
}

export function setServerBaseUrl(url: string | null) {
  const normalized = url?.trim().replace(/\/+$/, '') || '';
  if (normalized && /^https?:\/\//i.test(normalized)) {
    localStorage.setItem(SERVER_URL_KEY, normalized);
  } else {
    localStorage.removeItem(SERVER_URL_KEY);
  }
}

export function apiUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) return path;
  const base = getServerBaseUrl();
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  return base ? `${base}${normalizedPath}` : normalizedPath;
}

export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setAuthToken(token: string | null) {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

export function buildWsUrl(role: 'dashboard' | 'device', token: string): string {
  const base = getServerBaseUrl();
  if (base) {
    const wsBase = base.replace(/^https:/i, 'wss:').replace(/^http:/i, 'ws:');
    return `${wsBase}/ws?role=${role}&token=${encodeURIComponent(token)}`;
  }
  const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${proto}//${window.location.host}/ws?role=${role}&token=${encodeURIComponent(token)}`;
}

export async function apiFetch<T = unknown>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getAuthToken();
  const headers = new Headers(options.headers || {});
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  if (!(options.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const res = await fetch(apiUrl(path), { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && path !== '/api/auth/login' && path !== '/api/auth/register') {
      setAuthToken(null);
      window.dispatchEvent(new CustomEvent('army-connect:unauthorized'));
    }
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data as T;
}

export function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

export function formatRelativeTime(ts: number | null | undefined): string {
  if (!ts) return 'Never';
  const diff = Math.max(0, Date.now() - ts);
  if (diff < 15_000) return 'Just now';
  if (diff < 60_000) return `${Math.floor(diff / 1000)}s ago`;
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
  return new Date(ts).toLocaleDateString();
}
