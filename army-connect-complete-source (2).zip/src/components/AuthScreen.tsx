import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Moon, Shield, Smartphone, Sun } from 'lucide-react';
import { apiFetch, apiUrl, setAuthToken } from '../lib/api';
import type { User } from '../types';
import { SourceZipDownloadButton } from './SourceZipDownloadButton';

interface AuthScreenProps {
  onAuthenticated: (user: User) => void;
  onOpenCompanion: () => void;
  darkMode: boolean;
  onToggleTheme: () => void;
}

export function AuthScreen({
  onAuthenticated,
  onOpenCompanion,
  darkMode,
  onToggleTheme,
}: AuthScreenProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pin, setPin] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [bannerFailed, setBannerFailed] = useState(false);
  const [emblemFailed, setEmblemFailed] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const endpoint = mode === 'login' ? '/api/auth/login' : '/api/auth/register';
      const body =
        mode === 'login'
          ? { email, password, label: navigator.userAgent.includes('Mobile') ? 'Mobile Browser' : 'Desktop Web' }
          : { name, email, password, pin: pin || undefined };
      const res = await apiFetch<{ token: string; user: User }>(endpoint, {
        method: 'POST',
        body: JSON.stringify(body),
      });
      setAuthToken(res.token);
      onAuthenticated(res.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F6F3] dark:bg-[#090B09] text-[#111713] dark:text-[#EDF2EE]">
      <header className="flex items-center justify-between gap-8 px-6 py-4 border-b border-[#D7DFD8] dark:border-[#1F2921]">
        <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
          <div className="w-9 h-9 rounded-lg overflow-hidden bg-[#111612] border border-[#2F5E38]/50 flex items-center justify-center">
            {!emblemFailed ? (
              <img
                src="/src/assets/images/army_connect_emblem_1795266698202.jpg"
                alt="ARMY CONNECT emblem"
                referrerPolicy="no-referrer"
                onError={() => setEmblemFailed(true)}
                className="w-full h-full object-cover"
              />
            ) : (
              <Shield className="w-5 h-5 text-[#3E7B4A]" />
            )}
          </div>
          <span className="font-display text-lg font-bold tracking-tight whitespace-nowrap shrink-0">
            ARMY CONNECT
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#4E5A51] dark:text-[#97A399]">
          <button
            type="button"
            onClick={onOpenCompanion}
            className="hover:text-[#111713] dark:hover:text-[#EDF2EE] transition-colors whitespace-nowrap shrink-0"
          >
            Pair This Phone
          </button>
          <a
            href={apiUrl('/downloads/army-connect-source.zip')}
            className="hover:text-[#111713] dark:hover:text-[#EDF2EE] transition-colors whitespace-nowrap shrink-0"
          >
            Android Source
          </a>
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label="Toggle color theme"
            className="p-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] hover:bg-[#E7ECE6] dark:hover:bg-[#161D17] transition-colors"
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      <main className="flex-1 grid lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-7 relative overflow-hidden bg-[#0F1410] text-[#EDF2EE] flex flex-col justify-between p-8 lg:p-14 border-b lg:border-b-0 lg:border-r border-[#1F2921]">
          {!bannerFailed && (
            <img
              src="/src/assets/images/army_tactical_banner_1795266699910.jpg"
              alt="ARMY CONNECT tactical command hardware surface"
              referrerPolicy="no-referrer"
              onError={() => setBannerFailed(true)}
              className="absolute inset-0 w-full h-full object-cover opacity-50"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#090B09] via-[#090B09]/75 to-[#090B09]/50" />

          <div className="relative z-10 max-w-xl">
            <p className="text-xs font-medium tracking-wider text-[#8FBC96] mb-3">
              Self-Hosted Android Command &amp; File Transfer
            </p>
            <h1
              className="font-display text-3xl lg:text-5xl font-bold leading-tight mb-5"
              style={{ textWrap: 'balance' }}
            >
              Manage your Android devices from anywhere, under your own control.
            </h1>
            <p className="text-sm lg:text-base text-[#BAC7BC] leading-relaxed max-w-lg">
              Direct remote file management, photo and media browsing, SMS and call history, live
              camera and screen mirroring, clipboard synchronization, and device location with zero
              subscriptions.
            </p>
            <div className="mt-7 pt-6 border-t border-white/10 space-y-2.5">
              <SourceZipDownloadButton variant="hero" />
              <p className="text-xs text-[#97A399]">
                Includes the complete Android Kotlin project, Node.js backend, and automated GitHub Actions APK build workflow.
              </p>
            </div>
          </div>

          <div className="relative z-10 grid sm:grid-cols-3 gap-6 pt-10 mt-10 border-t border-white/10">
            <div>
              <div className="font-mono text-sm font-semibold text-[#EDF2EE]">WebRTC + WSS</div>
              <div className="text-xs text-[#97A399] mt-1">
                Cross-network NAT traversal and encrypted WebSocket relay
              </div>
            </div>
            <div>
              <div className="font-mono text-sm font-semibold text-[#EDF2EE]">Zero Subscriptions</div>
              <div className="text-xs text-[#97A399] mt-1">
                100% open architecture hosted on your own hardware
              </div>
            </div>
            <div>
              <div className="font-mono text-sm font-semibold text-[#EDF2EE]">Android 8 – 16</div>
              <div className="text-xs text-[#97A399] mt-1">
                Native Kotlin APK source plus instant browser companion mode
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 flex items-center justify-center p-6 lg:p-12">
          <div className="w-full max-w-md space-y-6">
            <div>
              <h2 className="font-display text-2xl font-bold tracking-tight">
                {mode === 'login' ? 'Sign in to Command' : 'Create Command Account'}
              </h2>
              <p className="text-sm text-[#4E5A51] dark:text-[#97A399] mt-1">
                {mode === 'login'
                  ? 'Access your paired Android devices, files, and real-time streams.'
                  : 'Register your self-hosted operator account. No external cloud required.'}
              </p>
            </div>

            <div className="flex items-center gap-1 p-1 rounded-lg bg-[#E7ECE6] dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921]">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError('');
                }}
                className={`flex-1 py-2 px-4 text-sm font-medium rounded-md transition-colors whitespace-nowrap ${
                  mode === 'login'
                    ? 'bg-white dark:bg-[#1E2A20] text-[#111713] dark:text-[#EDF2EE] shadow-sm'
                    : 'text-[#4E5A51] dark:text-[#97A399]'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setError('');
                }}
                className={`flex-1 py-2 px-4 text-sm font-medium rounded-md transition-colors whitespace-nowrap ${
                  mode === 'register'
                    ? 'bg-white dark:bg-[#1E2A20] text-[#111713] dark:text-[#EDF2EE] shadow-sm'
                    : 'text-[#4E5A51] dark:text-[#97A399]'
                }`}
              >
                Create Account
              </button>
            </div>

            {error && (
              <div
                role="alert"
                className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-sm text-red-700 dark:text-red-300"
              >
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'register' && (
                <div>
                  <label className="block text-xs font-medium text-[#4E5A51] dark:text-[#97A399] mb-1.5">
                    Operator Name
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Commander Patel"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] text-sm focus:outline-none focus:ring-2 focus:ring-[#2F5E38]"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-[#4E5A51] dark:text-[#97A399] mb-1.5">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="operator@local.host"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] text-sm focus:outline-none focus:ring-2 focus:ring-[#2F5E38]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4E5A51] dark:text-[#97A399] mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Minimum 6 characters"
                    className="w-full px-3.5 py-2.5 pr-10 rounded-lg bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] text-sm focus:outline-none focus:ring-2 focus:ring-[#2F5E38]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-[#4E5A51] dark:text-[#97A399]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {mode === 'register' && (
                <div>
                  <label className="block text-xs font-medium text-[#4E5A51] dark:text-[#97A399] mb-1.5">
                    Security PIN (Optional, 4–6 digits for sensitive operations)
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#4E5A51] dark:text-[#97A399]" />
                    <input
                      type="password"
                      inputMode="numeric"
                      pattern="\d{4,6}"
                      maxLength={6}
                      value={pin}
                      onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                      placeholder="e.g. 2468"
                      className="w-full pl-9 pr-3.5 py-2.5 rounded-lg bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#2F5E38]"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 px-5 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] hover:bg-[#17371E] dark:hover:bg-[#3A7345] text-white text-sm font-semibold transition-colors disabled:opacity-50"
              >
                {loading
                  ? 'Authenticating...'
                  : mode === 'login'
                  ? 'Sign In to Dashboard'
                  : 'Create Account & Enter'}
              </button>
            </form>

            <div className="pt-4 border-t border-[#D7DFD8] dark:border-[#1F2921] flex items-center justify-between gap-4">
              <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">
                Opening this page on your Android phone?
              </div>
              <button
                type="button"
                onClick={onOpenCompanion}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium hover:bg-[#E7ECE6] dark:hover:bg-[#161D17] whitespace-nowrap shrink-0"
              >
                <Smartphone className="w-3.5 h-3.5 text-[#3E7B4A]" />
                Pair This Device
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
