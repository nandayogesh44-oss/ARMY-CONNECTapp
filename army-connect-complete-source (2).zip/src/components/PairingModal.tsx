import React, { useEffect, useState } from 'react';
import { Copy, Check, QrCode, RefreshCw, X } from 'lucide-react';
import { apiFetch } from '../lib/api';

interface PairingModalProps {
  open: boolean;
  onClose: () => void;
}

interface PairingData {
  code: string;
  token: string;
  serverUrl: string;
  companionUrl: string;
  qrDataUrl: string;
  expiresAt: number;
}

export function PairingModal({ open, onClose }: PairingModalProps) {
  const [data, setData] = useState<PairingData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  async function generateCode() {
    setLoading(true);
    setError('');
    try {
      const res = await apiFetch<PairingData>('/api/pairing/create', { method: 'POST' });
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to generate pairing QR');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (open) {
      generateCode();
    }
  }, [open]);

  if (!open) return null;

  function copyUrl() {
    if (!data) return;
    navigator.clipboard?.writeText(data.companionUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className="w-full max-w-md rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-6 space-y-5">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <QrCode className="w-5 h-5 text-[#3E7B4A]" />
            <h3 className="font-display text-lg font-bold">Pair Android Device</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close pairing dialog"
            className="p-1.5 rounded-lg hover:bg-[#E7ECE6] dark:hover:bg-[#161D17]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
          Open ARMY CONNECT on your Android device and scan this QR code, or enter the 6-digit
          pairing code below. Expires in 10 minutes.
        </p>

        {error && (
          <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-sm text-red-600 dark:text-red-300">
            {error}
          </div>
        )}

        {loading && !data ? (
          <div className="h-64 rounded-lg bg-[#E7ECE6] dark:bg-[#161D17] animate-pulse" />
        ) : (
          data && (
            <div className="space-y-4">
              <div className="flex flex-col items-center p-4 rounded-xl bg-[#F4F6F3] border border-[#D7DFD8]">
                <img
                  src={data.qrDataUrl}
                  alt="Device pairing QR code"
                  className="w-56 h-56 rounded-lg"
                />
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921]">
                <div>
                  <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">6-Digit Pairing Code</div>
                  <div className="font-mono text-2xl font-bold tracking-widest mt-0.5">{data.code}</div>
                </div>
                <button
                  type="button"
                  onClick={generateCode}
                  disabled={loading}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium hover:bg-[#E7ECE6] dark:hover:bg-[#161D17]"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
              </div>

              <div className="space-y-1.5">
                <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">
                  Or open this link on your mobile browser to connect directly:
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={data.companionUrl}
                    className="flex-1 px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-mono truncate"
                  />
                  <button
                    type="button"
                    onClick={copyUrl}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-medium whitespace-nowrap"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>
                </div>
              </div>
            </div>
          )
        )}
      </div>
    </div>
  );
}
