import React, { useState } from 'react';
import { AlertCircle, CheckCircle2, Download, Loader2 } from 'lucide-react';
import { apiUrl, formatBytes } from '../lib/api';

interface SourceZipDownloadButtonProps {
  variant?: 'hero' | 'compact';
  className?: string;
}

const SOURCE_ZIP_URL = apiUrl('/downloads/army-connect-source.zip');
const SOURCE_ZIP_FILENAME = 'army-connect-complete-source.zip';

export function SourceZipDownloadButton({
  variant = 'hero',
  className = '',
}: SourceZipDownloadButtonProps) {
  const [status, setStatus] = useState<'idle' | 'downloading' | 'done' | 'error'>('idle');
  const [receivedBytes, setReceivedBytes] = useState(0);
  const [totalBytes, setTotalBytes] = useState(0);
  const [errorMsg, setErrorMsg] = useState('');

  const percent =
    totalBytes > 0 ? Math.min(100, Math.round((receivedBytes / totalBytes) * 100)) : 0;

  async function handleDownload() {
    if (status === 'downloading') return;
    setStatus('downloading');
    setReceivedBytes(0);
    setTotalBytes(0);
    setErrorMsg('');

    try {
      const response = await fetch(SOURCE_ZIP_URL, {
        method: 'GET',
        cache: 'no-store',
      });

      if (!response.ok) {
        throw new Error(`Download failed (HTTP ${response.status})`);
      }

      const contentLengthHeader = response.headers.get('content-length');
      const expectedTotal = contentLengthHeader ? Number(contentLengthHeader) : 0;
      if (expectedTotal > 0) {
        setTotalBytes(expectedTotal);
      }

      const chunks: Uint8Array[] = [];
      let received = 0;

      if (response.body) {
        const reader = response.body.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            chunks.push(value);
            received += value.byteLength;
            setReceivedBytes(received);
          }
        }
      } else {
        const buf = new Uint8Array(await response.arrayBuffer());
        chunks.push(buf);
        received = buf.byteLength;
        setReceivedBytes(received);
      }

      if (received < 4) {
        throw new Error('Downloaded archive was empty.');
      }

      // Verify ZIP magic header ('PK')
      const firstChunk = chunks[0];
      if (firstChunk[0] !== 0x50 || firstChunk[1] !== 0x4b) {
        throw new Error('Server returned an invalid ZIP archive.');
      }

      const blobParts: BlobPart[] = chunks.map((chunk) => {
        const copy = new Uint8Array(chunk.byteLength);
        copy.set(chunk);
        return copy.buffer;
      });
      const blob = new Blob(blobParts, { type: 'application/zip' });
      const blobUrl = URL.createObjectURL(blob);

      const anchor = document.createElement('a');
      anchor.href = blobUrl;
      anchor.download = SOURCE_ZIP_FILENAME;
      anchor.rel = 'noopener';
      anchor.style.display = 'none';
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();

      // Android Chrome requires keeping the blob URL alive briefly while handing off to DownloadManager
      window.setTimeout(() => {
        URL.revokeObjectURL(blobUrl);
      }, 15000);

      setTotalBytes((prev) => (prev > 0 ? prev : received));
      setStatus('done');
    } catch (err) {
      setStatus('error');
      setErrorMsg(
        err instanceof Error ? err.message : 'Unable to download Android source ZIP.'
      );
    }
  }

  const isHero = variant === 'hero';

  return (
    <div className={`space-y-2.5 ${className}`}>
      <button
        type="button"
        onClick={handleDownload}
        disabled={status === 'downloading'}
        className={
          isHero
            ? 'inline-flex items-center justify-center gap-2.5 px-5 py-3 rounded-lg bg-[#2F5E38] hover:bg-[#3A7345] active:bg-[#254C2D] text-white text-sm font-display font-bold tracking-wide border border-[#4D8B58]/60 shadow-lg shadow-black/40 transition-colors disabled:opacity-70 cursor-pointer'
            : 'inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] hover:bg-[#17371E] dark:hover:bg-[#3A7345] text-white text-xs sm:text-sm font-semibold tracking-wide transition-colors disabled:opacity-70 whitespace-nowrap shrink-0 cursor-pointer'
        }
      >
        {status === 'downloading' ? (
          <Loader2 className="w-4 h-4 animate-spin shrink-0" />
        ) : (
          <Download className="w-4 h-4 shrink-0" />
        )}
        <span>
          {status === 'downloading'
            ? totalBytes > 0
              ? `DOWNLOADING ZIP (${percent}%)`
              : `DOWNLOADING ZIP (${formatBytes(receivedBytes)})`
            : 'DOWNLOAD ANDROID SOURCE ZIP'}
        </span>
      </button>

      {status === 'downloading' && (
        <div
          className={`space-y-1.5 ${
            isHero ? 'max-w-sm text-[#BAC7BC]' : 'max-w-xs text-[#4E5A51] dark:text-[#97A399]'
          }`}
          role="status"
          aria-live="polite"
        >
          <div className="w-full h-2 rounded-full bg-black/30 dark:bg-black/50 overflow-hidden border border-white/10">
            <div
              className="h-full bg-[#4ADE80] transition-all duration-150"
              style={{ width: `${totalBytes > 0 ? percent : 100}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-xs font-mono tabular-nums">
            <span>
              {formatBytes(receivedBytes)}
              {totalBytes > 0 ? ` / ${formatBytes(totalBytes)}` : ''}
            </span>
            <span>{totalBytes > 0 ? `${percent}%` : 'Streaming...'}</span>
          </div>
        </div>
      )}

      {status === 'done' && (
        <div
          className={`flex flex-wrap items-center gap-2 text-xs ${
            isHero ? 'text-[#86EFAC]' : 'text-[#16A34A] dark:text-[#4ADE80]'
          }`}
          role="status"
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>
            Saved {SOURCE_ZIP_FILENAME} ({formatBytes(receivedBytes)}).
          </span>
          <a
            href={SOURCE_ZIP_URL}
            download={SOURCE_ZIP_FILENAME}
            className="underline underline-offset-2 font-medium"
          >
            Tap here if Chrome blocked the popup
          </a>
        </div>
      )}

      {status === 'error' && (
        <div
          role="alert"
          className={`p-3 rounded-lg bg-red-500/15 border border-red-500/40 text-xs space-y-1.5 max-w-md ${
            isHero ? 'text-red-200' : 'text-red-700 dark:text-red-300'
          }`}
        >
          <div className="flex items-center gap-2 font-medium">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleDownload}
              className="underline underline-offset-2 font-semibold"
            >
              Retry Download
            </button>
            <a
              href={SOURCE_ZIP_URL}
              download={SOURCE_ZIP_FILENAME}
              className="underline underline-offset-2"
            >
              Direct Browser Link
            </a>
          </div>
        </div>
      )}
    </div>
  );
}
