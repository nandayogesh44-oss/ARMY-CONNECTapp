import React, { useState } from 'react';
import { Lock, X } from 'lucide-react';
import { apiFetch } from '../lib/api';

interface PinPromptModalProps {
  open: boolean;
  actionLabel: string;
  onSuccess: () => void;
  onCancel: () => void;
}

export function PinPromptModal({ open, actionLabel, onSuccess, onCancel }: PinPromptModalProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!open) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await apiFetch('/api/auth/pin/verify', {
        method: 'POST',
        body: JSON.stringify({ pin }),
      });
      setPin('');
      onSuccess();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid PIN');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className="w-full max-w-sm rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#3E7B4A]" />
            <h3 className="font-display text-base font-bold">Security PIN Required</h3>
          </div>
          <button
            type="button"
            onClick={onCancel}
            aria-label="Cancel"
            className="p-1 rounded hover:bg-[#E7ECE6] dark:hover:bg-[#161D17]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
          Enter your security PIN to authorize: <span className="font-medium text-[#111713] dark:text-[#EDF2EE]">{actionLabel}</span>.
        </p>
        {error && (
          <div className="p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-600 dark:text-red-300">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="password"
            inputMode="numeric"
            autoFocus
            maxLength={6}
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
            placeholder="Enter 4–6 digit PIN"
            className="w-full px-3.5 py-2.5 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] font-mono text-center text-lg tracking-widest focus:outline-none focus:ring-2 focus:ring-[#2F5E38]"
          />
          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-sm font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || pin.length < 4}
              className="px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-sm font-semibold disabled:opacity-50"
            >
              {loading ? 'Verifying...' : 'Verify PIN'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
