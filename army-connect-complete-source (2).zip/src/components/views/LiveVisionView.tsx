import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  Download,
  Flashlight,
  Maximize2,
  Monitor,
  RefreshCw,
  Square,
} from 'lucide-react';
import { apiFetch } from '../../lib/api';
import {
  DEFAULT_ICE_CONFIG,
  describeTransportMode,
  inspectPeerConnectionStats,
} from '../../lib/webrtcPeer';
import type { Device, WebRtcIceConfig, WebRtcStatsSnapshot } from '../../types';

interface LiveVisionViewProps {
  device: Device | null;
  cameraFrame: string | null;
  screenFrame: string | null;
  onCommand: (deviceId: string, command: string, payload?: Record<string, unknown>) => Promise<void>;
  onSendSignal: (msg: Record<string, unknown>) => void;
  requirePinCheck: (label: string, action: () => void) => void;
}

export function LiveVisionView({
  device,
  cameraFrame,
  screenFrame,
  onCommand,
  onSendSignal,
  requirePinCheck,
}: LiveVisionViewProps) {
  const [mode, setMode] = useState<'camera' | 'screen'>('camera');
  const [streaming, setStreaming] = useState(false);
  const [flashOn, setFlashOn] = useState(false);
  const [iceConfig, setIceConfig] = useState<WebRtcIceConfig>(DEFAULT_ICE_CONFIG);
  const [webrtcActive, setWebrtcActive] = useState(false);
  const [rtcStats, setRtcStats] = useState<WebRtcStatsSnapshot | null>(null);

  const viewerRef = useRef<HTMLDivElement | null>(null);
  const webrtcVideoRef = useRef<HTMLVideoElement | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const iceConfigRef = useRef<WebRtcIceConfig>(iceConfig);
  iceConfigRef.current = iceConfig;

  function closePeer() {
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    if (webrtcVideoRef.current) {
      webrtcVideoRef.current.srcObject = null;
    }
    setWebrtcActive(false);
    setRtcStats(null);
  }

  useEffect(() => {
    apiFetch<WebRtcIceConfig>('/api/webrtc/ice-servers')
      .then((cfg) => {
        if (Array.isArray(cfg.iceServers) && cfg.iceServers.length > 0) {
          setIceConfig(cfg);
        }
      })
      .catch(() => {
        // Keep public STUN fallback silently
      });
  }, [device?.id]);

  useEffect(() => {
    closePeer();
    setStreaming(false);
  }, [device?.id]);

  useEffect(() => {
    if (!webrtcActive || !pcRef.current) return;
    const poll = () => {
      if (pcRef.current) {
        inspectPeerConnectionStats(pcRef.current).then(setRtcStats);
      }
    };
    poll();
    const timer = window.setInterval(poll, 2000);
    return () => window.clearInterval(timer);
  }, [webrtcActive]);

  useEffect(() => {
    if (!device) return;

    const handleSignal = async (ev: Event) => {
      const msg = (ev as CustomEvent<Record<string, unknown>>).detail;
      if (!msg || msg.deviceId !== device.id || msg.channel === 'data') return;

      if (msg.type === 'webrtc:offer' && msg.sdp) {
        closePeer();
        const pc = new RTCPeerConnection({
          iceServers: iceConfigRef.current.iceServers,
          iceCandidatePoolSize: 4,
        });
        pcRef.current = pc;

        pc.onicecandidate = (e) => {
          if (e.candidate) {
            onSendSignal({
              type: 'webrtc:ice',
              channel: 'media',
              deviceId: device.id,
              candidate: e.candidate.toJSON(),
            });
          }
        };

        pc.ontrack = (e) => {
          const stream = e.streams[0];
          if (stream && webrtcVideoRef.current) {
            webrtcVideoRef.current.srcObject = stream;
            webrtcVideoRef.current.play().catch(() => {});
            setWebrtcActive(true);
            setStreaming(true);
            inspectPeerConnectionStats(pc).then(setRtcStats);
          }
        };

        pc.onconnectionstatechange = () => {
          if (pc.connectionState === 'connected') {
            inspectPeerConnectionStats(pc).then(setRtcStats);
          } else if (pc.connectionState === 'disconnected') {
            onSendSignal({ type: 'webrtc:restart', channel: 'media', deviceId: device.id });
          } else if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
            setWebrtcActive(false);
            setRtcStats(null);
          }
        };

        try {
          await pc.setRemoteDescription(
            new RTCSessionDescription(msg.sdp as RTCSessionDescriptionInit)
          );
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          onSendSignal({
            type: 'webrtc:answer',
            channel: 'media',
            deviceId: device.id,
            sdp: pc.localDescription,
          });
        } catch {
          closePeer();
        }
      } else if (msg.type === 'webrtc:ice' && msg.candidate && pcRef.current) {
        try {
          await pcRef.current.addIceCandidate(
            new RTCIceCandidate(msg.candidate as RTCIceCandidateInit)
          );
        } catch {
          // Ignore stale ICE candidates
        }
      }
    };

    window.addEventListener('army-connect:webrtc-signal', handleSignal);
    return () => {
      window.removeEventListener('army-connect:webrtc-signal', handleSignal);
    };
  }, [device?.id, onSendSignal]);

  if (!device) {
    return (
      <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-10 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
        Select a paired device to access Remote Camera and Screen Mirroring.
      </div>
    );
  }

  const activeFrame = mode === 'camera' ? cameraFrame : screenFrame;
  const transportLabel = webrtcActive
    ? rtcStats
      ? `${describeTransportMode(rtcStats.transportMode)}${rtcStats.rttMs ? ` · ${rtcStats.rttMs} ms` : ''}`
      : 'WebRTC P2P Connected'
    : 'Encrypted WSS Relay';

  function startStream(targetMode: 'camera' | 'screen') {
    if (!device) return;
    requirePinCheck(
      targetMode === 'camera' ? 'Start Remote Camera Stream' : 'Start Screen Mirroring',
      async () => {
        setMode(targetMode);
        setStreaming(true);
        await onCommand(device.id, targetMode === 'camera' ? 'camera:start' : 'screen:start');
      }
    );
  }

  async function stopStream() {
    if (!device) return;
    setStreaming(false);
    closePeer();
    await onCommand(device.id, mode === 'camera' ? 'camera:stop' : 'screen:stop');
  }

  function saveSnapshot() {
    if (webrtcActive && webrtcVideoRef.current && webrtcVideoRef.current.videoWidth > 0) {
      const video = webrtcVideoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext('2d')?.drawImage(video, 0, 0);
      const a = document.createElement('a');
      a.href = canvas.toDataURL('image/jpeg', 0.9);
      a.download = `army-connect-${mode}-${Date.now()}.jpg`;
      a.click();
      return;
    }
    if (!activeFrame) return;
    const a = document.createElement('a');
    a.href = activeFrame;
    a.download = `army-connect-${mode}-${Date.now()}.jpg`;
    a.click();
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">
            Remote Camera &amp; Screen Mirroring
          </h1>
          <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
            Worldwide encrypted stream from {device.name} over WebRTC (STUN/TURN) or WSS relay.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-lg bg-[#E7ECE6] dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921]">
          <button
            type="button"
            onClick={() => setMode('camera')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap shrink-0 ${
              mode === 'camera'
                ? 'bg-white dark:bg-[#1E2A20] text-[#111713] dark:text-[#EDF2EE] shadow-sm'
                : 'text-[#4E5A51] dark:text-[#97A399]'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            Remote Camera
          </button>
          <button
            type="button"
            onClick={() => setMode('screen')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap shrink-0 ${
              mode === 'screen'
                ? 'bg-white dark:bg-[#1E2A20] text-[#111713] dark:text-[#EDF2EE] shadow-sm'
                : 'text-[#4E5A51] dark:text-[#97A399]'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            Screen Mirroring
          </button>
        </div>
      </div>

      <div
        ref={viewerRef}
        className="rounded-xl overflow-hidden bg-[#090B09] border border-[#1F2921]"
      >
        <div className="px-4 py-3 border-b border-[#1F2921] flex flex-wrap items-center justify-between gap-3 text-white">
          <div className="text-xs font-mono text-[#97A399] tabular-nums">
            {device.online ? 'Device Connected' : 'Device Offline'} ·{' '}
            {mode === 'camera' ? 'Camera Feed' : 'Screen Mirror'} ·{' '}
            {iceConfig.turnConfigured ? 'STUN + TURN' : 'Public STUN'} ·{' '}
            {transportLabel}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {!streaming ? (
              <button
                type="button"
                disabled={!device.online}
                onClick={() => startStream(mode)}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#2F5E38] hover:bg-[#3A7345] text-white text-xs font-semibold disabled:opacity-40 whitespace-nowrap shrink-0"
              >
                {mode === 'camera' ? <Camera className="w-3.5 h-3.5" /> : <Monitor className="w-3.5 h-3.5" />}
                {mode === 'camera' ? 'Start Camera' : 'Start Mirroring'}
              </button>
            ) : (
              <button
                type="button"
                onClick={stopStream}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-red-600 text-white text-xs font-semibold whitespace-nowrap shrink-0"
              >
                <Square className="w-3.5 h-3.5" />
                Stop Stream
              </button>
            )}

            {mode === 'camera' && (
              <>
                <button
                  type="button"
                  disabled={!device.online}
                  onClick={() => onCommand(device.id, 'camera:switch')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#1F2921] text-xs font-medium text-[#EDF2EE] disabled:opacity-40 whitespace-nowrap shrink-0"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Switch Lens
                </button>
                <button
                  type="button"
                  disabled={!device.online}
                  onClick={() => {
                    const next = !flashOn;
                    setFlashOn(next);
                    onCommand(device.id, 'camera:flash', { enabled: next });
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#1F2921] text-xs font-medium text-[#EDF2EE] disabled:opacity-40 whitespace-nowrap shrink-0"
                >
                  <Flashlight className="w-3.5 h-3.5" />
                  Flash {flashOn ? 'On' : 'Off'}
                </button>
              </>
            )}

            <button
              type="button"
              disabled={!activeFrame && !webrtcActive}
              onClick={saveSnapshot}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#1F2921] text-xs font-medium text-[#EDF2EE] disabled:opacity-40 whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              Snapshot
            </button>

            <button
              type="button"
              onClick={() => viewerRef.current?.requestFullscreen?.()}
              className="p-1.5 rounded-lg border border-[#1F2921] text-[#EDF2EE]"
              title="Fullscreen"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="aspect-video flex items-center justify-center bg-[#060806]">
          <video
            ref={webrtcVideoRef}
            autoPlay
            playsInline
            muted
            className={`w-full h-full object-contain ${webrtcActive ? 'block' : 'hidden'}`}
          />
          {!webrtcActive && activeFrame ? (
            <img
              src={activeFrame}
              alt={`${mode} live stream`}
              className="w-full h-full object-contain"
            />
          ) : !webrtcActive ? (
            <div className="text-center space-y-2 p-8">
              {mode === 'camera' ? (
                <Camera className="w-10 h-10 mx-auto text-[#3E7B4A]" />
              ) : (
                <Monitor className="w-10 h-10 mx-auto text-[#3E7B4A]" />
              )}
              <div className="text-sm font-medium text-[#EDF2EE]">
                {device.online
                  ? `Click "${mode === 'camera' ? 'Start Camera' : 'Start Mirroring'}" to begin live stream`
                  : 'Device is offline'}
              </div>
              <div className="text-xs text-[#97A399] max-w-md mx-auto">
                Traverses mobile data, different Wi-Fi networks, and firewalls automatically via
                WebRTC STUN/TURN with encrypted WebSocket fallback.
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
