import React from 'react';
import { ExternalLink, LocateFixed, MapPin, Volume2, VolumeX } from 'lucide-react';
import { formatRelativeTime } from '../../lib/api';
import type { Device } from '../../types';

interface LocationViewProps {
  device: Device | null;
  onCommand: (deviceId: string, command: string) => Promise<void>;
}

export function LocationView({ device, onCommand }: LocationViewProps) {
  if (!device) {
    return (
      <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-10 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
        Select a paired device to view GPS location and trigger Find My Device.
      </div>
    );
  }

  const hasCoords = device.latitude !== null && device.longitude !== null;
  const osmEmbedUrl = hasCoords
    ? `https://www.openstreetmap.org/export/embed.html?bbox=${device.longitude! - 0.01},${device.latitude! - 0.01},${device.longitude! + 0.01},${device.latitude! + 0.01}&layer=mapnik&marker=${device.latitude},${device.longitude}`
    : '';
  const osmLink = hasCoords
    ? `https://www.openstreetmap.org/?mlat=${device.latitude}&mlon=${device.longitude}#map=16/${device.latitude}/${device.longitude}`
    : '';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">
            Device Location &amp; Find My Device
          </h1>
          <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
            Locate {device.name} using GPS/network telemetry or sound a loud alarm.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={!device.online}
            onClick={() => onCommand(device.id, 'location:request')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold disabled:opacity-40"
          >
            <LocateFixed className="w-3.5 h-3.5" />
            Refresh Location
          </button>
          <button
            type="button"
            disabled={!device.online}
            onClick={() => onCommand(device.id, 'ring:start')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium disabled:opacity-40"
          >
            <Volume2 className="w-3.5 h-3.5 text-[#3E7B4A]" />
            Ring My Phone
          </button>
          <button
            type="button"
            disabled={!device.online}
            onClick={() => onCommand(device.id, 'ring:stop')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium disabled:opacity-40"
          >
            <VolumeX className="w-3.5 h-3.5" />
            Stop Alarm
          </button>
        </div>
      </div>

      <div className="grid sm:grid-cols-3 gap-4">
        <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-4">
          <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">Coordinates</div>
          <div className="font-mono text-sm font-semibold mt-1 tabular-nums">
            {hasCoords
              ? `${device.latitude!.toFixed(5)}, ${device.longitude!.toFixed(5)}`
              : 'Not reported yet'}
          </div>
        </div>
        <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-4">
          <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">GPS Accuracy</div>
          <div className="font-mono text-sm font-semibold mt-1 tabular-nums">
            {device.location_accuracy ? `±${Math.round(device.location_accuracy)} m` : '—'}
          </div>
        </div>
        <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-4">
          <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">Last Fix</div>
          <div className="font-mono text-sm font-semibold mt-1">
            {formatRelativeTime(device.location_updated_at)}
          </div>
        </div>
      </div>

      <div className="rounded-xl overflow-hidden bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921]">
        {hasCoords ? (
          <div>
            <iframe
              title="Device GPS Location Map"
              src={osmEmbedUrl}
              className="w-full h-[420px] border-0"
            />
            <div className="px-5 py-3 border-t border-[#D7DFD8] dark:border-[#1F2921] flex items-center justify-between text-xs">
              <span className="font-mono text-[#4E5A51] dark:text-[#97A399]">
                OpenStreetMap Free Coordinates View
              </span>
              <a
                href={osmLink}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 font-medium text-[#3E7B4A]"
              >
                Open Full Map
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        ) : (
          <div className="p-12 text-center space-y-2">
            <MapPin className="w-8 h-8 mx-auto text-[#3E7B4A]" />
            <div className="text-sm font-medium">No GPS Fix Received Yet</div>
            <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">
              Click &ldquo;Refresh Location&rdquo; while your device is online and Location permission is enabled.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
