import React from 'react';
import { Bell, CheckCheck, X } from 'lucide-react';
import type { Device, NotificationItem } from '../../types';

interface NotificationsViewProps {
  device: Device | null;
  notifications: NotificationItem[];
  onDismiss: (notifId: string) => void;
}

export function NotificationsView({
  device,
  notifications,
  onDismiss,
}: NotificationsViewProps) {
  if (!device) {
    return (
      <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-10 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
        Select a paired device to view synchronized notifications.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Notification Mirror</h1>
          <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
            Live notifications synced from {device.name}.
          </p>
        </div>
        {notifications.length > 0 && (
          <button
            type="button"
            onClick={() => onDismiss('all')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium hover:bg-[#E7ECE6] dark:hover:bg-[#161D17]"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            Clear All
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-10 text-center space-y-2">
          <Bell className="w-8 h-8 mx-auto text-[#3E7B4A]" />
          <div className="text-sm font-medium">No Active Notifications</div>
          <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">
            Incoming Android notifications appear here in real time once Notification Access is granted on your phone.
          </div>
        </div>
      ) : (
        <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] divide-y divide-[#D7DFD8] dark:divide-[#1F2921]">
          {notifications.map((n) => (
            <div key={n.id} className="p-4 flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs text-[#4E5A51] dark:text-[#97A399] font-mono">
                  {n.app_name} · {new Date(n.timestamp).toLocaleTimeString()}
                </div>
                <div className="font-medium text-sm">{n.title}</div>
                {n.text && (
                  <p className="text-sm text-[#4E5A51] dark:text-[#BAC7BC]">{n.text}</p>
                )}
              </div>
              <button
                type="button"
                onClick={() => onDismiss(n.id)}
                aria-label="Dismiss notification"
                className="p-1.5 rounded-lg hover:bg-[#E7ECE6] dark:hover:bg-[#161D17]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
