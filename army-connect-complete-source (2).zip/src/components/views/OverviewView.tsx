import React from 'react';
import {
  Activity,
  BatteryCharging,
  BatteryMedium,
  Check,
  HardDrive,
  MapPin,
  PhoneOff,
  QrCode,
  ShieldCheck,
  Smartphone,
  Volume2,
  VolumeX,
  Wifi,
  X,
} from 'lucide-react';
import { formatBytes, formatRelativeTime } from '../../lib/api';
import type { ActiveTab, ConnectionHistoryItem, Device, DeviceLatency } from '../../types';
import { SourceZipDownloadButton } from '../SourceZipDownloadButton';

interface OverviewViewProps {
  devices: Device[];
  selectedDevice: Device | null;
  history: ConnectionHistoryItem[];
  latencyByDevice: Record<string, DeviceLatency>;
  onSelectDevice: (id: string) => void;
  onPing: (id: string) => void;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  onDisconnect: (id: string) => void;
  onCommand: (deviceId: string, command: string) => void;
  onOpenPairing: () => void;
  onNavigate: (tab: ActiveTab) => void;
}

export function OverviewView({
  devices,
  selectedDevice,
  history,
  latencyByDevice,
  onSelectDevice,
  onPing,
  onApprove,
  onReject,
  onDisconnect,
  onCommand,
  onOpenPairing,
  onNavigate,
}: OverviewViewProps) {
  const pending = devices.filter((d) => !d.approved);
  const approved = devices.filter((d) => d.approved);

  return (
    <div className="space-y-8">
      {pending.length > 0 && (
        <section className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold">Pending Device Approval</h2>
            <span className="font-mono text-xs text-amber-700 dark:text-amber-300">
              {pending.length} awaiting consent
            </span>
          </div>
          <div className="divide-y divide-amber-500/20">
            {pending.map((dev) => (
              <div key={dev.id} className="py-3 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="font-medium text-sm">{dev.name}</div>
                  <div className="text-xs text-[#4E5A51] dark:text-[#97A399] font-mono">
                    {dev.manufacturer} {dev.model} · Android {dev.android_version} · E2EE {dev.e2ee_fingerprint}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onApprove(dev.id)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Approve Device
                  </button>
                  <button
                    type="button"
                    onClick={() => onReject(dev.id)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-red-500/40 text-red-600 dark:text-red-400 text-xs font-medium"
                  >
                    <X className="w-3.5 h-3.5" />
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight">Connected Devices</h1>
            <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
              Manage multiple Android devices, inspect telemetry, and issue real-time commands.
            </p>
          </div>
          <div className="flex flex-wrap items-start gap-2.5">
            <SourceZipDownloadButton variant="compact" />
            <button
              type="button"
              onClick={onOpenPairing}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] hover:bg-[#17371E] dark:hover:bg-[#3A7345] text-white text-sm font-semibold whitespace-nowrap shrink-0"
            >
              <QrCode className="w-4 h-4" />
              Pair New Device
            </button>
          </div>
        </div>

        {approved.length === 0 ? (
          <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-10 text-center space-y-4">
            <Smartphone className="w-10 h-10 mx-auto text-[#3E7B4A]" />
            <div className="space-y-1 max-w-md mx-auto">
              <h3 className="font-display text-lg font-bold">No Android Devices Paired Yet</h3>
              <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
                Pair your phone using the ARMY CONNECT Android app or open the Companion link on
                your mobile browser to test live telemetry immediately.
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenPairing}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-sm font-semibold"
            >
              <QrCode className="w-4 h-4" />
              Generate Pairing QR Code
            </button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
            {approved.map((dev) => {
              const isSelected = selectedDevice?.id === dev.id;
              const storagePct =
                dev.storage_total > 0
                  ? Math.min(100, Math.round((dev.storage_used / dev.storage_total) * 100))
                  : 0;
              return (
                <div
                  key={dev.id}
                  onClick={() => onSelectDevice(dev.id)}
                  className={`cursor-pointer rounded-xl bg-white dark:bg-[#111612] border p-5 space-y-4 transition-colors ${
                    isSelected
                      ? 'border-[#2F5E38] ring-1 ring-[#2F5E38]/40'
                      : 'border-[#D7DFD8] dark:border-[#1F2921] hover:border-[#3E7B4A]/50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="font-display text-base font-bold">{dev.name}</h3>
                      <div className="text-xs text-[#4E5A51] dark:text-[#97A399] mt-0.5">
                        {dev.manufacturer} {dev.model} · Android {dev.android_version}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs font-mono whitespace-nowrap">
                      <span
                        className={`w-2 h-2 rounded-full ${
                          dev.online ? 'bg-[#16A34A] animate-pulse' : 'bg-[#64748B]'
                        }`}
                      />
                      <span className={dev.online ? 'text-[#16A34A] dark:text-[#4ADE80]' : 'text-[#4E5A51] dark:text-[#97A399]'}>
                        {dev.online ? 'Online' : 'Offline'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-[#D7DFD8]/70 dark:border-[#1F2921]">
                    <div>
                      <div className="text-xs text-[#4E5A51] dark:text-[#97A399] flex items-center gap-1">
                        {dev.is_charging ? (
                          <BatteryCharging className="w-3.5 h-3.5 text-[#3E7B4A]" />
                        ) : (
                          <BatteryMedium className="w-3.5 h-3.5 text-[#3E7B4A]" />
                        )}
                        Battery
                      </div>
                      <div className="font-mono text-sm font-semibold mt-0.5 tabular-nums">
                        {dev.battery_level}%
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-[#4E5A51] dark:text-[#97A399] flex items-center gap-1">
                        <HardDrive className="w-3.5 h-3.5 text-[#3E7B4A]" />
                        Storage
                      </div>
                      <div className="font-mono text-sm font-semibold mt-0.5 tabular-nums">
                        {dev.storage_total > 0 ? `${storagePct}%` : '—'}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-[#4E5A51] dark:text-[#97A399] flex items-center gap-1">
                        <Wifi className="w-3.5 h-3.5 text-[#3E7B4A]" />
                        Network
                      </div>
                      <div className="font-mono text-sm font-semibold mt-0.5 truncate">
                        {dev.network_type || 'Unknown'}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-[#4E5A51] dark:text-[#97A399] flex items-center gap-1">
                        <Activity className="w-3.5 h-3.5 text-[#3E7B4A]" />
                        Latency
                      </div>
                      <div className="font-mono text-sm font-semibold mt-0.5 tabular-nums">
                        {latencyByDevice[dev.id]?.pinging
                          ? '...'
                          : latencyByDevice[dev.id]?.rttMs !== null &&
                            latencyByDevice[dev.id]?.rttMs !== undefined
                          ? `${latencyByDevice[dev.id].rttMs} ms`
                          : '—'}
                      </div>
                    </div>
                  </div>

                  <div className="text-xs font-mono text-[#4E5A51] dark:text-[#97A399] flex items-center justify-between gap-2 pt-1">
                    <span className="inline-flex items-center gap-1 truncate">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#3E7B4A] shrink-0" />
                      {dev.e2ee_fingerprint}
                    </span>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        disabled={!dev.online || latencyByDevice[dev.id]?.pinging}
                        onClick={(e) => {
                          e.stopPropagation();
                          onPing(dev.id);
                        }}
                        className="px-2 py-0.5 rounded border border-[#D7DFD8] dark:border-[#1F2921] hover:border-[#3E7B4A] text-[11px] font-medium text-[#111713] dark:text-[#EDF2EE] disabled:opacity-40"
                      >
                        {latencyByDevice[dev.id]?.pinging ? 'Pinging' : 'Ping'}
                      </button>
                      <span>Seen {formatRelativeTime(dev.last_seen)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {selectedDevice && selectedDevice.approved && (
        <section className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <h2 className="font-display text-lg font-bold">
                Selected Device: {selectedDevice.name}
              </h2>
              <p className="text-xs text-[#4E5A51] dark:text-[#97A399] font-mono">
                Remote IP {selectedDevice.ip_address || '—'} · Link {selectedDevice.network_type || 'Internet'} ·
                Wi-Fi {selectedDevice.wifi_ssid || 'N/A'} ·
                RAM {selectedDevice.ram_total > 0 ? `${formatBytes(selectedDevice.ram_used)} / ${formatBytes(selectedDevice.ram_total)}` : 'N/A'} ·
                Storage {selectedDevice.storage_total > 0 ? `${formatBytes(selectedDevice.storage_used)} / ${formatBytes(selectedDevice.storage_total)}` : 'N/A'}
              </p>
              <div className="text-xs font-mono flex flex-wrap items-center gap-2 pt-0.5">
                <Activity className="w-3.5 h-3.5 text-[#3E7B4A]" />
                {latencyByDevice[selectedDevice.id]?.pinging ? (
                  <span className="text-[#4E5A51] dark:text-[#97A399]">Measuring round-trip latency...</span>
                ) : latencyByDevice[selectedDevice.id]?.error ? (
                  <span className="text-red-600 dark:text-red-400">
                    Ping failed: {latencyByDevice[selectedDevice.id].error}
                  </span>
                ) : latencyByDevice[selectedDevice.id]?.rttMs !== null &&
                  latencyByDevice[selectedDevice.id]?.rttMs !== undefined ? (
                  <span className="tabular-nums text-[#16A34A] dark:text-[#4ADE80]">
                    Network Latency: {latencyByDevice[selectedDevice.id].rttMs} ms
                    {latencyByDevice[selectedDevice.id].serverDeviceMs !== null
                      ? ` (Device WS ${latencyByDevice[selectedDevice.id].serverDeviceMs} ms)`
                      : ''}
                    {latencyByDevice[selectedDevice.id].checkedAt
                      ? ` · Checked ${formatRelativeTime(latencyByDevice[selectedDevice.id].checkedAt!)}`
                      : ''}
                  </span>
                ) : (
                  <span className="text-[#4E5A51] dark:text-[#97A399]">
                    Network Latency: Not measured yet — click Ping
                  </span>
                )}
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={!selectedDevice.online || latencyByDevice[selectedDevice.id]?.pinging}
                onClick={() => onPing(selectedDevice.id)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-[#2F5E38] text-[#1E4627] dark:text-[#8FBC96] hover:bg-[#2F5E38]/10 text-xs font-semibold disabled:opacity-40"
              >
                <Activity className="w-3.5 h-3.5" />
                {latencyByDevice[selectedDevice.id]?.pinging ? 'Pinging...' : 'Ping'}
              </button>
              <button
                type="button"
                disabled={!selectedDevice.online}
                onClick={() => onCommand(selectedDevice.id, 'ring:start')}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold disabled:opacity-40"
              >
                <Volume2 className="w-3.5 h-3.5" />
                Ring Phone
              </button>
              <button
                type="button"
                disabled={!selectedDevice.online}
                onClick={() => onCommand(selectedDevice.id, 'ring:stop')}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium disabled:opacity-40"
              >
                <VolumeX className="w-3.5 h-3.5" />
                Stop Ring
              </button>
              <button
                type="button"
                onClick={() => onNavigate('location')}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium"
              >
                <MapPin className="w-3.5 h-3.5" />
                Locate Device
              </button>
              <button
                type="button"
                disabled={!selectedDevice.online}
                onClick={() => onDisconnect(selectedDevice.id)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-red-500/40 text-red-600 dark:text-red-400 text-xs font-medium disabled:opacity-40"
              >
                <PhoneOff className="w-3.5 h-3.5" />
                Disconnect
              </button>
            </div>
          </div>
        </section>
      )}

      <section className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] overflow-hidden">
        <div className="px-5 py-4 border-b border-[#D7DFD8] dark:border-[#1F2921] flex items-center justify-between">
          <h2 className="font-display text-base font-bold">Device Connection History</h2>
          <span className="text-xs font-mono text-[#4E5A51] dark:text-[#97A399]">
            {history.length} recent events
          </span>
        </div>
        {history.length === 0 ? (
          <div className="p-8 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
            No connection events recorded yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#F4F6F3] dark:bg-[#0D110E] text-xs text-[#4E5A51] dark:text-[#97A399]">
                <tr>
                  <th className="px-5 py-2.5 font-medium">Device</th>
                  <th className="px-5 py-2.5 font-medium">Event</th>
                  <th className="px-5 py-2.5 font-medium">Details</th>
                  <th className="px-5 py-2.5 font-medium">IP Address</th>
                  <th className="px-5 py-2.5 font-medium text-right">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D7DFD8] dark:divide-[#1F2921]">
                {history.slice(0, 20).map((item) => (
                  <tr key={item.id} className="hover:bg-[#F4F6F3]/60 dark:hover:bg-[#161D17]">
                    <td className="px-5 py-2.5 font-medium">{item.device_name}</td>
                    <td className="px-5 py-2.5 font-mono text-xs">{item.event}</td>
                    <td className="px-5 py-2.5 text-xs text-[#4E5A51] dark:text-[#97A399]">
                      {item.details}
                    </td>
                    <td className="px-5 py-2.5 font-mono text-xs">{item.ip_address || '—'}</td>
                    <td className="px-5 py-2.5 font-mono text-xs text-right tabular-nums">
                      {new Date(item.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
