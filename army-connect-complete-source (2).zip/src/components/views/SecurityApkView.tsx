import React, { useEffect, useState } from 'react';
import {
  Activity,
  CheckCircle2,
  Download,
  Globe,
  KeyRound,
  LogOut,
  Server,
  Shield,
  Smartphone,
  Trash2,
} from 'lucide-react';
import { apiFetch, apiUrl, formatBytes } from '../../lib/api';
import { testIceConnectivity } from '../../lib/webrtcPeer';
import type {
  Device,
  DevicePermissions,
  DownloadArtifact,
  IceProbeResult,
  NetworkDiagnostics,
  ServerSettings,
  SessionItem,
  User,
} from '../../types';

interface SecurityApkViewProps {
  user: User;
  device: Device | null;
  onUpdatePermissions: (deviceId: string, permissions: DevicePermissions) => Promise<void>;
  onUnpairDevice: (deviceId: string) => Promise<void>;
  onUserUpdated: (user: User) => void;
}

export function SecurityApkView({
  user,
  device,
  onUpdatePermissions,
  onUnpairDevice,
  onUserUpdated,
}: SecurityApkViewProps) {
  const [sessions, setSessions] = useState<SessionItem[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState('');
  const [settings, setSettings] = useState<ServerSettings | null>(null);
  const [downloads, setDownloads] = useState<DownloadArtifact[]>([]);
  const [diagnostics, setDiagnostics] = useState<NetworkDiagnostics | null>(null);
  const [iceProbe, setIceProbe] = useState<IceProbeResult | null>(null);
  const [probingIce, setProbingIce] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  async function loadAll() {
    const [sess, sett, dl, diag] = await Promise.all([
      apiFetch<{ sessions: SessionItem[]; currentSessionId: string }>('/api/auth/sessions'),
      apiFetch<{ settings: ServerSettings }>('/api/settings'),
      apiFetch<{ downloads: DownloadArtifact[] }>('/api/downloads/info'),
      apiFetch<NetworkDiagnostics>(
        `/api/network/diagnostics${device ? `?deviceId=${encodeURIComponent(device.id)}` : ''}`
      ),
    ]);
    setSessions(sess.sessions);
    setCurrentSessionId(sess.currentSessionId);
    setSettings(sett.settings);
    setDownloads(dl.downloads);
    setDiagnostics(diag);
  }

  useEffect(() => {
    loadAll();
  }, [device?.id]);

  async function handleProbeIce() {
    if (!diagnostics) return;
    setProbingIce(true);
    try {
      const result = await testIceConnectivity(diagnostics.iceConfig.iceServers);
      setIceProbe(result);
    } finally {
      setProbingIce(false);
    }
  }

  async function handleSetPin(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setNotice('');
    try {
      await apiFetch('/api/auth/pin/set', {
        method: 'POST',
        body: JSON.stringify({ pin: newPin }),
      });
      onUserUpdated({ ...user, hasPin: true });
      setNewPin('');
      setNotice('Security PIN updated.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save PIN');
    }
  }

  async function handleSaveSettings(e: React.FormEvent) {
    e.preventDefault();
    if (!settings) return;
    setError('');
    setNotice('');
    await apiFetch('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    });
    setNotice('Self-hosted network and security settings saved.');
  }

  async function handleRevokeSession(id: string) {
    await apiFetch(`/api/auth/sessions/${id}`, { method: 'DELETE' });
    loadAll();
  }

  const permissionLabels: Array<{ key: keyof DevicePermissions; label: string }> = [
    { key: 'files', label: 'Remote File Manager & Storage' },
    { key: 'media', label: 'Photos, Videos & Audio Browser' },
    { key: 'contacts', label: 'Contacts Synchronization' },
    { key: 'sms', label: 'SMS Reading & Sending' },
    { key: 'calls', label: 'Call History Access' },
    { key: 'notifications', label: 'Notification Mirroring' },
    { key: 'camera', label: 'Remote Camera Access' },
    { key: 'screen', label: 'Screen Mirroring' },
    { key: 'location', label: 'GPS Location & Find My Device' },
    { key: 'clipboard', label: 'Clipboard Synchronization' },
    { key: 'ring', label: 'Ring My Phone Alarm' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">
          Security, Self-Hosting &amp; Android APK
        </h1>
        <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
          Download the complete source archive and Android project, manage device permissions, PIN
          lock, active sessions, and STUN/TURN configuration.
        </p>
      </div>

      {notice && (
        <div className="p-3 rounded-lg bg-[#2F5E38]/15 border border-[#2F5E38]/40 text-sm flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-[#3E7B4A]" />
          {notice}
        </div>
      )}
      {error && (
        <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-sm text-red-600 dark:text-red-300">
          {error}
        </div>
      )}

      <section className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-6 space-y-5">
        <div className="flex items-center gap-2.5">
          <Smartphone className="w-5 h-5 text-[#3E7B4A]" />
          <h2 className="font-display text-lg font-bold">Android App &amp; Complete Source Code</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {downloads.map((item) => {
            const isSource = item.filename.includes('source');
            const label = isSource
              ? 'Complete Source + Android Project'
              : item.filename.includes('debug')
              ? 'Debug APK'
              : 'Release APK (Signed)';
            return (
              <div
                key={item.filename}
                className="p-4 rounded-xl bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] flex flex-col justify-between gap-4"
              >
                <div>
                  <div className="font-medium text-sm">{label}</div>
                  <div className="font-mono text-xs text-[#4E5A51] dark:text-[#97A399] mt-1">
                    {item.filename}
                    {item.size > 0 ? ` · ${formatBytes(item.size)}` : ''}
                  </div>
                </div>
                {item.available ? (
                  <a
                    href={apiUrl(item.url)}
                    download={item.filename}
                    className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download
                  </a>
                ) : (
                  <span className="text-xs text-[#4E5A51] dark:text-[#97A399]">
                    Build via included GitHub Actions or build script
                  </span>
                )}
              </div>
            );
          })}
        </div>

        <div className="text-xs text-[#4E5A51] dark:text-[#97A399] space-y-1.5 pt-2 border-t border-[#D7DFD8] dark:border-[#1F2921]">
          <div className="font-semibold text-[#111713] dark:text-[#EDF2EE]">
            Zero-Coding APK Build &amp; Installation Guide:
          </div>
          <p>1. Click &ldquo;Download&rdquo; on Complete Source + Android Project above to get the full zip.</p>
          <p>2. Upload the folder to a free GitHub repository — the included GitHub Actions workflow builds both Debug and Release APKs automatically in ~3 minutes with zero coding.</p>
          <p>3. Or open the included android-app folder in Android Studio and click Build &rarr; Build APK(s), then install on your phone and scan the QR code.</p>
        </div>
      </section>

      <section className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Globe className="w-5 h-5 text-[#3E7B4A]" />
            <h2 className="font-display text-lg font-bold">
              Worldwide Remote Access &amp; NAT Traversal
            </h2>
          </div>
          <button
            type="button"
            disabled={probingIce || !diagnostics}
            onClick={handleProbeIce}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold disabled:opacity-40 whitespace-nowrap shrink-0"
          >
            <Activity className="w-3.5 h-3.5" />
            {probingIce ? 'Testing STUN / TURN...' : 'Test STUN / TURN Connectivity'}
          </button>
        </div>

        <p className="text-xs text-[#4E5A51] dark:text-[#97A399]">
          Connect phones and computers across different Wi-Fi networks, 4G/5G mobile data, and ISPs
          worldwide using HTTPS + Encrypted WebSocket signaling (WSS) and WebRTC STUN/TURN.
        </p>

        {diagnostics && (
          <div className="grid sm:grid-cols-3 gap-4 pt-2 border-t border-[#D7DFD8] dark:border-[#1F2921]">
            <div>
              <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">Public Relay URL</div>
              <div className="font-mono text-xs font-semibold mt-1 break-all">
                {diagnostics.publicUrl}
              </div>
            </div>
            <div>
              <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">Signaling Endpoint</div>
              <div className="font-mono text-xs font-semibold mt-1 break-all">
                {diagnostics.wsEndpoint} ({diagnostics.isHttps ? 'TLS Encrypted' : 'Local HTTP'})
              </div>
            </div>
            <div>
              <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">ICE Traversal Mode</div>
              <div className="font-mono text-xs font-semibold mt-1">
                {diagnostics.iceConfig.turnConfigured
                  ? 'STUN + Private TURN Relay'
                  : 'Public STUN + Encrypted WSS Relay'}
              </div>
            </div>
          </div>
        )}

        {iceProbe && (
          <div className="p-3.5 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-mono space-y-1 tabular-nums">
            <div className="font-semibold text-[#111713] dark:text-[#EDF2EE]">
              {iceProbe.error
                ? `ICE Probe Error: ${iceProbe.error}`
                : `ICE Probe Complete (${iceProbe.gatheredMs} ms · ${iceProbe.candidateCount} candidates)`}
            </div>
            <div className="text-[#4E5A51] dark:text-[#97A399]">
              Local Host: {iceProbe.hostFound ? 'Yes' : 'No'} · Public STUN NAT Reflex:{' '}
              {iceProbe.stunFound ? `Yes (${iceProbe.publicReflexIp || 'Resolved'})` : 'Blocked'} ·
              TURN Relay: {iceProbe.turnRelayFound ? 'Verified' : 'Not configured (Optional)'}
            </div>
          </div>
        )}

        <div className="overflow-x-auto pt-2 border-t border-[#D7DFD8] dark:border-[#1F2921]">
          <table className="w-full text-left text-xs">
            <thead className="text-[#4E5A51] dark:text-[#97A399]">
              <tr>
                <th className="py-2 pr-4 font-medium">Hosting / Traversal Tier</th>
                <th className="py-2 pr-4 font-medium">How It Works</th>
                <th className="py-2 font-medium text-right">Estimated Cost</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D7DFD8] dark:divide-[#1F2921]">
              <tr>
                <td className="py-2.5 pr-4 font-medium">Home PC + Cloudflare Tunnel + Public STUN</td>
                <td className="py-2.5 pr-4 text-[#4E5A51] dark:text-[#97A399]">
                  Zero port-forwarding HTTPS/WSS tunnel on your PC + free Google/Cloudflare STUN
                </td>
                <td className="py-2.5 font-mono text-right tabular-nums">$0 / month</td>
              </tr>
              <tr>
                <td className="py-2.5 pr-4 font-medium">Always-On VPS + Docker Caddy + Coturn TURN</td>
                <td className="py-2.5 pr-4 text-[#4E5A51] dark:text-[#97A399]">
                  24/7 worldwide access + private TURN relay for strict 4G/5G carrier CGNATs
                </td>
                <td className="py-2.5 font-mono text-right tabular-nums">$0–$6 / month</td>
              </tr>
              <tr>
                <td className="py-2.5 pr-4 font-medium">Managed Cloud TURN Fallback (Optional)</td>
                <td className="py-2.5 pr-4 text-[#4E5A51] dark:text-[#97A399]">
                  Metered / Cloudflare Calls free starter quota (5–50 GB/mo), only for blocked P2P video
                </td>
                <td className="py-2.5 font-mono text-right tabular-nums">$0 free tier</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <div className="grid lg:grid-cols-2 gap-6">
        <section className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-6 space-y-4">
          <div className="flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-[#3E7B4A]" />
            <h2 className="font-display text-lg font-bold">Security PIN Protection</h2>
          </div>
          <p className="text-xs text-[#4E5A51] dark:text-[#97A399]">
            Current status: {user.hasPin ? 'PIN configured' : 'No PIN set yet'}. When enabled in
            Security Policy, sensitive operations (Camera, Screen Mirror, SMS) require this PIN.
          </p>
          <form onSubmit={handleSetPin} className="flex gap-2">
            <input
              type="password"
              inputMode="numeric"
              maxLength={6}
              value={newPin}
              onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
              placeholder="New 4–6 digit PIN"
              className="flex-1 px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] font-mono text-sm"
            />
            <button
              type="submit"
              disabled={newPin.length < 4}
              className="px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold disabled:opacity-40"
            >
              Save PIN
            </button>
          </form>
        </section>

        {device && (
          <section className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-[#3E7B4A]" />
                <h2 className="font-display text-lg font-bold">
                  Permissions: {device.name}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onUnpairDevice(device.id)}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-red-500/40 text-red-600 dark:text-red-400 text-xs font-medium"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Unpair
              </button>
            </div>
            <div className="grid sm:grid-cols-2 gap-2.5">
              {permissionLabels.map((p) => (
                <label
                  key={p.key}
                  className="flex items-center justify-between gap-2 p-2.5 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-xs cursor-pointer"
                >
                  <span>{p.label}</span>
                  <input
                    type="checkbox"
                    checked={Boolean(device.permissions?.[p.key])}
                    onChange={(e) =>
                      onUpdatePermissions(device.id, {
                        ...device.permissions,
                        [p.key]: e.target.checked,
                      })
                    }
                    className="accent-[#2F5E38]"
                  />
                </label>
              ))}
            </div>
          </section>
        )}
      </div>

      {settings && (
        <form
          onSubmit={handleSaveSettings}
          className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-6 space-y-5"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Server className="w-5 h-5 text-[#3E7B4A]" />
              <h2 className="font-display text-lg font-bold">
                Self-Hosting, WebRTC NAT Traversal &amp; Session Policy
              </h2>
            </div>
            <span className="text-xs font-mono text-[#4E5A51] dark:text-[#97A399]">
              {settings.turnUrl || settings.envTurnConfigured
                ? 'Mode: STUN + Optional TURN Relay'
                : 'Mode: Public STUN Fallback (TURN optional)'}
            </span>
          </div>

          <div className="p-3 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-xs text-[#4E5A51] dark:text-[#97A399]">
            External TURN credentials are <strong className="text-[#111713] dark:text-[#EDF2EE]">optional</strong>.
            During development or standard connections, WebRTC uses the public STUN servers below with encrypted WebSocket relay fallback. Add a self-hosted Coturn TURN server only if strict cellular firewalls block direct P2P video.
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-[#4E5A51] dark:text-[#97A399] mb-1">
                STUN Servers (comma-separated, public fallback)
              </label>
              <input
                type="text"
                value={settings.stunUrls.join(', ')}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    stunUrls: e.target.value
                      .split(',')
                      .map((s) => s.trim())
                      .filter(Boolean),
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] font-mono text-xs"
              />
            </div>

            <div>
              <label className="block text-xs text-[#4E5A51] dark:text-[#97A399] mb-1">
                Optional TURN Relay URL (Coturn)
              </label>
              <input
                type="text"
                value={settings.turnUrl}
                onChange={(e) => setSettings({ ...settings, turnUrl: e.target.value })}
                placeholder="Optional — leave blank to use public STUN"
                className="w-full px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] font-mono text-xs"
              />
            </div>

            <div>
              <label className="block text-xs text-[#4E5A51] dark:text-[#97A399] mb-1">
                Optional TURN Username
              </label>
              <input
                type="text"
                value={settings.turnUsername}
                onChange={(e) => setSettings({ ...settings, turnUsername: e.target.value })}
                placeholder="Optional"
                className="w-full px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] font-mono text-xs"
              />
            </div>

            <div>
              <label className="block text-xs text-[#4E5A51] dark:text-[#97A399] mb-1">
                Optional TURN Credential {settings.hasTurnCredential ? '(stored securely on server)' : ''}
              </label>
              <div className="flex gap-2">
                <input
                  type="password"
                  value={settings.turnCredential}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      turnCredential: e.target.value,
                      clearTurnCredential: false,
                    })
                  }
                  placeholder={settings.hasTurnCredential ? 'Leave blank to keep stored secret' : 'Optional'}
                  className="flex-1 px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] font-mono text-xs"
                />
                {settings.hasTurnCredential && (
                  <button
                    type="button"
                    onClick={async () => {
                      await apiFetch('/api/settings', {
                        method: 'PUT',
                        body: JSON.stringify({ ...settings, turnCredential: '', clearTurnCredential: true }),
                      });
                      setNotice('Stored TURN credential cleared.');
                      loadAll();
                    }}
                    className="px-3 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>

            <div>
              <label className="block text-xs text-[#4E5A51] dark:text-[#97A399] mb-1">
                Session Expiration (Hours)
              </label>
              <input
                type="number"
                min={1}
                max={720}
                value={settings.sessionTtlHours}
                onChange={(e) =>
                  setSettings({ ...settings, sessionTtlHours: Number(e.target.value || 168) })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] font-mono text-xs"
              />
            </div>

            <div className="flex flex-col justify-center gap-2 pt-3">
              <label className="inline-flex items-center gap-2 text-xs cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.requireDeviceApproval}
                  onChange={(e) =>
                    setSettings({ ...settings, requireDeviceApproval: e.target.checked })
                  }
                  className="accent-[#2F5E38]"
                />
                Require manual approval before newly paired devices become active
              </label>
              <label className="inline-flex items-center gap-2 text-xs cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.requirePinSensitive}
                  onChange={(e) =>
                    setSettings({ ...settings, requirePinSensitive: e.target.checked })
                  }
                  className="accent-[#2F5E38]"
                />
                Require Security PIN before Remote Camera, Screen Mirroring, or Sending SMS
              </label>
            </div>
          </div>

          <button
            type="submit"
            className="px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold"
          >
            Save Configuration
          </button>
        </form>
      )}

      <section className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] overflow-hidden">
        <div className="px-5 py-4 border-b border-[#D7DFD8] dark:border-[#1F2921] font-display text-base font-bold">
          Active Login Sessions
        </div>
        <div className="divide-y divide-[#D7DFD8] dark:divide-[#1F2921]">
          {sessions.map((s) => (
            <div key={s.id} className="px-5 py-3 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="text-sm font-medium">
                  {s.label} {s.id === currentSessionId ? '(Current Session)' : ''}
                </div>
                <div className="text-xs font-mono text-[#4E5A51] dark:text-[#97A399]">
                  IP {s.ip_address || '—'} · Created {new Date(s.created_at).toLocaleString()} ·{' '}
                  {s.revoked_at ? 'Revoked' : `Expires ${new Date(s.expires_at).toLocaleDateString()}`}
                </div>
              </div>
              {!s.revoked_at && (
                <button
                  type="button"
                  onClick={() => handleRevokeSession(s.id)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/40 text-red-600 dark:text-red-400 text-xs font-medium"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Terminate Session
                </button>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
