import React, { useEffect, useState } from 'react';
import {
  Download,
  MessageSquare,
  Phone,
  PhoneIncoming,
  PhoneMissed,
  PhoneOutgoing,
  Send,
  Trash2,
  UserPlus,
  Users,
} from 'lucide-react';
import { apiFetch } from '../../lib/api';
import type { CallLogItem, ContactItem, Device, SmsMessage } from '../../types';

interface CommsViewProps {
  device: Device | null;
  requirePinCheck: (label: string, action: () => void) => void;
}

export function CommsView({ device, requirePinCheck }: CommsViewProps) {
  const [subTab, setSubTab] = useState<'sms' | 'contacts' | 'calls'>('sms');
  const [contacts, setContacts] = useState<ContactItem[]>([]);
  const [messages, setMessages] = useState<SmsMessage[]>([]);
  const [calls, setCalls] = useState<CallLogItem[]>([]);
  const [smsTo, setSmsTo] = useState('');
  const [smsBody, setSmsBody] = useState('');
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  async function loadAll() {
    if (!device) return;
    const [c, m, l] = await Promise.all([
      apiFetch<{ contacts: ContactItem[] }>(`/api/devices/${device.id}/contacts`),
      apiFetch<{ messages: SmsMessage[] }>(`/api/devices/${device.id}/sms`),
      apiFetch<{ calls: CallLogItem[] }>(`/api/devices/${device.id}/calls`),
    ]);
    setContacts(c.contacts);
    setMessages(m.messages);
    setCalls(l.calls);
  }

  useEffect(() => {
    loadAll();
  }, [device?.id]);

  if (!device) {
    return (
      <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-10 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
        Select a paired device to manage SMS, contacts, and call history.
      </div>
    );
  }

  function handleSendSms(e: React.FormEvent) {
    e.preventDefault();
    if (!device || !smsTo.trim() || !smsBody.trim()) return;
    requirePinCheck('Send SMS via connected phone', async () => {
      const res = await apiFetch<{ message: SmsMessage }>(`/api/devices/${device.id}/sms/send`, {
        method: 'POST',
        body: JSON.stringify({ address: smsTo.trim(), body: smsBody.trim() }),
      });
      setMessages((prev) => [res.message, ...prev]);
      setSmsBody('');
      setStatusMsg(
        res.message.status === 'sent'
          ? 'SMS dispatched to phone.'
          : 'SMS queued (phone currently offline).'
      );
    });
  }

  async function handleAddContact(e: React.FormEvent) {
    e.preventDefault();
    if (!device || !newName.trim() || !newPhone.trim()) return;
    const res = await apiFetch<{ contact: ContactItem }>(`/api/devices/${device.id}/contacts`, {
      method: 'POST',
      body: JSON.stringify({ name: newName.trim(), phone: newPhone.trim(), email: newEmail.trim() }),
    });
    setContacts((prev) => [...prev, res.contact].sort((a, b) => a.name.localeCompare(b.name)));
    setNewName('');
    setNewPhone('');
    setNewEmail('');
  }

  async function handleDeleteContact(id: string) {
    if (!device) return;
    await apiFetch(`/api/devices/${device.id}/contacts/${id}`, { method: 'DELETE' });
    setContacts((prev) => prev.filter((c) => c.id !== id));
  }

  function exportVcf() {
    if (!device) return;
    const vcf = contacts
      .map(
        (c) =>
          `BEGIN:VCARD\nVERSION:3.0\nFN:${c.name}\nTEL:${c.phone}\nEMAIL:${c.email || ''}\nEND:VCARD`
      )
      .join('\n');
    const blob = new Blob([vcf], { type: 'text/vcard' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${device.name.replace(/\s+/g, '_')}_contacts.vcf`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">
            Messages, Contacts &amp; Calls
          </h1>
          <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
            Synchronized communications for {device.name}.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-lg bg-[#E7ECE6] dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921]">
          <button
            type="button"
            onClick={() => setSubTab('sms')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium ${
              subTab === 'sms'
                ? 'bg-white dark:bg-[#1E2A20] text-[#111713] dark:text-[#EDF2EE] shadow-sm'
                : 'text-[#4E5A51] dark:text-[#97A399]'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            SMS ({messages.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab('contacts')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium ${
              subTab === 'contacts'
                ? 'bg-white dark:bg-[#1E2A20] text-[#111713] dark:text-[#EDF2EE] shadow-sm'
                : 'text-[#4E5A51] dark:text-[#97A399]'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            Contacts ({contacts.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab('calls')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium ${
              subTab === 'calls'
                ? 'bg-white dark:bg-[#1E2A20] text-[#111713] dark:text-[#EDF2EE] shadow-sm'
                : 'text-[#4E5A51] dark:text-[#97A399]'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            Call History ({calls.length})
          </button>
        </div>
      </div>

      {subTab === 'sms' && (
        <div className="grid lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleSendSms}
            className="lg:col-span-4 rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-5 space-y-4 h-fit"
          >
            <h2 className="font-display text-base font-bold">Send SMS</h2>
            {statusMsg && (
              <div className="p-2.5 rounded-lg bg-[#2F5E38]/15 text-xs">{statusMsg}</div>
            )}
            <div>
              <label className="block text-xs text-[#4E5A51] dark:text-[#97A399] mb-1">
                Recipient Phone Number
              </label>
              <input
                type="tel"
                required
                value={smsTo}
                onChange={(e) => setSmsTo(e.target.value)}
                placeholder="+1 555 019 2834"
                className="w-full px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] font-mono text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-[#4E5A51] dark:text-[#97A399] mb-1">
                Message
              </label>
              <textarea
                rows={4}
                required
                value={smsBody}
                onChange={(e) => setSmsBody(e.target.value)}
                placeholder="Write your SMS message..."
                className="w-full px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-sm"
              />
            </div>
            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold"
            >
              <Send className="w-3.5 h-3.5" />
              Send via Phone
            </button>
          </form>

          <div className="lg:col-span-8 rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#D7DFD8] dark:border-[#1F2921] font-display text-base font-bold">
              Recent SMS Messages
            </div>
            {messages.length === 0 ? (
              <div className="p-8 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
                No SMS messages synced yet. Grant SMS permission in the ARMY CONNECT Android app to sync threads.
              </div>
            ) : (
              <div className="divide-y divide-[#D7DFD8] dark:divide-[#1F2921] max-h-[480px] overflow-y-auto">
                {messages.map((m) => (
                  <div key={m.id} className="px-5 py-3.5 space-y-1">
                    <div className="flex items-center justify-between gap-4">
                      <span className="font-medium text-sm">
                        {m.contact_name || m.address}
                      </span>
                      <span className="font-mono text-xs text-[#4E5A51] dark:text-[#97A399]">
                        {m.direction} · {m.status} · {new Date(m.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-sm text-[#4E5A51] dark:text-[#BAC7BC]">{m.body}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {subTab === 'contacts' && (
        <div className="space-y-4">
          <form
            onSubmit={handleAddContact}
            className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-4 flex flex-wrap items-end gap-3"
          >
            <div className="flex-1 min-w-[160px]">
              <label className="block text-xs text-[#4E5A51] dark:text-[#97A399] mb-1">Name</label>
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Full Name"
                className="w-full px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-sm"
              />
            </div>
            <div className="flex-1 min-w-[160px]">
              <label className="block text-xs text-[#4E5A51] dark:text-[#97A399] mb-1">Phone</label>
              <input
                type="tel"
                required
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                placeholder="+1 555 0100"
                className="w-full px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] font-mono text-sm"
              />
            </div>
            <div className="flex-1 min-w-[160px]">
              <label className="block text-xs text-[#4E5A51] dark:text-[#97A399] mb-1">Email</label>
              <input
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="optional@email.com"
                className="w-full px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-sm"
              />
            </div>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold"
            >
              <UserPlus className="w-3.5 h-3.5" />
              Add Contact
            </button>
            <button
              type="button"
              onClick={exportVcf}
              disabled={contacts.length === 0}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium disabled:opacity-40"
            >
              <Download className="w-3.5 h-3.5" />
              Export vCard
            </button>
          </form>

          <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] overflow-hidden">
            {contacts.length === 0 ? (
              <div className="p-8 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
                No contacts stored yet. Add a contact above or sync from Android.
              </div>
            ) : (
              <table className="w-full text-left text-sm">
                <thead className="bg-[#F4F6F3] dark:bg-[#0D110E] text-xs text-[#4E5A51] dark:text-[#97A399]">
                  <tr>
                    <th className="px-5 py-2.5 font-medium">Name</th>
                    <th className="px-5 py-2.5 font-medium">Phone</th>
                    <th className="px-5 py-2.5 font-medium">Email</th>
                    <th className="px-5 py-2.5 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D7DFD8] dark:divide-[#1F2921]">
                  {contacts.map((c) => (
                    <tr key={c.id}>
                      <td className="px-5 py-2.5 font-medium">{c.name}</td>
                      <td className="px-5 py-2.5 font-mono text-xs">{c.phone}</td>
                      <td className="px-5 py-2.5 text-xs text-[#4E5A51] dark:text-[#97A399]">
                        {c.email || '—'}
                      </td>
                      <td className="px-5 py-2.5 text-right">
                        <button
                          type="button"
                          onClick={() => {
                            setSmsTo(c.phone);
                            setSubTab('sms');
                          }}
                          className="text-xs text-[#3E7B4A] font-medium mr-3"
                        >
                          Message
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteContact(c.id)}
                          className="p-1 text-red-500"
                          title="Delete contact"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {subTab === 'calls' && (
        <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] overflow-hidden">
          {calls.length === 0 ? (
            <div className="p-8 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
              No call logs synced yet. Grant Call Log permission in the ARMY CONNECT Android app.
            </div>
          ) : (
            <table className="w-full text-left text-sm">
              <thead className="bg-[#F4F6F3] dark:bg-[#0D110E] text-xs text-[#4E5A51] dark:text-[#97A399]">
                <tr>
                  <th className="px-5 py-2.5 font-medium">Caller</th>
                  <th className="px-5 py-2.5 font-medium">Type</th>
                  <th className="px-5 py-2.5 font-medium text-right">Duration</th>
                  <th className="px-5 py-2.5 font-medium text-right">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D7DFD8] dark:divide-[#1F2921]">
                {calls.map((c) => (
                  <tr key={c.id}>
                    <td className="px-5 py-2.5 font-medium">
                      {c.contact_name || c.number}
                      {c.contact_name && (
                        <span className="ml-2 font-mono text-xs text-[#4E5A51] dark:text-[#97A399]">
                          {c.number}
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-2.5 text-xs capitalize inline-flex items-center gap-1.5">
                      {c.call_type === 'missed' ? (
                        <PhoneMissed className="w-3.5 h-3.5 text-red-500" />
                      ) : c.call_type === 'outgoing' ? (
                        <PhoneOutgoing className="w-3.5 h-3.5 text-[#3E7B4A]" />
                      ) : (
                        <PhoneIncoming className="w-3.5 h-3.5 text-sky-500" />
                      )}
                      {c.call_type}
                    </td>
                    <td className="px-5 py-2.5 font-mono text-xs text-right tabular-nums">
                      {c.duration_sec}s
                    </td>
                    <td className="px-5 py-2.5 font-mono text-xs text-right tabular-nums">
                      {new Date(c.timestamp).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}
