import React, { useState } from 'react';
import { Check, ClipboardCopy, Lock, Send } from 'lucide-react';
import { apiFetch } from '../../lib/api';
import { decryptText, encryptText, isEncryptedPayload } from '../../lib/crypto';
import type { ClipboardItem, Device } from '../../types';

interface ClipboardViewProps {
  device: Device | null;
  items: ClipboardItem[];
  onAdded: (item: ClipboardItem) => void;
}

export function ClipboardView({ device, items, onAdded }: ClipboardViewProps) {
  const [content, setContent] = useState('');
  const [e2eePassphrase, setE2eePassphrase] = useState('');
  const [useE2ee, setUseE2ee] = useState(false);
  const [decryptedMap, setDecryptedMap] = useState<Record<string, string>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [error, setError] = useState('');

  async function handlePush(e: React.FormEvent) {
    e.preventDefault();
    if (!content.trim()) return;
    setError('');
    try {
      const finalContent =
        useE2ee && e2eePassphrase.trim()
          ? await encryptText(content.trim(), e2eePassphrase.trim())
          : content.trim();

      const res = await apiFetch<{ item: ClipboardItem }>('/api/clipboard', {
        method: 'POST',
        body: JSON.stringify({
          content: finalContent,
          deviceId: device?.id || null,
          encrypted: useE2ee && Boolean(e2eePassphrase.trim()),
        }),
      });
      onAdded(res.item);
      setContent('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to sync clipboard');
    }
  }

  async function handleCopy(item: ClipboardItem) {
    let text = decryptedMap[item.id] ?? item.content;
    if (isEncryptedPayload(text)) {
      if (!e2eePassphrase.trim()) {
        setError('Enter your E2EE passphrase to decrypt this entry.');
        return;
      }
      try {
        text = await decryptText(text, e2eePassphrase.trim());
        setDecryptedMap((prev) => ({ ...prev, [item.id]: text }));
      } catch {
        setError('Incorrect E2EE passphrase.');
        return;
      }
    }
    await navigator.clipboard?.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 1800);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">Clipboard Sync</h1>
        <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
          Share text, links, and verification codes between your computer and Android device in real time.
        </p>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-sm text-red-600 dark:text-red-300">
          {error}
        </div>
      )}

      <form
        onSubmit={handlePush}
        className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-5 space-y-4"
      >
        <textarea
          rows={3}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Paste text or URL to send immediately to your phone clipboard..."
          className="w-full px-3.5 py-2.5 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-sm"
        />
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <label className="inline-flex items-center gap-2 text-xs font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={useE2ee}
                onChange={(e) => setUseE2ee(e.target.checked)}
                className="accent-[#2F5E38]"
              />
              <Lock className="w-3.5 h-3.5 text-[#3E7B4A]" />
              Encrypt with AES-256-GCM
            </label>
            <input
              type="password"
              value={e2eePassphrase}
              onChange={(e) => setE2eePassphrase(e.target.value)}
              placeholder="Shared E2EE passphrase (optional)"
              className="px-3 py-1.5 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-xs"
            />
          </div>

          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold"
          >
            <Send className="w-3.5 h-3.5" />
            Sync Clipboard
          </button>
        </div>
      </form>

      <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] divide-y divide-[#D7DFD8] dark:divide-[#1F2921]">
        {items.length === 0 ? (
          <div className="p-8 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
            No clipboard items synced yet.
          </div>
        ) : (
          items.map((item) => {
            const encrypted = isEncryptedPayload(item.content) && !decryptedMap[item.id];
            const displayed = decryptedMap[item.id] ?? item.content;
            return (
              <div key={item.id} className="p-4 flex items-start justify-between gap-4">
                <div className="min-w-0 space-y-1">
                  <div className="text-xs font-mono text-[#4E5A51] dark:text-[#97A399]">
                    {item.source} · {new Date(item.created_at).toLocaleString()}
                    {encrypted ? ' · Encrypted' : ''}
                  </div>
                  <div className="text-sm break-all font-mono">
                    {encrypted ? 'AES-GCM Encrypted Payload (enter passphrase & click Copy to decrypt)' : displayed}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(item)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium shrink-0"
                >
                  {copiedId === item.id ? (
                    <Check className="w-3.5 h-3.5 text-[#3E7B4A]" />
                  ) : (
                    <ClipboardCopy className="w-3.5 h-3.5" />
                  )}
                  {copiedId === item.id ? 'Copied' : encrypted ? 'Decrypt & Copy' : 'Copy'}
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
