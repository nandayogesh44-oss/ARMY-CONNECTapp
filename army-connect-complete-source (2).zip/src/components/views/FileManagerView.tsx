import React, { useEffect, useRef, useState } from 'react';
import {
  Download,
  FileText,
  Folder,
  Globe,
  RefreshCw,
  Search,
  Trash2,
  Upload,
} from 'lucide-react';
import { apiFetch, apiUrl, formatBytes, getAuthToken } from '../../lib/api';
import {
  attachDataChannelFileReceiver,
  DEFAULT_ICE_CONFIG,
  describeTransportMode,
  inspectPeerConnectionStats,
  sendFileOverDataChannel,
} from '../../lib/webrtcPeer';
import type { Device, FileItem, WebRtcIceConfig, WebRtcStatsSnapshot } from '../../types';

interface FileManagerViewProps {
  device: Device | null;
  onCommand: (deviceId: string, command: string, payload?: Record<string, unknown>) => Promise<void>;
  onSendSignal: (msg: Record<string, unknown>) => void;
}

export function FileManagerView({ device, onCommand, onSendSignal }: FileManagerViewProps) {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadPct, setUploadPct] = useState<number | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState('');
  const [p2pState, setP2pState] = useState<'idle' | 'connecting' | 'open'>('idle');
  const [p2pStats, setP2pStats] = useState<WebRtcStatsSnapshot | null>(null);
  const [p2pStatusMsg, setP2pStatusMsg] = useState('');

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const dcRef = useRef<RTCDataChannel | null>(null);
  const iceConfigRef = useRef<WebRtcIceConfig>(DEFAULT_ICE_CONFIG);

  function closeP2pTunnel() {
    if (dcRef.current) {
      dcRef.current.close();
      dcRef.current = null;
    }
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    setP2pState('idle');
    setP2pStats(null);
  }

  async function loadFiles() {
    if (!device) return;
    setLoading(true);
    setError('');
    try {
      const res = await apiFetch<{ files: FileItem[] }>(`/api/devices/${device.id}/files`);
      setFiles(res.files);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load files');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    closeP2pTunnel();
    loadFiles();
  }, [device?.id]);

  useEffect(() => {
    apiFetch<WebRtcIceConfig>('/api/webrtc/ice-servers')
      .then((cfg) => {
        if (Array.isArray(cfg.iceServers) && cfg.iceServers.length > 0) {
          iceConfigRef.current = cfg;
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const onFileAdded = (ev: Event) => {
      const detail = (ev as CustomEvent<{ deviceId?: string }>).detail;
      if (device && detail?.deviceId === device.id) {
        loadFiles().catch(() => {});
      }
    };
    window.addEventListener('army-connect:file-added', onFileAdded);
    return () => window.removeEventListener('army-connect:file-added', onFileAdded);
  }, [device?.id]);

  useEffect(() => {
    if (!device) return;

    const handleSignal = async (ev: Event) => {
      const msg = (ev as CustomEvent<Record<string, unknown>>).detail;
      if (!msg || msg.deviceId !== device.id || msg.channel !== 'data') return;

      if (msg.type === 'webrtc:answer' && msg.sdp && pcRef.current) {
        try {
          await pcRef.current.setRemoteDescription(
            new RTCSessionDescription(msg.sdp as RTCSessionDescriptionInit)
          );
        } catch {
          closeP2pTunnel();
        }
      } else if (msg.type === 'webrtc:ice' && msg.candidate && pcRef.current) {
        try {
          await pcRef.current.addIceCandidate(
            new RTCIceCandidate(msg.candidate as RTCIceCandidateInit)
          );
        } catch {
          // Ignore stale candidates
        }
      }
    };

    window.addEventListener('army-connect:webrtc-signal', handleSignal);
    return () => {
      window.removeEventListener('army-connect:webrtc-signal', handleSignal);
    };
  }, [device?.id]);

  async function connectP2pTunnel() {
    if (!device || !device.online) return;
    closeP2pTunnel();
    setP2pState('connecting');
    setP2pStatusMsg('Negotiating STUN/TURN WebRTC DataChannel...');

    try {
      const pc = new RTCPeerConnection({
        iceServers: iceConfigRef.current.iceServers,
        iceCandidatePoolSize: 4,
      });
      pcRef.current = pc;

      const dc = pc.createDataChannel('army-connect-data', { ordered: true });
      dcRef.current = dc;

      dc.onopen = () => {
        setP2pState('open');
        setP2pStatusMsg('Direct encrypted WebRTC P2P tunnel active');
        inspectPeerConnectionStats(pc).then(setP2pStats);
      };

      dc.onclose = () => {
        setP2pState('idle');
        setP2pStats(null);
      };

      attachDataChannelFileReceiver(dc, (received) => {
        const url = URL.createObjectURL(received.blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = received.name;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 5000);
        setP2pStatusMsg(`Received ${received.name} directly over WebRTC P2P`);
      });

      pc.onicecandidate = (ev) => {
        if (ev.candidate) {
          onSendSignal({
            type: 'webrtc:ice',
            channel: 'data',
            deviceId: device.id,
            candidate: ev.candidate.toJSON(),
          });
        }
      };

      pc.onconnectionstatechange = () => {
        if (pc.connectionState === 'connected') {
          inspectPeerConnectionStats(pc).then(setP2pStats);
        } else if (pc.connectionState === 'disconnected') {
          pc.restartIce?.();
        } else if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
          setP2pState('idle');
          setP2pStatusMsg('Peer offline or blocked by NAT — HTTPS encrypted transfer remains active');
        }
      };

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      onSendSignal({
        type: 'webrtc:offer',
        channel: 'data',
        deviceId: device.id,
        sdp: pc.localDescription,
      });
    } catch {
      closeP2pTunnel();
      setP2pStatusMsg('Could not open P2P tunnel; using HTTPS encrypted relay');
    }
  }

  async function uploadFileList(fileList: FileList | null) {
    if (!fileList || fileList.length === 0 || !device) return;
    setUploading(true);
    setUploadPct(0);
    setError('');
    try {
      const filesArr = Array.from(fileList);
      for (let i = 0; i < filesArr.length; i += 1) {
        const file = filesArr[i];
        if (dcRef.current && dcRef.current.readyState === 'open') {
          await sendFileOverDataChannel(dcRef.current, file, (pct) => {
            setUploadPct(pct);
          });
          setP2pStatusMsg(`Sent ${file.name} directly via WebRTC P2P`);
        }

        const form = new FormData();
        form.append('file', file);
        form.append('folder', '/Transfers');
        await apiFetch(`/api/devices/${device.id}/files/upload`, {
          method: 'POST',
          body: form,
        });
        setUploadPct(Math.round(((i + 1) / filesArr.length) * 100));
      }
      await loadFiles();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploading(false);
      setUploadPct(null);
    }
  }

  async function handleDelete(fileId: string) {
    if (!device) return;
    await apiFetch(`/api/devices/${device.id}/files/${fileId}`, { method: 'DELETE' });
    setFiles((prev) => prev.filter((f) => f.id !== fileId));
  }

  async function handleSyncFromPhone() {
    if (!device) return;
    await onCommand(device.id, 'files:list', { path: '/storage/emulated/0' });
    setTimeout(loadFiles, 1000);
  }

  if (!device) {
    return (
      <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-10 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
        Select or pair an Android device first to browse and transfer files.
      </div>
    );
  }

  const filtered = files.filter((f) => {
    if (categoryFilter !== 'all' && f.category !== categoryFilter) return false;
    if (
      search &&
      !f.name.toLowerCase().includes(search.toLowerCase()) &&
      !f.path.toLowerCase().includes(search.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const token = getAuthToken() || '';
  const transportText =
    p2pState === 'open'
      ? p2pStats
        ? `${describeTransportMode(p2pStats.transportMode)}${p2pStats.rttMs ? ` · ${p2pStats.rttMs} ms` : ''}`
        : 'WebRTC P2P DataChannel Open'
      : p2pState === 'connecting'
      ? 'Negotiating STUN/TURN P2P...'
      : 'HTTPS Encrypted Transfer (Click to open P2P tunnel)';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Remote File Manager</h1>
          <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
            Transfer files worldwide across Wi-Fi and mobile data to {device.name} via HTTPS or
            WebRTC P2P.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleSyncFromPhone}
            disabled={!device.online}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium hover:bg-[#E7ECE6] dark:hover:bg-[#161D17] disabled:opacity-40 whitespace-nowrap shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Sync Phone Storage
          </button>
          <label className="cursor-pointer inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold whitespace-nowrap shrink-0">
            <Upload className="w-3.5 h-3.5" />
            {uploading ? `Uploading${uploadPct !== null ? ` (${uploadPct}%)` : '...'}` : 'Upload to Phone'}
            <input
              type="file"
              multiple
              className="hidden"
              onChange={(e) => uploadFileList(e.target.files)}
            />
          </label>
        </div>
      </div>

      <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-mono text-[#4E5A51] dark:text-[#97A399] tabular-nums">
          <Globe className="w-4 h-4 text-[#3E7B4A] shrink-0" />
          <span>{transportText}</span>
          {p2pStatusMsg && (
            <>
              <span aria-hidden="true">·</span>
              <span className="text-[#111713] dark:text-[#EDF2EE]">{p2pStatusMsg}</span>
            </>
          )}
        </div>
        {p2pState === 'open' ? (
          <button
            type="button"
            onClick={closeP2pTunnel}
            className="px-3 py-1.5 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium whitespace-nowrap shrink-0"
          >
            Close P2P Tunnel
          </button>
        ) : (
          <button
            type="button"
            disabled={!device.online || p2pState === 'connecting'}
            onClick={connectP2pTunnel}
            className="px-3 py-1.5 rounded-lg border border-[#3E7B4A]/50 text-[#1E4627] dark:text-[#4ADE80] text-xs font-semibold disabled:opacity-40 whitespace-nowrap shrink-0"
          >
            {p2pState === 'connecting' ? 'Connecting P2P...' : 'Connect P2P Tunnel'}
          </button>
        )}
      </div>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          uploadFileList(e.dataTransfer.files);
        }}
        className={`rounded-xl border border-dashed p-6 text-center transition-colors ${
          dragOver
            ? 'border-[#3E7B4A] bg-[#2F5E38]/10'
            : 'border-[#D7DFD8] dark:border-[#1F2921] bg-white dark:bg-[#111612]'
        }`}
      >
        <p className="text-sm font-medium">
          Drag and drop files here to transfer directly to {device.name}
        </p>
        <p className="text-xs text-[#4E5A51] dark:text-[#97A399] mt-1">
          Supports documents, APKs, photos, videos, and archives up to 250 MB per file over
          encrypted internet relay or WebRTC P2P.
        </p>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-sm text-red-600 dark:text-red-300">
          {error}
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 rounded-lg bg-[#E7ECE6] dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921]">
          {(['all', 'document', 'photo', 'video', 'audio'] as const).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-colors whitespace-nowrap shrink-0 ${
                categoryFilter === cat
                  ? 'bg-white dark:bg-[#1E2A20] text-[#111713] dark:text-[#EDF2EE] shadow-sm'
                  : 'text-[#4E5A51] dark:text-[#97A399]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#4E5A51] dark:text-[#97A399]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search files or path..."
            className="w-full pl-9 pr-3 py-2 rounded-lg bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] text-xs"
          />
        </div>
      </div>

      <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
            Loading files...
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-10 text-center space-y-2">
            <Folder className="w-8 h-8 mx-auto text-[#3E7B4A]" />
            <div className="text-sm font-medium">No files in this view</div>
            <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">
              Upload a file above or sync storage from your connected Android phone.
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#F4F6F3] dark:bg-[#0D110E] text-xs text-[#4E5A51] dark:text-[#97A399]">
                <tr>
                  <th className="px-5 py-2.5 font-medium">Name</th>
                  <th className="px-5 py-2.5 font-medium">Folder</th>
                  <th className="px-5 py-2.5 font-medium">Type</th>
                  <th className="px-5 py-2.5 font-medium text-right">Size</th>
                  <th className="px-5 py-2.5 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D7DFD8] dark:divide-[#1F2921]">
                {filtered.map((file) => (
                  <tr key={file.id} className="hover:bg-[#F4F6F3]/60 dark:hover:bg-[#161D17]">
                    <td className="px-5 py-2.5 font-medium">
                      <div className="flex items-center gap-2">
                        {file.is_directory ? (
                          <Folder className="w-4 h-4 text-[#3E7B4A] shrink-0" />
                        ) : (
                          <FileText className="w-4 h-4 text-[#4E5A51] dark:text-[#97A399] shrink-0" />
                        )}
                        <span className="truncate max-w-xs">{file.name}</span>
                      </div>
                    </td>
                    <td className="px-5 py-2.5 font-mono text-xs text-[#4E5A51] dark:text-[#97A399]">
                      {file.folder}
                    </td>
                    <td className="px-5 py-2.5 text-xs capitalize text-[#4E5A51] dark:text-[#97A399]">
                      {file.category}
                    </td>
                    <td className="px-5 py-2.5 font-mono text-xs text-right tabular-nums">
                      {file.is_directory ? '—' : formatBytes(file.size)}
                    </td>
                    <td className="px-5 py-2.5 text-right">
                      <div className="inline-flex items-center gap-2">
                        {file.stored_filename ? (
                          <a
                            href={apiUrl(`/api/devices/${device.id}/files/${file.id}/download?token=${encodeURIComponent(token)}`)}
                            className="p-1.5 rounded hover:bg-[#E7ECE6] dark:hover:bg-[#1E2A20] text-[#3E7B4A]"
                            title="Download file"
                          >
                            <Download className="w-4 h-4" />
                          </a>
                        ) : (
                          <button
                            type="button"
                            disabled={!device.online}
                            onClick={() => onCommand(device.id, 'files:pull', { path: file.path })}
                            className="px-2 py-1 rounded border border-[#D7DFD8] dark:border-[#1F2921] text-xs disabled:opacity-40"
                          >
                            Fetch
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleDelete(file.id)}
                          className="p-1.5 rounded hover:bg-red-500/10 text-red-600 dark:text-red-400"
                          title="Delete file"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
