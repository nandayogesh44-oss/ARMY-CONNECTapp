import React, { useEffect, useState } from 'react';
import { Download, Film, Image as ImageIcon, Music, Play, Trash2, Upload, X } from 'lucide-react';
import { apiFetch, apiUrl, formatBytes, getAuthToken } from '../../lib/api';
import type { Device, FileItem } from '../../types';

interface MediaViewProps {
  device: Device | null;
  category: 'photo' | 'video' | 'audio';
}

export function MediaView({ device, category }: MediaViewProps) {
  const [items, setItems] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [activePhoto, setActivePhoto] = useState<FileItem | null>(null);
  const [activeVideo, setActiveVideo] = useState<FileItem | null>(null);
  const [activeAudio, setActiveAudio] = useState<FileItem | null>(null);

  async function loadMedia() {
    if (!device) return;
    setLoading(true);
    try {
      const res = await apiFetch<{ files: FileItem[] }>(
        `/api/devices/${device.id}/files?category=${category}`
      );
      setItems(res.files);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadMedia();
    setActivePhoto(null);
    setActiveVideo(null);
    setActiveAudio(null);
  }, [device?.id, category]);

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    if (!e.target.files || !device) return;
    for (const file of Array.from(e.target.files)) {
      const form = new FormData();
      form.append('file', file);
      form.append('folder', `/${category.charAt(0).toUpperCase() + category.slice(1)}s`);
      await apiFetch(`/api/devices/${device.id}/files/upload`, { method: 'POST', body: form });
    }
    await loadMedia();
    e.target.value = '';
  }

  async function handleDelete(id: string) {
    if (!device) return;
    await apiFetch(`/api/devices/${device.id}/files/${id}`, { method: 'DELETE' });
    setItems((prev) => prev.filter((item) => item.id !== id));
  }

  if (!device) {
    return (
      <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-10 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
        Select a paired device to browse {category}s.
      </div>
    );
  }

  const token = getAuthToken() || '';
  const streamUrl = (id: string) =>
    apiUrl(`/api/devices/${device.id}/files/${id}/download?inline=1&token=${encodeURIComponent(token)}`);
  const downloadUrl = (id: string) =>
    apiUrl(`/api/devices/${device.id}/files/${id}/download?token=${encodeURIComponent(token)}`);

  const heading =
    category === 'photo' ? 'Photo Browser' : category === 'video' ? 'Video Browser' : 'Music & Audio';
  const accept =
    category === 'photo' ? 'image/*' : category === 'video' ? 'video/*' : 'audio/*';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">{heading}</h1>
          <p className="text-sm text-[#4E5A51] dark:text-[#97A399]">
            Stream, inspect, and transfer {category} files for {device.name}.
          </p>
        </div>
        <label className="cursor-pointer inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold whitespace-nowrap">
          <Upload className="w-3.5 h-3.5" />
          Upload {category}
          <input type="file" accept={accept} multiple className="hidden" onChange={handleUpload} />
        </label>
      </div>

      {loading ? (
        <div className="p-8 text-center text-sm text-[#4E5A51] dark:text-[#97A399]">
          Loading media...
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-10 text-center space-y-2">
          {category === 'photo' ? (
            <ImageIcon className="w-8 h-8 mx-auto text-[#3E7B4A]" />
          ) : category === 'video' ? (
            <Film className="w-8 h-8 mx-auto text-[#3E7B4A]" />
          ) : (
            <Music className="w-8 h-8 mx-auto text-[#3E7B4A]" />
          )}
          <div className="text-sm font-medium">No {category}s available yet</div>
          <div className="text-xs text-[#4E5A51] dark:text-[#97A399]">
            Upload media or transfer from your Android device to view here.
          </div>
        </div>
      ) : category === 'photo' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {items.map((item) => (
            <div
              key={item.id}
              className="group rounded-xl overflow-hidden bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921]"
            >
              <button
                type="button"
                onClick={() => setActivePhoto(item)}
                className="block w-full aspect-[4/3] bg-[#090B09] overflow-hidden"
              >
                {item.stored_filename ? (
                  <img
                    src={streamUrl(item.id)}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-[#97A399]">
                    On Device
                  </div>
                )}
              </button>
              <div className="p-3 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-xs font-medium truncate">{item.name}</div>
                  <div className="text-xs font-mono text-[#4E5A51] dark:text-[#97A399]">
                    {formatBytes(item.size)}
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {item.stored_filename && (
                    <a href={downloadUrl(item.id)} className="p-1 text-[#3E7B4A]" title="Download">
                      <Download className="w-4 h-4" />
                    </a>
                  )}
                  <button
                    type="button"
                    onClick={() => handleDelete(item.id)}
                    className="p-1 text-red-500"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : category === 'video' ? (
        <div className="space-y-4">
          {activeVideo && activeVideo.stored_filename && (
            <div className="rounded-xl overflow-hidden bg-black border border-[#1F2921]">
              <video src={streamUrl(activeVideo.id)} controls autoPlay className="w-full max-h-[460px]" />
            </div>
          )}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {items.map((item) => (
              <div
                key={item.id}
                className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-4 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <div className="text-sm font-medium truncate">{item.name}</div>
                  <div className="text-xs font-mono text-[#4E5A51] dark:text-[#97A399]">
                    {formatBytes(item.size)}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {item.stored_filename && (
                    <>
                      <button
                        type="button"
                        onClick={() => setActiveVideo(item)}
                        className="p-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white"
                        title="Play video"
                      >
                        <Play className="w-3.5 h-3.5" />
                      </button>
                      <a href={downloadUrl(item.id)} className="p-2 text-[#3E7B4A]" title="Download">
                        <Download className="w-4 h-4" />
                      </a>
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => handleDelete(item.id)}
                    className="p-2 text-red-500"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {activeAudio && activeAudio.stored_filename && (
            <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#2F5E38] p-4 space-y-2">
              <div className="text-xs font-semibold text-[#3E7B4A]">Now Playing: {activeAudio.name}</div>
              <audio src={streamUrl(activeAudio.id)} controls autoPlay className="w-full" />
            </div>
          )}
          <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] divide-y divide-[#D7DFD8] dark:divide-[#1F2921]">
            {items.map((item) => (
              <div key={item.id} className="px-5 py-3 flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="text-sm font-medium truncate">{item.name}</div>
                  <div className="text-xs font-mono text-[#4E5A51] dark:text-[#97A399]">
                    {formatBytes(item.size)}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {item.stored_filename && (
                    <>
                      <button
                        type="button"
                        onClick={() => setActiveAudio(item)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-medium"
                      >
                        <Play className="w-3.5 h-3.5" />
                        Play
                      </button>
                      <a href={downloadUrl(item.id)} className="p-1.5 text-[#3E7B4A]" title="Download">
                        <Download className="w-4 h-4" />
                      </a>
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => handleDelete(item.id)}
                    className="p-1.5 text-red-500"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activePhoto && activePhoto.stored_filename && (
        <div
          onClick={() => setActivePhoto(null)}
          className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-6"
        >
          <button
            type="button"
            onClick={() => setActivePhoto(null)}
            className="absolute top-6 right-6 p-2 rounded-lg bg-white/10 text-white"
          >
            <X className="w-5 h-5" />
          </button>
          <img
            src={streamUrl(activePhoto.id)}
            alt={activePhoto.name}
            className="max-w-full max-h-[88vh] rounded-lg object-contain"
          />
        </div>
      )}
    </div>
  );
}
