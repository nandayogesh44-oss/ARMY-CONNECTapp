import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Bell,
  Camera,
  ClipboardCopy,
  Globe,
  MapPin,
  Monitor,
  Shield,
  Smartphone,
  Upload,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { apiUrl, buildWsUrl } from '../lib/api';
import {
  attachDataChannelFileReceiver,
  DEFAULT_PUBLIC_STUN_ICE,
  describeTransportMode,
  inspectPeerConnectionStats,
  sendFileOverDataChannel,
} from '../lib/webrtcPeer';
import type { WebRtcTransportMode } from '../types';

interface DeviceCompanionProps {
  initialCode?: string;
  onExit: () => void;
}

const DEVICE_STORAGE_KEY = 'army_connect_companion_device';

export function DeviceCompanion({ initialCode = '', onExit }: DeviceCompanionProps) {
  const [code, setCode] = useState(initialCode);
  const [deviceName, setDeviceName] = useState(() => {
    const ua = navigator.userAgent;
    if (/Android/i.test(ua)) return 'Android Handheld';
    if (/iPhone|iPad/i.test(ua)) return 'Mobile Browser';
    return 'Companion Device';
  });
  const [paired, setPaired] = useState<{
    deviceId: string;
    deviceToken: string;
    approved: boolean;
    fingerprint: string;
  } | null>(() => {
    try {
      const saved = localStorage.getItem(DEVICE_STORAGE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [wsConnected, setWsConnected] = useState(false);
  const [p2pOpen, setP2pOpen] = useState(false);
  const [p2pMode, setP2pMode] = useState<WebRtcTransportMode>('wss-relay');
  const [ringing, setRinging] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [screenActive, setScreenActive] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [clipInput, setClipInput] = useState('');
  const [notifTitle, setNotifTitle] = useState('');
  const [notifBody, setNotifBody] = useState('');
  const [log, setLog] = useState<string[]>([]);
  const [error, setError] = useState('');

  const wsRef = useRef<WebSocket | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const mediaPcRef = useRef<RTCPeerConnection | null>(null);
  const dataPcRef = useRef<RTCPeerConnection | null>(null);
  const dataChannelRef = useRef<RTCDataChannel | null>(null);
  const frameIntervalRef = useRef<number | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const ringTimerRef = useRef<number | null>(null);

  function appendLog(msg: string) {
    setLog((prev) => [`${new Date().toLocaleTimeString()} — ${msg}`, ...prev].slice(0, 30));
  }

  function stopAlarm() {
    if (ringTimerRef.current) {
      window.clearInterval(ringTimerRef.current);
      ringTimerRef.current = null;
    }
    if (audioCtxRef.current) {
      audioCtxRef.current.close().catch(() => {});
      audioCtxRef.current = null;
    }
    setRinging(false);
  }

  function startAlarm() {
    stopAlarm();
    setRinging(true);
    appendLog('Ring My Phone alarm triggered from Web Dashboard');
    try {
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const playTone = () => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.setValueAtTime(1180, ctx.currentTime + 0.18);
        gain.gain.setValueAtTime(0.25, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.45);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.45);
      };
      playTone();
      ringTimerRef.current = window.setInterval(playTone, 650);
    } catch {
      // Audio playback blocked before interaction
    }
    if ('vibrate' in navigator) {
      navigator.vibrate([400, 200, 400, 200, 400]);
    }
  }

  function stopStreams() {
    if (frameIntervalRef.current) {
      window.clearInterval(frameIntervalRef.current);
      frameIntervalRef.current = null;
    }
    if (mediaPcRef.current) {
      mediaPcRef.current.close();
      mediaPcRef.current = null;
    }
    cameraStreamRef.current?.getTracks().forEach((t) => t.stop());
    cameraStreamRef.current = null;
    screenStreamRef.current?.getTracks().forEach((t) => t.stop());
    screenStreamRef.current = null;
    setCameraActive(false);
    setScreenActive(false);
  }

  function closeDataPeer() {
    if (dataChannelRef.current) {
      dataChannelRef.current.close();
      dataChannelRef.current = null;
    }
    if (dataPcRef.current) {
      dataPcRef.current.close();
      dataPcRef.current = null;
    }
    setP2pOpen(false);
    setP2pMode('wss-relay');
  }

  async function fetchIceServers(): Promise<RTCIceServer[]> {
    if (!paired) return DEFAULT_PUBLIC_STUN_ICE;
    try {
      const res = await fetch(apiUrl('/api/device/webrtc/ice-servers'), {
        headers: { 'x-device-token': paired.deviceToken },
      });
      if (res.ok) {
        const cfg = await res.json();
        if (Array.isArray(cfg.iceServers) && cfg.iceServers.length > 0) {
          return cfg.iceServers;
        }
      }
    } catch {
      // Keep public STUN fallback
    }
    return DEFAULT_PUBLIC_STUN_ICE;
  }

  function setupDataChannelHandlers(dc: RTCDataChannel) {
    dataChannelRef.current = dc;
    dc.onopen = () => {
      setP2pOpen(true);
      appendLog('WebRTC P2P file tunnel opened');
      if (dataPcRef.current) {
        inspectPeerConnectionStats(dataPcRef.current).then((snap) => setP2pMode(snap.transportMode));
      }
    };
    dc.onclose = () => {
      setP2pOpen(false);
      setP2pMode('wss-relay');
    };
    attachDataChannelFileReceiver(dc, (received) => {
      appendLog(`Received P2P file (${received.name}) via WebRTC`);
      const url = URL.createObjectURL(received.blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = received.name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 5000);
    });
  }

  async function handleIncomingDataOffer(sdp: RTCSessionDescriptionInit) {
    if (!paired || !wsRef.current || wsRef.current.readyState !== 1) return;
    closeDataPeer();
    const iceServers = await fetchIceServers();
    const pc = new RTCPeerConnection({ iceServers, iceCandidatePoolSize: 4 });
    dataPcRef.current = pc;

    pc.ondatachannel = (ev) => {
      setupDataChannelHandlers(ev.channel);
    };

    pc.onicecandidate = (ev) => {
      if (ev.candidate && wsRef.current?.readyState === 1) {
        wsRef.current.send(
          JSON.stringify({
            type: 'webrtc:ice',
            channel: 'data',
            candidate: ev.candidate.toJSON(),
          })
        );
      }
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected') {
        inspectPeerConnectionStats(pc).then((snap) => setP2pMode(snap.transportMode));
      } else if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
        setP2pOpen(false);
      }
    };

    try {
      await pc.setRemoteDescription(new RTCSessionDescription(sdp));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      wsRef.current?.send(
        JSON.stringify({
          type: 'webrtc:answer',
          channel: 'data',
          sdp: pc.localDescription,
        })
      );
    } catch {
      closeDataPeer();
    }
  }

  async function startWebRtcOffer(stream: MediaStream) {
    if (!paired || !wsRef.current || wsRef.current.readyState !== 1) return;
    const iceServers = await fetchIceServers();

    try {
      const pc = new RTCPeerConnection({ iceServers, iceCandidatePoolSize: 4 });
      mediaPcRef.current = pc;
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      pc.onicecandidate = (ev) => {
        if (ev.candidate && wsRef.current?.readyState === 1) {
          wsRef.current.send(
            JSON.stringify({
              type: 'webrtc:ice',
              channel: 'media',
              candidate: ev.candidate.toJSON(),
            })
          );
        }
      };

      pc.oniceconnectionstatechange = () => {
        if (pc.iceConnectionState === 'disconnected' || pc.iceConnectionState === 'failed') {
          pc.restartIce?.();
        }
      };

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      wsRef.current?.send(
        JSON.stringify({
          type: 'webrtc:offer',
          channel: 'media',
          sdp: pc.localDescription,
        })
      );
    } catch {
      // Fallback JPEG frame relay continues automatically
    }
  }

  async function startFrameStream(kind: 'camera' | 'screen', mode: 'environment' | 'user' = facingMode) {
    stopStreams();
    try {
      const stream =
        kind === 'camera'
          ? await navigator.mediaDevices.getUserMedia({ video: { facingMode: mode, width: 640 }, audio: false })
          : await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 8 } });

      if (kind === 'camera') {
        cameraStreamRef.current = stream;
        setCameraActive(true);
      } else {
        screenStreamRef.current = stream;
        setScreenActive(true);
      }

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      startWebRtcOffer(stream);

      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      frameIntervalRef.current = window.setInterval(() => {
        const video = videoRef.current;
        if (!video || !ctx || video.videoWidth === 0 || !wsRef.current || wsRef.current.readyState !== 1) return;
        const scale = Math.min(1, 640 / video.videoWidth);
        canvas.width = Math.round(video.videoWidth * scale);
        canvas.height = Math.round(video.videoHeight * scale);
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const frame = canvas.toDataURL('image/jpeg', 0.62);
        wsRef.current.send(
          JSON.stringify({
            type: kind === 'camera' ? 'camera:frame' : 'screen:frame',
            frame,
            facingMode: mode,
            timestamp: Date.now(),
          })
        );
      }, 280);

      stream.getVideoTracks()[0]?.addEventListener('ended', () => {
        stopStreams();
      });
      appendLog(`Started ${kind === 'camera' ? 'remote camera' : 'screen mirroring'} stream`);
    } catch (err) {
      appendLog(`Permission denied for ${kind}: ${err instanceof Error ? err.message : 'blocked'}`);
    }
  }

  async function sendTelemetry(ws: WebSocket) {
    let batteryLevel = 92;
    let isCharging = false;
    try {
      const nav = navigator as Navigator & {
        getBattery?: () => Promise<{ level: number; charging: boolean }>;
      };
      if (nav.getBattery) {
        const b = await nav.getBattery();
        batteryLevel = Math.round(b.level * 100);
        isCharging = b.charging;
      }
    } catch {
      // Battery API optional
    }

    const storageEst = await navigator.storage?.estimate?.().catch(() => null);
    const conn = (navigator as Navigator & { connection?: { effectiveType?: string; type?: string } }).connection;
    const netLabel = conn?.type
      ? `${conn.type.toUpperCase()} (${conn.effectiveType || 'Internet'})`
      : conn?.effectiveType
      ? conn.effectiveType.toUpperCase()
      : 'Internet Link';

    ws.send(
      JSON.stringify({
        type: 'device:telemetry',
        payload: {
          batteryLevel,
          isCharging,
          storageUsed: storageEst?.usage || 0,
          storageTotal: storageEst?.quota || 64 * 1024 * 1024 * 1024,
          networkType: netLabel,
          wifiSsid: 'Worldwide Companion',
          wifiStrength: 88,
          androidVersion: /Android\s([\d.]+)/.exec(navigator.userAgent)?.[1] || '16',
          model: navigator.platform || 'Mobile Web',
          manufacturer: 'ARMY Companion',
        },
      })
    );
  }

  function pushLocation(ws?: WebSocket | null) {
    if (!('geolocation' in navigator)) {
      appendLog('Geolocation API unavailable in this browser');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const socket = ws || wsRef.current;
        if (socket && socket.readyState === 1) {
          socket.send(
            JSON.stringify({
              type: 'device:telemetry',
              payload: {
                latitude: pos.coords.latitude,
                longitude: pos.coords.longitude,
                locationAccuracy: pos.coords.accuracy,
              },
            })
          );
          appendLog(
            `GPS shared: ${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}`
          );
        }
      },
      (err) => appendLog(`Location error: ${err.message}`),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  useEffect(() => {
    if (!paired) return;
    let cancelled = false;
    let reconnectTimer: number | null = null;
    let telemetryTimer: number | null = null;
    let pingTimer: number | null = null;
    let retryAttempt = 0;

    function clearTimers() {
      if (reconnectTimer) {
        window.clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
      if (telemetryTimer) {
        window.clearInterval(telemetryTimer);
        telemetryTimer = null;
      }
      if (pingTimer) {
        window.clearInterval(pingTimer);
        pingTimer = null;
      }
    }

    function connect() {
      clearTimers();
      if (cancelled || !paired) return;
      const ws = new WebSocket(buildWsUrl('device', paired.deviceToken));
      wsRef.current = ws;

      ws.onopen = () => {
        retryAttempt = 0;
        setWsConnected(true);
        appendLog('Connected to ARMY CONNECT server');
        if (paired.approved) {
          sendTelemetry(ws);
        }
        telemetryTimer = window.setInterval(() => {
          if (ws.readyState === 1 && paired.approved) sendTelemetry(ws);
        }, 15_000);
        pingTimer = window.setInterval(() => {
          if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'ping' }));
        }, 20_000);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'device:approved') {
            const next = { ...paired, approved: true };
            setPaired(next);
            localStorage.setItem(DEVICE_STORAGE_KEY, JSON.stringify(next));
            appendLog('Device approved by dashboard');
            sendTelemetry(ws);
          } else if (msg.type === 'device:force_disconnect') {
            appendLog(`Disconnected: ${msg.reason || 'Remote disconnect'}`);
            localStorage.removeItem(DEVICE_STORAGE_KEY);
            setPaired(null);
          } else if (msg.type === 'clipboard:set') {
            navigator.clipboard?.writeText(msg.content).catch(() => {});
            appendLog(`Clipboard received: ${String(msg.content).slice(0, 60)}`);
          } else if (msg.type === 'webrtc:offer' && msg.sdp && msg.channel === 'data') {
            handleIncomingDataOffer(msg.sdp);
          } else if (msg.type === 'webrtc:answer' && msg.sdp && msg.channel !== 'data' && mediaPcRef.current) {
            mediaPcRef.current.setRemoteDescription(new RTCSessionDescription(msg.sdp)).catch(() => {});
          } else if (msg.type === 'webrtc:ice' && msg.candidate) {
            const targetPc = msg.channel === 'data' ? dataPcRef.current : mediaPcRef.current;
            targetPc?.addIceCandidate(new RTCIceCandidate(msg.candidate)).catch(() => {});
          } else if (msg.type === 'webrtc:restart') {
            if (msg.channel === 'data') dataPcRef.current?.restartIce?.();
            else mediaPcRef.current?.restartIce?.();
          } else if (msg.type === 'command') {
            const { commandId, command } = msg;
            let resultPayload: Record<string, unknown> = { ok: true };
            if (command === 'device:ping') {
              resultPayload = { ok: true, pongAt: Date.now() };
            } else if (command === 'ring:start') {
              startAlarm();
            } else if (command === 'ring:stop') {
              stopAlarm();
            } else if (command === 'location:request') {
              pushLocation(ws);
            } else if (command === 'camera:start') {
              startFrameStream('camera', facingMode);
            } else if (command === 'camera:stop' || command === 'screen:stop') {
              stopStreams();
            } else if (command === 'camera:switch') {
              const nextMode = facingMode === 'environment' ? 'user' : 'environment';
              setFacingMode(nextMode);
              if (cameraActive) startFrameStream('camera', nextMode);
            } else if (command === 'screen:start') {
              startFrameStream('screen');
            }
            if (commandId) {
              ws.send(JSON.stringify({ type: 'command:result', commandId, payload: resultPayload }));
            }
          }
        } catch {
          // Ignore malformed
        }
      };

      ws.onclose = () => {
        clearTimers();
        setWsConnected(false);
        if (!cancelled) {
          const delayMs = Math.min(15_000, 1500 * Math.pow(2, retryAttempt));
          retryAttempt = Math.min(retryAttempt + 1, 5);
          appendLog(`Network reconnecting in ${Math.round(delayMs / 1000)}s...`);
          reconnectTimer = window.setTimeout(connect, delayMs);
        }
      };
    }

    const handleNetworkShift = () => {
      if (cancelled) return;
      if (navigator.onLine) {
        retryAttempt = 0;
        appendLog('Internet connectivity restored — syncing signaling');
        mediaPcRef.current?.restartIce?.();
        dataPcRef.current?.restartIce?.();
        if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
          connect();
        } else {
          wsRef.current.send(JSON.stringify({ type: 'ping' }));
          if (paired.approved) sendTelemetry(wsRef.current);
        }
      } else {
        setWsConnected(false);
        appendLog('Network offline — waiting to auto-reconnect');
      }
    };

    window.addEventListener('online', handleNetworkShift);
    window.addEventListener('offline', handleNetworkShift);
    const navConn = (navigator as Navigator & { connection?: EventTarget }).connection;
    navConn?.addEventListener?.('change', handleNetworkShift);

    connect();

    return () => {
      cancelled = true;
      clearTimers();
      window.removeEventListener('online', handleNetworkShift);
      window.removeEventListener('offline', handleNetworkShift);
      navConn?.removeEventListener?.('change', handleNetworkShift);
      stopStreams();
      closeDataPeer();
      stopAlarm();
      wsRef.current?.close();
    };
  }, [paired?.deviceId, paired?.approved]);

  async function handlePair(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    try {
      const res = await fetch(apiUrl('/api/pairing/claim'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: code.trim(),
          name: deviceName.trim() || 'Companion Phone',
          manufacturer: 'Browser Companion',
          model: navigator.platform || 'Mobile',
          androidVersion: /Android\s([\d.]+)/.exec(navigator.userAgent)?.[1] || '16',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Pairing failed');
      const next = {
        deviceId: data.deviceId,
        deviceToken: data.deviceToken,
        approved: data.approved,
        fingerprint: data.e2eeFingerprint,
      };
      localStorage.setItem(DEVICE_STORAGE_KEY, JSON.stringify(next));
      setPaired(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to pair');
    }
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !paired) return;
    if (dataChannelRef.current && dataChannelRef.current.readyState === 'open') {
      try {
        await sendFileOverDataChannel(dataChannelRef.current, file);
        appendLog(`Sent ${file.name} via WebRTC P2P`);
      } catch {
        // Fallback to HTTPS upload
      }
    }
    const form = new FormData();
    form.append('file', file);
    form.append('folder', '/PhoneUploads');
    const res = await fetch(apiUrl('/api/device/files/upload'), {
      method: 'POST',
      headers: { 'x-device-token': paired.deviceToken },
      body: form,
    });
    if (res.ok) {
      appendLog(`Synced ${file.name} to dashboard over HTTPS`);
    } else {
      const body = await res.json().catch(() => ({}));
      appendLog(`Upload blocked: ${body.error || 'Awaiting dashboard approval'}`);
    }
    e.target.value = '';
  }

  function handleSendClipboard() {
    if (!clipInput.trim() || !wsRef.current) return;
    wsRef.current.send(
      JSON.stringify({ type: 'clipboard:push', payload: { content: clipInput.trim() } })
    );
    appendLog('Pushed clipboard text to dashboard');
    setClipInput('');
  }

  function handleSendNotif() {
    if (!notifTitle.trim() || !wsRef.current) return;
    wsRef.current.send(
      JSON.stringify({
        type: 'notification:new',
        payload: {
          appName: 'Android Companion',
          title: notifTitle.trim(),
          text: notifBody.trim(),
          timestamp: Date.now(),
        },
      })
    );
    appendLog(`Synced notification: ${notifTitle}`);
    setNotifTitle('');
    setNotifBody('');
  }

  return (
    <div className="min-h-screen bg-[#F4F6F3] dark:bg-[#090B09] text-[#111713] dark:text-[#EDF2EE] p-4 sm:p-8">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={onExit}
            className="inline-flex items-center gap-2 text-sm font-medium text-[#4E5A51] dark:text-[#97A399] hover:text-[#111713] dark:hover:text-[#EDF2EE]"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard Login
          </button>
          <div className="flex items-center gap-2 font-display font-bold text-sm">
            <Shield className="w-4 h-4 text-[#3E7B4A]" />
            ARMY CONNECT Companion
          </div>
        </div>

        {!paired ? (
          <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-6 space-y-5">
            <div className="flex items-center gap-3">
              <Smartphone className="w-6 h-6 text-[#3E7B4A]" />
              <div>
                <h1 className="font-display text-xl font-bold">Pair This Device</h1>
                <p className="text-xs text-[#4E5A51] dark:text-[#97A399]">
                  Works over any Wi-Fi or mobile data connection worldwide. Enter the 6-digit pairing
                  code shown in your dashboard QR dialog.
                </p>
              </div>
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-sm text-red-600 dark:text-red-300">
                {error}
              </div>
            )}

            <form onSubmit={handlePair} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#4E5A51] dark:text-[#97A399] mb-1.5">
                  Device Name
                </label>
                <input
                  type="text"
                  required
                  value={deviceName}
                  onChange={(e) => setDeviceName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#4E5A51] dark:text-[#97A399] mb-1.5">
                  6-Digit Pairing Code
                </label>
                <input
                  type="text"
                  required
                  inputMode="numeric"
                  maxLength={6}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="123456"
                  className="w-full px-3.5 py-3 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] font-mono text-2xl text-center tracking-widest"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 px-5 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-sm font-semibold"
              >
                Connect Device Now
              </button>
            </form>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-5 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="font-display text-lg font-bold">{deviceName}</div>
                <div className="text-xs text-[#4E5A51] dark:text-[#97A399] font-mono mt-0.5 flex flex-wrap items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-[#3E7B4A]" />
                  <span>{wsConnected ? 'WSS Connected' : 'Auto-Reconnecting'}</span>
                  <span>·</span>
                  <span>{paired.approved ? 'Approved' : 'Awaiting Dashboard Approval'}</span>
                  <span>·</span>
                  <span>{p2pOpen ? describeTransportMode(p2pMode) : `E2EE ${paired.fingerprint}`}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  localStorage.removeItem(DEVICE_STORAGE_KEY);
                  setPaired(null);
                }}
                className="px-3 py-1.5 rounded-lg border border-red-500/40 text-red-600 dark:text-red-400 text-xs font-medium"
              >
                Unpair Device
              </button>
            </div>

            {ringing && (
              <div className="rounded-xl bg-red-600 text-white p-4 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <Volume2 className="w-5 h-5" />
                  <span className="font-semibold text-sm">Find My Device Alarm Active</span>
                </div>
                <button
                  type="button"
                  onClick={stopAlarm}
                  className="px-3 py-1.5 rounded-lg bg-white text-red-700 text-xs font-semibold inline-flex items-center gap-1"
                >
                  <VolumeX className="w-3.5 h-3.5" />
                  Stop Alarm
                </button>
              </div>
            )}

            <div className="grid sm:grid-cols-2 gap-3">
              <button
                type="button"
                disabled={!paired.approved}
                onClick={() => (cameraActive ? stopStreams() : startFrameStream('camera'))}
                className="flex items-center justify-center gap-2 p-3.5 rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] text-sm font-medium hover:border-[#3E7B4A] disabled:opacity-40"
              >
                <Camera className="w-4 h-4 text-[#3E7B4A]" />
                {cameraActive ? 'Stop Camera Stream' : 'Share Camera Stream'}
              </button>
              <button
                type="button"
                disabled={!paired.approved}
                onClick={() => (screenActive ? stopStreams() : startFrameStream('screen'))}
                className="flex items-center justify-center gap-2 p-3.5 rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] text-sm font-medium hover:border-[#3E7B4A] disabled:opacity-40"
              >
                <Monitor className="w-4 h-4 text-[#3E7B4A]" />
                {screenActive ? 'Stop Screen Mirror' : 'Share Screen Mirror'}
              </button>
              <button
                type="button"
                disabled={!paired.approved}
                onClick={() => pushLocation()}
                className="flex items-center justify-center gap-2 p-3.5 rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] text-sm font-medium hover:border-[#3E7B4A] disabled:opacity-40"
              >
                <MapPin className="w-4 h-4 text-[#3E7B4A]" />
                Update GPS Location
              </button>
              <label
                className={`flex items-center justify-center gap-2 p-3.5 rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] text-sm font-medium ${
                  paired.approved ? 'cursor-pointer hover:border-[#3E7B4A]' : 'opacity-40 pointer-events-none'
                }`}
              >
                <Upload className="w-4 h-4 text-[#3E7B4A]" />
                Upload File to PC
                <input type="file" className="hidden" onChange={handleFileUpload} />
              </label>
            </div>

            <video
              ref={videoRef}
              muted
              playsInline
              className={`w-full rounded-xl bg-black aspect-video object-contain ${
                cameraActive || screenActive ? 'block' : 'hidden'
              }`}
            />

            <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-4 space-y-3">
              <div className="flex items-center gap-2 text-xs font-semibold">
                <ClipboardCopy className="w-4 h-4 text-[#3E7B4A]" />
                Push Clipboard to Dashboard
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={clipInput}
                  onChange={(e) => setClipInput(e.target.value)}
                  placeholder="Paste text or link..."
                  className="flex-1 px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-sm"
                />
                <button
                  type="button"
                  disabled={!paired.approved}
                  onClick={handleSendClipboard}
                  className="px-4 py-2 rounded-lg bg-[#1E4627] dark:bg-[#2F5E38] text-white text-xs font-semibold disabled:opacity-40"
                >
                  Send
                </button>
              </div>
            </div>

            <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-4 space-y-3">
              <div className="flex items-center gap-2 text-xs font-semibold">
                <Bell className="w-4 h-4 text-[#3E7B4A]" />
                Send Notification to Dashboard
              </div>
              <div className="grid sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  value={notifTitle}
                  onChange={(e) => setNotifTitle(e.target.value)}
                  placeholder="Notification title"
                  className="px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-sm"
                />
                <input
                  type="text"
                  value={notifBody}
                  onChange={(e) => setNotifBody(e.target.value)}
                  placeholder="Message body"
                  className="px-3 py-2 rounded-lg bg-[#F4F6F3] dark:bg-[#090B09] border border-[#D7DFD8] dark:border-[#1F2921] text-sm"
                />
              </div>
              <button
                type="button"
                disabled={!paired.approved}
                onClick={handleSendNotif}
                className="px-4 py-2 rounded-lg border border-[#D7DFD8] dark:border-[#1F2921] text-xs font-medium disabled:opacity-40"
              >
                Sync Notification
              </button>
            </div>

            <div className="rounded-xl bg-white dark:bg-[#111612] border border-[#D7DFD8] dark:border-[#1F2921] p-4">
              <div className="text-xs font-semibold mb-2">Device Event Log</div>
              <div className="space-y-1 font-mono text-xs text-[#4E5A51] dark:text-[#97A399] max-h-40 overflow-y-auto">
                {log.length === 0 ? 'Waiting for events...' : log.map((l, idx) => <div key={idx}>{l}</div>)}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
