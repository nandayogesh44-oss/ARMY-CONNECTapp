import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import type { NextFunction, Request, Response } from 'express';
import { db } from './db.ts';

const SECRET_PATH = path.resolve(process.cwd(), 'data', '.jwt_secret');
const PLACEHOLDER_SECRETS = new Set([
  '',
  'change-this-to-a-long-random-secret-key',
  'MY_JWT_SECRET',
  'dev-secret',
]);

function loadJwtSecret(): string {
  const envSecret = (process.env.JWT_SECRET || '').trim();
  if (envSecret && !PLACEHOLDER_SECRETS.has(envSecret)) {
    return envSecret;
  }

  if (fs.existsSync(SECRET_PATH)) {
    const existing = fs.readFileSync(SECRET_PATH, 'utf8').trim();
    if (existing.length >= 32) {
      return existing;
    }
  }

  const generated = crypto.randomBytes(48).toString('hex');
  fs.mkdirSync(path.dirname(SECRET_PATH), { recursive: true });
  fs.writeFileSync(SECRET_PATH, generated, { mode: 0o600 });

  if (process.env.NODE_ENV === 'production') {
    console.warn(
      '[auth] JWT_SECRET env var not provided; generated persistent instance secret in data/.jwt_secret.'
    );
  } else {
    console.info(
      '[auth] Generated secure development-only JWT_SECRET (stored locally in data/.jwt_secret).'
    );
  }

  return generated;
}

export const JWT_SECRET = loadJwtSecret();

export interface AuthTokenPayload {
  userId: string;
  email: string;
  sessionId: string;
}

export interface AuthedRequest extends Request {
  auth?: AuthTokenPayload;
}

export function hashSecret(plain: string): string {
  return bcrypt.hashSync(plain, 10);
}

export function verifySecret(plain: string, hash: string): boolean {
  return bcrypt.compareSync(plain, hash);
}

export function signUserToken(payload: AuthTokenPayload, ttlHours: number): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: `${ttlHours}h` });
}

export function verifyUserToken(token: string): AuthTokenPayload | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthTokenPayload;
    if (!decoded?.userId || !decoded?.sessionId) return null;
    const session = db
      .prepare('SELECT id, expires_at, revoked_at FROM sessions WHERE id = ? AND user_id = ?')
      .get(decoded.sessionId, decoded.userId) as
      | { id: string; expires_at: number; revoked_at: number | null }
      | undefined;

    if (!session || session.revoked_at !== null || session.expires_at < Date.now()) {
      return null;
    }
    return decoded;
  } catch {
    return null;
  }
}

export function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  const queryToken = typeof req.query.token === 'string' ? req.query.token : undefined;
  const raw = header?.startsWith('Bearer ') ? header.slice(7) : queryToken;

  if (!raw) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  const verified = verifyUserToken(raw);
  if (!verified) {
    res.status(401).json({ error: 'Session expired or revoked' });
    return;
  }

  req.auth = verified;
  next();
}
