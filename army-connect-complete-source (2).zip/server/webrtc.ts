import crypto from 'node:crypto';
import { db } from './db.ts';

export const DEFAULT_PUBLIC_STUN_URLS = [
  'stun:stun.l.google.com:19302',
  'stun:stun1.l.google.com:19302',
  'stun:stun.cloudflare.com:3478',
];

export interface IceServerEntry {
  urls: string | string[];
  username?: string;
  credential?: string;
}

export interface WebRtcIceConfig {
  iceServers: IceServerEntry[];
  turnConfigured: boolean;
  fallbackMode: 'public-stun' | 'stun-and-turn';
}

interface SettingsRow {
  stun_urls: string | null;
  turn_url: string | null;
  turn_username: string | null;
  turn_credential: string | null;
}

function buildEphemeralTurnCredentials(userId: string, sharedSecret: string) {
  // Coturn REST API time-limited HMAC-SHA1 credentials (1 hour TTL)
  const unixExpiry = Math.floor(Date.now() / 1000) + 3600;
  const username = `${unixExpiry}:${userId}`;
  const credential = crypto.createHmac('sha1', sharedSecret).update(username).digest('base64');
  return { username, credential };
}

export function buildIceConfigForUser(userId: string): WebRtcIceConfig {
  const row = db
    .prepare('SELECT stun_urls, turn_url, turn_username, turn_credential FROM server_settings WHERE user_id = ?')
    .get(userId) as SettingsRow | undefined;

  let stunUrls: string[] = DEFAULT_PUBLIC_STUN_URLS;
  if (row?.stun_urls) {
    try {
      const parsed = JSON.parse(row.stun_urls);
      if (Array.isArray(parsed)) {
        const cleaned = parsed.map((u) => String(u).trim()).filter(Boolean);
        if (cleaned.length > 0) {
          stunUrls = cleaned;
        }
      }
    } catch {
      // Keep default public STUN fallback
    }
  }

  const iceServers: IceServerEntry[] = stunUrls.map((url) => ({ urls: url }));

  const turnUrl = (row?.turn_url || process.env.TURN_URL || '').trim();
  const sharedSecret = (process.env.TURN_SHARED_SECRET || '').trim();
  const staticUsername = (row?.turn_username || process.env.TURN_USERNAME || '').trim();
  const staticCredential = (row?.turn_credential || process.env.TURN_CREDENTIAL || '').trim();

  let turnConfigured = false;

  if (turnUrl) {
    if (sharedSecret) {
      const ephemeral = buildEphemeralTurnCredentials(userId, sharedSecret);
      iceServers.push({
        urls: turnUrl,
        username: ephemeral.username,
        credential: ephemeral.credential,
      });
      turnConfigured = true;
    } else if (staticUsername && staticCredential) {
      iceServers.push({
        urls: turnUrl,
        username: staticUsername,
        credential: staticCredential,
      });
      turnConfigured = true;
    } else {
      // Allow anonymous/open self-hosted TURN relays without forcing credentials
      iceServers.push({ urls: turnUrl });
      turnConfigured = true;
    }
  }

  return {
    iceServers,
    turnConfigured,
    fallbackMode: turnConfigured ? 'stun-and-turn' : 'public-stun',
  };
}
