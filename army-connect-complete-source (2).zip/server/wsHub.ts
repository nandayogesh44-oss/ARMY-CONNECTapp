import crypto from 'node:crypto';
import type { Server as HttpServer } from 'node:http';
import { WebSocket, WebSocketServer } from 'ws';
import { verifyUserToken } from './auth.ts';
import { db, logConnectionEvent } from './db.ts';

interface DashboardSocket {
  ws: WebSocket;
  userId: string;
  sessionId: string;
  isAlive: boolean;
}

interface DeviceSocket {
  ws: WebSocket;
  deviceId: string;
  userId: string;
  deviceName: string;
  approved: boolean;
  ipAddress: string;
  connectedAt: number;
  lastPongAt: number;
  isAlive: boolean;
}

interface PendingCommand {
  resolve: (data: unknown) => void;
  reject: (err: Error) => void;
  timer: ReturnType<typeof setTimeout>;
}

export class WsHub {
  private wss: WebSocketServer;
  private dashboards = new Set<DashboardSocket>();
  private devices = new Map<string, DeviceSocket>();
  private pendingCommands = new Map<string, PendingCommand>();
  private heartbeatTimer: ReturnType<typeof setInterval>;

  constructor(server: HttpServer) {
    this.wss = new WebSocketServer({ server, path: '/ws' });
    this.wss.on('connection', (ws, req) => this.handleConnection(ws, req));

    // Keep cellular & NAT WebSocket tunnels alive and reap zombie connections every 25s
    this.heartbeatTimer = setInterval(() => {
      for (const client of this.dashboards) {
        if (!client.isAlive) {
          client.ws.terminate();
          this.dashboards.delete(client);
          continue;
        }
        client.isAlive = false;
        if (client.ws.readyState === WebSocket.OPEN) {
          client.ws.ping();
        }
      }

      for (const [deviceId, dev] of this.devices.entries()) {
        if (!dev.isAlive) {
          dev.ws.terminate();
          this.devices.delete(deviceId);
          db.prepare('UPDATE devices SET online = 0, last_seen = ? WHERE id = ?').run(Date.now(), deviceId);
          this.broadcastToUser(dev.userId, {
            type: 'device:status',
            deviceId,
            online: false,
            lastSeen: Date.now(),
          });
          continue;
        }
        dev.isAlive = false;
        if (dev.ws.readyState === WebSocket.OPEN) {
          dev.ws.ping();
        }
      }
    }, 25_000);
  }

  private handleConnection(ws: WebSocket, req: import('node:http').IncomingMessage) {
    const url = new URL(req.url ?? '/ws', 'http://localhost');
    const role = url.searchParams.get('role');
    const token = url.searchParams.get('token') ?? '';
    const ip =
      (req.headers['x-forwarded-for'] as string | undefined)?.split(',')[0]?.trim() ||
      req.socket.remoteAddress ||
      '';

    if (role === 'dashboard') {
      const auth = verifyUserToken(token);
      if (!auth) {
        ws.close(4001, 'Invalid or expired dashboard session');
        return;
      }
      const client: DashboardSocket = {
        ws,
        userId: auth.userId,
        sessionId: auth.sessionId,
        isAlive: true,
      };
      this.dashboards.add(client);

      ws.on('pong', () => {
        client.isAlive = true;
      });

      ws.send(
        JSON.stringify({
          type: 'connected',
          role: 'dashboard',
          userId: auth.userId,
          onlineDeviceIds: Array.from(this.devices.values())
            .filter((d) => d.userId === auth.userId)
            .map((d) => d.deviceId),
        })
      );

      ws.on('message', (raw) => this.onDashboardMessage(client, raw.toString()));
      ws.on('close', () => {
        this.dashboards.delete(client);
      });
      return;
    }

    if (role === 'device') {
      const device = db
        .prepare('SELECT id, user_id, name, approved, network_type FROM devices WHERE device_token = ?')
        .get(token) as
        | { id: string; user_id: string; name: string; approved: number; network_type: string }
        | undefined;

      if (!device) {
        ws.close(4002, 'Invalid device token');
        return;
      }

      const existing = this.devices.get(device.id);
      if (existing && existing.ws.readyState === WebSocket.OPEN) {
        existing.ws.close(4000, 'Replaced by new device connection');
      }

      const now = Date.now();
      const devClient: DeviceSocket = {
        ws,
        deviceId: device.id,
        userId: device.user_id,
        deviceName: device.name,
        approved: Boolean(device.approved),
        ipAddress: ip,
        connectedAt: now,
        lastPongAt: now,
        isAlive: true,
      };
      this.devices.set(device.id, devClient);

      ws.on('pong', () => {
        devClient.isAlive = true;
        devClient.lastPongAt = Date.now();
      });

      db.prepare('UPDATE devices SET online = 1, last_seen = ?, ip_address = ? WHERE id = ?').run(
        now,
        ip,
        device.id
      );

      logConnectionEvent({
        id: crypto.randomUUID(),
        userId: device.user_id,
        deviceId: device.id,
        deviceName: device.name,
        event: 'connected',
        ipAddress: ip,
        networkType: device.network_type || 'Internet',
        details: device.approved
          ? 'Device connected via encrypted WebSocket'
          : 'Device connected (awaiting explicit owner approval)',
      });

      this.broadcastToUser(device.user_id, {
        type: 'device:status',
        deviceId: device.id,
        online: true,
        approved: Boolean(device.approved),
        lastSeen: now,
        ipAddress: ip,
      });

      ws.send(
        JSON.stringify({
          type: 'connected',
          role: 'device',
          deviceId: device.id,
          approved: Boolean(device.approved),
        })
      );

      ws.on('message', (raw) => this.onDeviceMessage(devClient, raw.toString()));
      ws.on('close', () => {
        const current = this.devices.get(device.id);
        if (current?.ws === ws) {
          this.devices.delete(device.id);
          db.prepare('UPDATE devices SET online = 0, last_seen = ? WHERE id = ?').run(Date.now(), device.id);
          logConnectionEvent({
            id: crypto.randomUUID(),
            userId: device.user_id,
            deviceId: device.id,
            deviceName: device.name,
            event: 'disconnected',
            ipAddress: ip,
            details: 'WebSocket connection closed',
          });
          this.broadcastToUser(device.user_id, {
            type: 'device:status',
            deviceId: device.id,
            online: false,
            lastSeen: Date.now(),
          });
        }
      });
      return;
    }

    ws.close(4003, 'Unknown WebSocket role');
  }

  private onDashboardMessage(client: DashboardSocket, raw: string) {
    try {
      const msg = JSON.parse(raw) as { type: string; deviceId?: string; [key: string]: unknown };
      if (!msg.type) return;

      client.isAlive = true;

      if (msg.type === 'ping') {
        client.ws.send(JSON.stringify({ type: 'pong', ts: Date.now() }));
        return;
      }

      if (msg.deviceId) {
        const dev = this.devices.get(msg.deviceId);
        if (!dev || dev.userId !== client.userId) return;

        const row = db
          .prepare('SELECT approved FROM devices WHERE id = ? AND user_id = ?')
          .get(msg.deviceId, client.userId) as { approved: number } | undefined;
        if (!row || !row.approved) return;

        if (dev.ws.readyState === WebSocket.OPEN) {
          dev.ws.send(JSON.stringify({ ...msg, fromSessionId: client.sessionId }));
        }
      }
    } catch {
      // Ignore malformed JSON payloads
    }
  }

  private onDeviceMessage(dev: DeviceSocket, raw: string) {
    try {
      const msg = JSON.parse(raw) as {
        type: string;
        commandId?: string;
        payload?: Record<string, unknown>;
        [key: string]: unknown;
      };
      if (!msg.type) return;

      dev.isAlive = true;
      dev.lastPongAt = Date.now();

      if (msg.type === 'ping') {
        db.prepare('UPDATE devices SET online = 1, last_seen = ? WHERE id = ?').run(Date.now(), dev.deviceId);
        dev.ws.send(JSON.stringify({ type: 'pong', ts: Date.now(), approved: dev.approved }));
        return;
      }

      // Enforce explicit approval before accepting telemetry, WebRTC signaling, or data pushes
      if (!dev.approved) {
        const row = db
          .prepare('SELECT approved FROM devices WHERE id = ?')
          .get(dev.deviceId) as { approved: number } | undefined;
        if (!row?.approved) {
          dev.ws.send(
            JSON.stringify({
              type: 'error',
              code: 'DEVICE_PENDING_APPROVAL',
              message: 'Device awaits explicit approval on the Web Dashboard.',
            })
          );
          return;
        }
        dev.approved = true;
      }

      if (msg.type === 'command:result' && msg.commandId) {
        const pending = this.pendingCommands.get(msg.commandId);
        if (pending) {
          clearTimeout(pending.timer);
          this.pendingCommands.delete(msg.commandId);
          pending.resolve(msg.payload ?? msg);
        }
        return;
      }

      if (msg.type === 'device:telemetry' && msg.payload) {
        const p = msg.payload;
        db.prepare(`
          UPDATE devices SET
            online = 1,
            last_seen = ?,
            battery_level = COALESCE(?, battery_level),
            is_charging = COALESCE(?, is_charging),
            battery_temp = COALESCE(?, battery_temp),
            storage_used = COALESCE(?, storage_used),
            storage_total = COALESCE(?, storage_total),
            ram_used = COALESCE(?, ram_used),
            ram_total = COALESCE(?, ram_total),
            wifi_ssid = COALESCE(?, wifi_ssid),
            wifi_strength = COALESCE(?, wifi_strength),
            network_type = COALESCE(?, network_type),
            latitude = COALESCE(?, latitude),
            longitude = COALESCE(?, longitude),
            location_accuracy = COALESCE(?, location_accuracy),
            location_updated_at = CASE WHEN ? IS NOT NULL THEN ? ELSE location_updated_at END,
            android_version = COALESCE(?, android_version),
            model = COALESCE(?, model),
            manufacturer = COALESCE(?, manufacturer)
          WHERE id = ?
        `).run(
          Date.now(),
          typeof p.batteryLevel === 'number' ? p.batteryLevel : null,
          typeof p.isCharging === 'boolean' ? (p.isCharging ? 1 : 0) : null,
          typeof p.batteryTemp === 'number' ? p.batteryTemp : null,
          typeof p.storageUsed === 'number' ? p.storageUsed : null,
          typeof p.storageTotal === 'number' ? p.storageTotal : null,
          typeof p.ramUsed === 'number' ? p.ramUsed : null,
          typeof p.ramTotal === 'number' ? p.ramTotal : null,
          typeof p.wifiSsid === 'string' ? p.wifiSsid : null,
          typeof p.wifiStrength === 'number' ? p.wifiStrength : null,
          typeof p.networkType === 'string' ? p.networkType : null,
          typeof p.latitude === 'number' ? p.latitude : null,
          typeof p.longitude === 'number' ? p.longitude : null,
          typeof p.locationAccuracy === 'number' ? p.locationAccuracy : null,
          typeof p.latitude === 'number' ? Date.now() : null,
          Date.now(),
          typeof p.androidVersion === 'string' ? p.androidVersion : null,
          typeof p.model === 'string' ? p.model : null,
          typeof p.manufacturer === 'string' ? p.manufacturer : null,
          dev.deviceId
        );

        this.broadcastToUser(dev.userId, {
          type: 'device:telemetry',
          deviceId: dev.deviceId,
          payload: p,
          lastSeen: Date.now(),
        });
        return;
      }

      if (msg.type === 'notification:new' && msg.payload) {
        const p = msg.payload;
        const id = typeof p.id === 'string' ? p.id : crypto.randomUUID();
        db.prepare(`
          INSERT OR REPLACE INTO device_notifications (id, device_id, app_name, package_name, title, text, timestamp, dismissed)
          VALUES (?, ?, ?, ?, ?, ?, ?, 0)
        `).run(
          id,
          dev.deviceId,
          String(p.appName ?? 'Android System'),
          String(p.packageName ?? ''),
          String(p.title ?? 'Notification'),
          String(p.text ?? ''),
          typeof p.timestamp === 'number' ? p.timestamp : Date.now()
        );
        this.broadcastToUser(dev.userId, {
          type: 'notification:new',
          deviceId: dev.deviceId,
          notification: { id, ...p, timestamp: typeof p.timestamp === 'number' ? p.timestamp : Date.now() },
        });
        return;
      }

      if (msg.type === 'clipboard:push' && msg.payload) {
        const content = String(msg.payload.content ?? '');
        if (content) {
          const item = {
            id: crypto.randomUUID(),
            user_id: dev.userId,
            device_id: dev.deviceId,
            source: dev.deviceName,
            content,
            encrypted: msg.payload.encrypted ? 1 : 0,
            created_at: Date.now(),
          };
          db.prepare(`
            INSERT INTO clipboard_items (id, user_id, device_id, source, content, encrypted, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
          `).run(item.id, item.user_id, item.device_id, item.source, item.content, item.encrypted, item.created_at);

          this.broadcastToUser(dev.userId, {
            type: 'clipboard:new',
            item,
          });
        }
        return;
      }

      this.broadcastToUser(dev.userId, {
        ...msg,
        deviceId: dev.deviceId,
      });
    } catch {
      // Ignore malformed payloads
    }
  }

  public approveDevice(deviceId: string) {
    const dev = this.devices.get(deviceId);
    if (dev) {
      dev.approved = true;
    }
    this.sendToDevice(deviceId, { type: 'device:approved', approved: true });
  }

  public isDeviceOnline(deviceId: string): boolean {
    const dev = this.devices.get(deviceId);
    return Boolean(dev && dev.ws.readyState === WebSocket.OPEN);
  }

  public getDeviceSessionInfo(deviceId: string) {
    const dev = this.devices.get(deviceId);
    if (!dev || dev.ws.readyState !== WebSocket.OPEN) {
      return {
        online: false,
        approved: false,
        connectedAt: null,
        lastPongAt: null,
        ipAddress: null,
      };
    }
    return {
      online: true,
      approved: dev.approved,
      connectedAt: dev.connectedAt,
      lastPongAt: dev.lastPongAt,
      ipAddress: dev.ipAddress,
    };
  }

  public broadcastToUser(userId: string, data: unknown) {
    const serialized = JSON.stringify(data);
    for (const d of this.dashboards) {
      if (d.userId === userId && d.ws.readyState === WebSocket.OPEN) {
        d.ws.send(serialized);
      }
    }
  }

  public revokeUserSession(sessionId: string) {
    for (const d of this.dashboards) {
      if (d.sessionId === sessionId && d.ws.readyState === WebSocket.OPEN) {
        d.ws.send(JSON.stringify({ type: 'session:revoked' }));
        d.ws.close(4004, 'Session terminated');
      }
    }
  }

  public disconnectDevice(deviceId: string, reason = 'Disconnected by user') {
    const dev = this.devices.get(deviceId);
    if (dev && dev.ws.readyState === WebSocket.OPEN) {
      dev.ws.send(JSON.stringify({ type: 'device:force_disconnect', reason }));
      dev.ws.close(4005, reason);
    }
    this.devices.delete(deviceId);
    db.prepare('UPDATE devices SET online = 0, last_seen = ? WHERE id = ?').run(Date.now(), deviceId);
  }

  public sendToDevice(deviceId: string, message: Record<string, unknown>): boolean {
    const dev = this.devices.get(deviceId);
    if (!dev || dev.ws.readyState !== WebSocket.OPEN) return false;
    dev.ws.send(JSON.stringify(message));
    return true;
  }

  public sendCommand(
    deviceId: string,
    command: string,
    payload: Record<string, unknown> = {},
    timeoutMs = 8000
  ): Promise<unknown> {
    const dev = this.devices.get(deviceId);
    if (!dev || dev.ws.readyState !== WebSocket.OPEN) {
      return Promise.reject(new Error('Device is offline'));
    }
    if (!dev.approved) {
      return Promise.reject(new Error('Device awaits explicit dashboard approval'));
    }
    const commandId = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingCommands.delete(commandId);
        reject(new Error(`Device command '${command}' timed out`));
      }, timeoutMs);

      this.pendingCommands.set(commandId, { resolve, reject, timer });
      dev.ws.send(
        JSON.stringify({
          type: 'command',
          commandId,
          command,
          payload,
        })
      );
    });
  }
}
