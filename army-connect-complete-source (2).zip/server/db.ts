import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
export const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
export const DOWNLOADS_DIR = path.resolve(process.cwd(), 'public', 'downloads');

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOADS_DIR, { recursive: true });
fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });

const dbPath = path.join(DATA_DIR, 'army_connect.db');
export const db = new Database(dbPath);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    pin_hash TEXT,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    label TEXT NOT NULL,
    ip_address TEXT,
    user_agent TEXT,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    revoked_at INTEGER,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS pairing_tokens (
    code TEXT PRIMARY KEY,
    token TEXT UNIQUE NOT NULL,
    user_id TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    claimed_device_id TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS devices (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    manufacturer TEXT DEFAULT 'Android',
    model TEXT DEFAULT 'Mobile Device',
    android_version TEXT DEFAULT '16',
    api_level INTEGER DEFAULT 36,
    device_token TEXT UNIQUE NOT NULL,
    approved INTEGER NOT NULL DEFAULT 1,
    online INTEGER NOT NULL DEFAULT 0,
    last_seen INTEGER NOT NULL,
    battery_level INTEGER DEFAULT 100,
    is_charging INTEGER DEFAULT 0,
    battery_temp REAL DEFAULT 31.0,
    storage_used INTEGER DEFAULT 0,
    storage_total INTEGER DEFAULT 0,
    ram_used INTEGER DEFAULT 0,
    ram_total INTEGER DEFAULT 0,
    wifi_ssid TEXT DEFAULT '',
    wifi_strength INTEGER DEFAULT 0,
    network_type TEXT DEFAULT 'Unknown',
    ip_address TEXT DEFAULT '',
    latitude REAL,
    longitude REAL,
    location_accuracy REAL,
    location_updated_at INTEGER,
    permissions_json TEXT NOT NULL,
    e2ee_enabled INTEGER NOT NULL DEFAULT 1,
    e2ee_fingerprint TEXT DEFAULT '',
    created_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS device_files (
    id TEXT PRIMARY KEY,
    device_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    folder TEXT NOT NULL DEFAULT '/',
    name TEXT NOT NULL,
    path TEXT NOT NULL,
    size INTEGER NOT NULL DEFAULT 0,
    mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
    category TEXT NOT NULL DEFAULT 'document',
    stored_filename TEXT,
    is_directory INTEGER NOT NULL DEFAULT 0,
    source TEXT NOT NULL DEFAULT 'vault',
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS device_contacts (
    id TEXT PRIMARY KEY,
    device_id TEXT NOT NULL,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT DEFAULT '',
    organization TEXT DEFAULT '',
    updated_at INTEGER NOT NULL,
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS device_messages (
    id TEXT PRIMARY KEY,
    device_id TEXT NOT NULL,
    address TEXT NOT NULL,
    contact_name TEXT DEFAULT '',
    body TEXT NOT NULL,
    direction TEXT NOT NULL DEFAULT 'incoming',
    status TEXT NOT NULL DEFAULT 'received',
    timestamp INTEGER NOT NULL,
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS device_calls (
    id TEXT PRIMARY KEY,
    device_id TEXT NOT NULL,
    number TEXT NOT NULL,
    contact_name TEXT DEFAULT '',
    call_type TEXT NOT NULL DEFAULT 'incoming',
    duration_sec INTEGER NOT NULL DEFAULT 0,
    timestamp INTEGER NOT NULL,
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS device_notifications (
    id TEXT PRIMARY KEY,
    device_id TEXT NOT NULL,
    app_name TEXT NOT NULL,
    package_name TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL,
    text TEXT NOT NULL DEFAULT '',
    timestamp INTEGER NOT NULL,
    dismissed INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS clipboard_items (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    device_id TEXT,
    source TEXT NOT NULL,
    content TEXT NOT NULL,
    encrypted INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS connection_history (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    device_id TEXT,
    device_name TEXT NOT NULL,
    event TEXT NOT NULL,
    ip_address TEXT DEFAULT '',
    network_type TEXT DEFAULT '',
    details TEXT DEFAULT '',
    created_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS server_settings (
    user_id TEXT PRIMARY KEY,
    stun_urls TEXT NOT NULL DEFAULT '["stun:stun.l.google.com:19302","stun:stun1.l.google.com:19302"]',
    turn_url TEXT DEFAULT '',
    turn_username TEXT DEFAULT '',
    turn_credential TEXT DEFAULT '',
    session_ttl_hours INTEGER NOT NULL DEFAULT 168,
    require_device_approval INTEGER NOT NULL DEFAULT 1,
    require_pin_sensitive INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

db.prepare('UPDATE devices SET online = 0').run();

export const DEFAULT_PERMISSIONS = {
  files: true,
  media: true,
  contacts: true,
  sms: true,
  calls: true,
  notifications: true,
  camera: true,
  screen: true,
  location: true,
  clipboard: true,
  ring: true,
};

export function logConnectionEvent(params: {
  id: string;
  userId: string;
  deviceId: string | null;
  deviceName: string;
  event: string;
  ipAddress?: string;
  networkType?: string;
  details?: string;
}) {
  db.prepare(`
    INSERT INTO connection_history (id, user_id, device_id, device_name, event, ip_address, network_type, details, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    params.id,
    params.userId,
    params.deviceId,
    params.deviceName,
    params.event,
    params.ipAddress ?? '',
    params.networkType ?? '',
    params.details ?? '',
    Date.now()
  );
}
