package com.armyconnect.app.network

import android.os.Build
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

data class PairingResponse(
    val deviceId: String,
    val deviceToken: String,
    val approved: Boolean,
    val e2eeFingerprint: String,
    val serverUrl: String
)

data class RemoteFileEntry(
    val id: String = "",
    val name: String = "",
    val folder: String = "/",
    val size: Long = 0L,
    val mimeType: String = "application/octet-stream"
)

object ArmyApiClient {
    val gson = Gson()
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()

    fun loginAndPair(
        serverUrl: String,
        email: String,
        password: String,
        deviceName: String,
        existingDeviceId: String?,
        registerName: String? = null
    ): Result<PairingResponse> = runCatching {
        val base = serverUrl.trimEnd('/')
        val authPath = if (registerName.isNullOrBlank()) "/api/auth/login" else "/api/auth/register"
        val authPayload = if (registerName.isNullOrBlank()) {
            mapOf("email" to email.trim(), "password" to password, "label" to "Android App ($deviceName)")
        } else {
            mapOf("name" to registerName.trim(), "email" to email.trim(), "password" to password)
        }

        val authReq = Request.Builder()
            .url("$base$authPath")
            .post(gson.toJson(authPayload).toRequestBody(JSON))
            .build()

        val mapType = object : TypeToken<Map<String, Any?>>() {}.type
        val userToken = http.newCall(authReq).execute().use { res ->
            val raw = res.body?.string().orEmpty()
            val parsed: Map<String, Any?>? = runCatching { gson.fromJson<Map<String, Any?>>(raw, mapType) }.getOrNull()
            if (!res.isSuccessful) {
                throw IllegalStateException(parsed?.get("error")?.toString() ?: "Authentication failed (${res.code})")
            }
            parsed?.get("token")?.toString() ?: throw IllegalStateException("Missing auth token")
        }

        val pairCreateReq = Request.Builder()
            .url("$base/api/pairing/create")
            .header("Authorization", "Bearer $userToken")
            .post("{}".toRequestBody(JSON))
            .build()

        val code = http.newCall(pairCreateReq).execute().use { res ->
            val raw = res.body?.string().orEmpty()
            val parsed: Map<String, Any?>? = runCatching { gson.fromJson<Map<String, Any?>>(raw, mapType) }.getOrNull()
            if (!res.isSuccessful) {
                throw IllegalStateException(parsed?.get("error")?.toString() ?: "Failed to create pairing code")
            }
            parsed?.get("code")?.toString() ?: throw IllegalStateException("Missing pairing code")
        }

        val claim = claimPairing(base, code, null, deviceName, existingDeviceId).getOrThrow()

        if (!claim.approved) {
            val approveReq = Request.Builder()
                .url("$base/api/devices/${claim.deviceId}/approve")
                .header("Authorization", "Bearer $userToken")
                .post("{\"approved\":true}".toRequestBody(JSON))
                .build()
            http.newCall(approveReq).execute().close()
            claim.copy(approved = true)
        } else {
            claim
        }
    }

    fun claimPairing(
        serverUrl: String,
        code: String?,
        token: String?,
        deviceName: String,
        existingDeviceId: String?
    ): Result<PairingResponse> = runCatching {
        val bodyMap = mapOf(
            "code" to (code ?: ""),
            "token" to (token ?: ""),
            "name" to deviceName,
            "manufacturer" to Build.MANUFACTURER,
            "model" to Build.MODEL,
            "androidVersion" to Build.VERSION.RELEASE,
            "apiLevel" to Build.VERSION.SDK_INT,
            "deviceId" to existingDeviceId
        )
        val req = Request.Builder()
            .url("${serverUrl.trimEnd('/')}/api/pairing/claim")
            .post(gson.toJson(bodyMap).toRequestBody(JSON))
            .build()

        http.newCall(req).execute().use { res ->
            val raw = res.body?.string().orEmpty()
            if (!res.isSuccessful) {
                val mapType = object : TypeToken<Map<String, Any>>() {}.type
                val errMap: Map<String, Any>? = runCatching { gson.fromJson<Map<String, Any>>(raw, mapType) }.getOrNull()
                throw IllegalStateException(errMap?.get("error")?.toString() ?: "Pairing failed (${res.code})")
            }
            gson.fromJson(raw, PairingResponse::class.java)
        }
    }

    fun postJson(serverUrl: String, path: String, deviceToken: String, payload: Any): Boolean {
        return runCatching {
            val req = Request.Builder()
                .url("${serverUrl.trimEnd('/')}$path")
                .header("x-device-token", deviceToken)
                .post(gson.toJson(payload).toRequestBody(JSON))
                .build()
            http.newCall(req).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    fun uploadFile(serverUrl: String, deviceToken: String, file: File, folder: String = "/PhoneUploads"): Boolean {
        if (!file.exists() || !file.isFile) return false
        return runCatching {
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("folder", folder)
                .addFormDataPart("file", file.name, file.asRequestBody("application/octet-stream".toMediaType()))
                .build()
            val req = Request.Builder()
                .url("${serverUrl.trimEnd('/')}/api/device/files/upload")
                .header("x-device-token", deviceToken)
                .post(body)
                .build()
            http.newCall(req).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    fun listTransferredFiles(serverUrl: String, deviceToken: String): List<RemoteFileEntry> {
        return runCatching {
            val req = Request.Builder()
                .url("${serverUrl.trimEnd('/')}/api/device/files")
                .header("x-device-token", deviceToken)
                .get()
                .build()
            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return emptyList()
                val raw = res.body?.string().orEmpty()
                val mapType = object : TypeToken<Map<String, List<RemoteFileEntry>>>() {}.type
                val parsed: Map<String, List<RemoteFileEntry>> = gson.fromJson(raw, mapType)
                parsed["files"] ?: emptyList()
            }
        }.getOrDefault(emptyList())
    }

    fun downloadFile(serverUrl: String, deviceToken: String, fileId: String, destFile: File): Boolean {
        return runCatching {
            val req = Request.Builder()
                .url("${serverUrl.trimEnd('/')}/api/device/files/$fileId/download")
                .header("x-device-token", deviceToken)
                .get()
                .build()
            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return false
                val body = res.body ?: return false
                destFile.parentFile?.mkdirs()
                body.byteStream().use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }
                true
            }
        }.getOrDefault(false)
    }

    fun fetchIceServers(serverUrl: String, deviceToken: String): List<Map<String, Any>> {
        val fallback = listOf(
            mapOf("urls" to "stun:stun.l.google.com:19302"),
            mapOf("urls" to "stun:stun1.l.google.com:19302")
        )
        return runCatching {
            val req = Request.Builder()
                .url("${serverUrl.trimEnd('/')}/api/device/webrtc/ice-servers")
                .header("x-device-token", deviceToken)
                .get()
                .build()
            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return fallback
                val raw = res.body?.string().orEmpty()
                val mapType = object : TypeToken<Map<String, Any>>() {}.type
                val parsed: Map<String, Any> = gson.fromJson(raw, mapType)
                @Suppress("UNCHECKED_CAST")
                (parsed["iceServers"] as? List<Map<String, Any>>)?.takeIf { it.isNotEmpty() } ?: fallback
            }
        }.getOrDefault(fallback)
    }
}
