package com.armyconnect.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.armyconnect.app.data.SecurePrefs
import com.armyconnect.app.network.ArmyApiClient
import com.armyconnect.app.network.RemoteFileEntry
import com.armyconnect.app.service.ConnectForegroundService
import com.armyconnect.app.service.ScreenMirrorService
import com.armyconnect.app.ui.ArmyConnectTheme
import com.armyconnect.app.ui.QrScannerView
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = SecurePrefs(this)
        if (prefs.isPaired()) {
            ContextCompat.startForegroundService(
                this,
                Intent(this, ConnectForegroundService::class.java).setAction(ConnectForegroundService.ACTION_START)
            )
        }
        setContent {
            ArmyConnectRoot(prefs)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArmyConnectRoot(prefs: SecurePrefs) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var darkTheme by remember { mutableStateOf(prefs.darkMode) }
    var isPaired by remember { mutableStateOf(prefs.isPaired()) }
    var serverUrl by remember { mutableStateOf(prefs.serverUrl) }
    var deviceName by remember { mutableStateOf(prefs.deviceName) }

    var authTab by remember { mutableStateOf(0) } // 0 = Login, 1 = QR / Code Pairing
    var operatorName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(prefs.operatorEmail) }
    var password by remember { mutableStateOf("") }
    var registerMode by remember { mutableStateOf(false) }

    var pairingCode by remember { mutableStateOf("") }
    var showScanner by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var remoteFiles by remember { mutableStateOf<List<RemoteFileEntry>>(emptyList()) }

    val connected by ConnectForegroundService.connectionState.collectAsState()
    val logs by ConnectForegroundService.eventLogs.collectAsState()

    fun refreshRemoteFiles() {
        val token = prefs.deviceToken ?: return
        scope.launch {
            val list = withContext(Dispatchers.IO) {
                ArmyApiClient.listTransferredFiles(prefs.serverUrl, token)
            }
            remoteFiles = list
        }
    }

    LaunchedEffect(isPaired, connected) {
        if (isPaired) refreshRemoteFiles()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val grantedCount = results.values.count { it }
        statusMessage = "Permissions updated ($grantedCount granted)"
    }

    val cameraForQrLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) showScanner = true
        else statusMessage = "Camera permission is needed to scan QR codes"
    }

    val screenCaptureLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val svc = Intent(context, ScreenMirrorService::class.java).apply {
                putExtra(ScreenMirrorService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenMirrorService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, svc)
            statusMessage = "Screen mirroring started"
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            statusMessage = "Uploading file securely..."
            val uploaded = withContext(Dispatchers.IO) {
                val token = prefs.deviceToken ?: return@withContext false
                var displayName = "upload_${System.currentTimeMillis()}"
                context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && c.moveToFirst()) {
                        displayName = c.getString(idx) ?: displayName
                    }
                }
                val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val tempFile = File(context.cacheDir, safeName)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { output -> input.copyTo(output) }
                }
                val ok = ArmyApiClient.uploadFile(prefs.serverUrl, token, tempFile)
                tempFile.delete()
                ok
            }
            statusMessage = if (uploaded) {
                refreshRemoteFiles()
                "File uploaded to ARMY CONNECT dashboard"
            } else {
                "File upload failed"
            }
        }
    }

    fun startConnectedService(
        targetServer: String,
        deviceId: String,
        deviceToken: String,
        approved: Boolean,
        fingerprint: String
    ) {
        prefs.serverUrl = targetServer
        prefs.deviceName = deviceName
        prefs.deviceId = deviceId
        prefs.deviceToken = deviceToken
        prefs.approved = approved
        prefs.e2eeFingerprint = fingerprint
        isPaired = true
        statusMessage = if (approved) "Connected securely" else "Paired! Approve device on Web Dashboard"
        ContextCompat.startForegroundService(
            context,
            Intent(context, ConnectForegroundService::class.java).setAction(ConnectForegroundService.ACTION_START)
        )
    }

    fun performLogin() {
        scope.launch {
            busy = true
            statusMessage = if (registerMode) "Creating account & pairing..." else "Signing in & pairing..."
            val result = withContext(Dispatchers.IO) {
                ArmyApiClient.loginAndPair(
                    serverUrl = serverUrl,
                    email = email,
                    password = password,
                    deviceName = deviceName,
                    existingDeviceId = prefs.deviceId,
                    registerName = if (registerMode) operatorName else null
                )
            }
            busy = false
            result.onSuccess { res ->
                prefs.operatorEmail = email
                startConnectedService(
                    targetServer = serverUrl,
                    deviceId = res.deviceId,
                    deviceToken = res.deviceToken,
                    approved = res.approved,
                    fingerprint = res.e2eeFingerprint
                )
            }.onFailure { err ->
                statusMessage = err.message ?: "Login failed"
            }
        }
    }

    fun performPairing(targetServer: String, code: String?, token: String?) {
        scope.launch {
            busy = true
            statusMessage = "Pairing device..."
            val result = withContext(Dispatchers.IO) {
                ArmyApiClient.claimPairing(
                    serverUrl = targetServer,
                    code = code,
                    token = token,
                    deviceName = deviceName,
                    existingDeviceId = prefs.deviceId
                )
            }
            busy = false
            result.onSuccess { res ->
                startConnectedService(
                    targetServer = targetServer,
                    deviceId = res.deviceId,
                    deviceToken = res.deviceToken,
                    approved = res.approved,
                    fingerprint = res.e2eeFingerprint
                )
            }.onFailure { err ->
                statusMessage = err.message ?: "Pairing failed"
            }
        }
    }

    ArmyConnectTheme(darkTheme = darkTheme) {
        if (showScanner) {
            QrScannerView(
                onQrScanned = { raw ->
                    showScanner = false
                    val mapType = object : TypeToken<Map<String, Any>>() {}.type
                    val parsed: Map<String, Any>? = runCatching {
                        ArmyApiClient.gson.fromJson<Map<String, Any>>(raw, mapType)
                    }.getOrNull()
                    if (parsed != null && parsed["app"] == "ARMY_CONNECT") {
                        val srv = parsed["serverUrl"]?.toString() ?: serverUrl
                        val qrToken = parsed["token"]?.toString()
                        val qrCode = parsed["code"]?.toString()
                        serverUrl = srv
                        performPairing(srv, qrCode, qrToken)
                    } else {
                        statusMessage = "Unrecognized QR code"
                    }
                },
                onCancel = { showScanner = false }
            )
            return@ArmyConnectTheme
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(Modifier.width(8.dp))
                            Text("ARMY CONNECT", fontWeight = FontWeight.Bold)
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            darkTheme = !darkTheme
                            prefs.darkMode = darkTheme
                        }) {
                            Icon(
                                if (darkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Toggle Theme"
                            )
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (statusMessage.isNotBlank()) {
                    item {
                        Card {
                            Text(
                                text = statusMessage,
                                modifier = Modifier.padding(12.dp),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                if (!isPaired) {
                    item {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                TabRow(selectedTabIndex = authTab) {
                                    Tab(
                                        selected = authTab == 0,
                                        onClick = { authTab = 0 },
                                        text = { Text("Account Login") }
                                    )
                                    Tab(
                                        selected = authTab == 1,
                                        onClick = { authTab = 1 },
                                        text = { Text("QR / Code Pair") }
                                    )
                                }

                                OutlinedTextField(
                                    value = serverUrl,
                                    onValueChange = { serverUrl = it },
                                    label = { Text("Server URL") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = deviceName,
                                    onValueChange = { deviceName = it },
                                    label = { Text("Device Name") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                if (authTab == 0) {
                                    if (registerMode) {
                                        OutlinedTextField(
                                            value = operatorName,
                                            onValueChange = { operatorName = it },
                                            label = { Text("Operator Name") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                    OutlinedTextField(
                                        value = email,
                                        onValueChange = { email = it },
                                        label = { Text("Email Address") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    OutlinedTextField(
                                        value = password,
                                        onValueChange = { password = it },
                                        label = { Text("Password") },
                                        singleLine = true,
                                        visualTransformation = PasswordVisualTransformation(),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Button(
                                        onClick = { performLogin() },
                                        enabled = !busy && email.isNotBlank() && password.length >= 6 && (!registerMode || operatorName.isNotBlank()),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            if (busy) "Connecting..."
                                            else if (registerMode) "Create Account & Connect"
                                            else "Sign In & Connect"
                                        )
                                    }
                                    TextButton(
                                        onClick = { registerMode = !registerMode },
                                        modifier = Modifier.align(Alignment.CenterHorizontally)
                                    ) {
                                        Text(if (registerMode) "Already have an account? Sign In" else "Need an account? Create One")
                                    }
                                } else {
                                    OutlinedTextField(
                                        value = pairingCode,
                                        onValueChange = { pairingCode = it.filter(Char::isDigit).take(6) },
                                        label = { Text("6-Digit Pairing Code") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { cameraForQrLauncher.launch(Manifest.permission.CAMERA) },
                                            enabled = !busy,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                                            Spacer(Modifier.width(6.dp))
                                            Text("Scan QR")
                                        }
                                        Button(
                                            onClick = { performPairing(serverUrl, pairingCode, null) },
                                            enabled = !busy && pairingCode.length == 6,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(if (busy) "Connecting..." else "Pair Code")
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    item {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(prefs.deviceName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            if (connected) "Status: Online" else "Status: Reconnecting",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    OutlinedButton(onClick = {
                                        context.startService(
                                            Intent(context, ConnectForegroundService::class.java)
                                                .setAction(ConnectForegroundService.ACTION_STOP)
                                        )
                                        prefs.clearPairing()
                                        isPaired = false
                                        remoteFiles = emptyList()
                                        statusMessage = "Device disconnected"
                                    }) {
                                        Text("Disconnect")
                                    }
                                }
                                Text(
                                    "E2EE Fingerprint: ${prefs.e2eeFingerprint}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    item {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("Secure File Transfer & Sync", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { filePickerLauncher.launch("*/*") },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Upload File")
                                    }
                                    Button(
                                        onClick = {
                                            refreshRemoteFiles()
                                            context.startService(
                                                Intent(context, ConnectForegroundService::class.java)
                                                    .setAction(ConnectForegroundService.ACTION_SYNC_ALL)
                                            )
                                            statusMessage = "Sync triggered"
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Sync & Refresh")
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                                            screenCaptureLauncher.launch(mpm.createScreenCaptureIntent())
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Share Screen")
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            context.startService(
                                                Intent(context, ConnectForegroundService::class.java)
                                                    .setAction(ConnectForegroundService.ACTION_STOP_RING)
                                            )
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Silence Alarm")
                                    }
                                }
                            }
                        }
                    }

                    if (remoteFiles.isNotEmpty()) {
                        item {
                            Text("Transferred Files (${remoteFiles.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        items(remoteFiles.take(15)) { fileItem ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(fileItem.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                        Text(
                                            "${fileItem.folder} · ${fileItem.size} bytes",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Spacer(Modifier.width(8.dp))
                                    OutlinedButton(onClick = {
                                        scope.launch {
                                            statusMessage = "Downloading ${fileItem.name}..."
                                            val token = prefs.deviceToken ?: return@launch
                                            val targetDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
                                            val dest = File(targetDir, fileItem.name)
                                            val ok = withContext(Dispatchers.IO) {
                                                ArmyApiClient.downloadFile(prefs.serverUrl, token, fileItem.id, dest)
                                            }
                                            statusMessage = if (ok) "Saved to ${dest.absolutePath}" else "Download failed"
                                        }
                                    }) {
                                        Text("Save")
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Permissions & Privacy", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Button(
                                onClick = {
                                    val perms = buildList {
                                        add(Manifest.permission.CAMERA)
                                        add(Manifest.permission.ACCESS_FINE_LOCATION)
                                        add(Manifest.permission.READ_CONTACTS)
                                        add(Manifest.permission.READ_SMS)
                                        add(Manifest.permission.SEND_SMS)
                                        add(Manifest.permission.READ_CALL_LOG)
                                        if (Build.VERSION.SDK_INT >= 33) {
                                            add(Manifest.permission.POST_NOTIFICATIONS)
                                            add(Manifest.permission.READ_MEDIA_IMAGES)
                                            add(Manifest.permission.READ_MEDIA_VIDEO)
                                            add(Manifest.permission.READ_MEDIA_AUDIO)
                                        } else {
                                            add(Manifest.permission.READ_EXTERNAL_STORAGE)
                                        }
                                    }.toTypedArray()
                                    permissionLauncher.launch(perms)
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Grant Android Permissions")
                            }
                            OutlinedButton(
                                onClick = {
                                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Enable Notification Mirroring Access")
                            }
                        }
                    }
                }

                if (logs.isNotEmpty()) {
                    item {
                        Text("Recent Activity", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                    items(logs) { line ->
                        Text(line, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}
