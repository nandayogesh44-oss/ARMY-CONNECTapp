package com.armyconnect.app.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class ArmyNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val appName = runCatching {
            val pm = packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        }.getOrDefault(sbn.packageName)

        ConnectForegroundService.sendWs(
            mapOf(
                "type" to "notification:new",
                "payload" to mapOf(
                    "id" to "${sbn.key}_${sbn.postTime}",
                    "appName" to appName,
                    "packageName" to sbn.packageName,
                    "title" to title,
                    "text" to text,
                    "timestamp" to sbn.postTime
                )
            )
        )
    }
}
