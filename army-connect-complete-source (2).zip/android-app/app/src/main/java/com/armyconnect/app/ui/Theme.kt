package com.armyconnect.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ArmyBlack = Color(0xFF090B09)
val ArmySurfaceDark = Color(0xFF111612)
val ArmyOlive = Color(0xFF2F5E38)
val ArmyOliveBright = Color(0xFF3E7B4A)
val ArmyTextDark = Color(0xFFEDF2EE)

val ArmyLightBg = Color(0xFFF4F6F3)
val ArmyLightSurface = Color(0xFFFFFFFF)
val ArmyForest = Color(0xFF1E4627)
val ArmyTextLight = Color(0xFF111713)

private val DarkScheme = darkColorScheme(
    primary = ArmyOlive,
    onPrimary = Color.White,
    secondary = ArmyOliveBright,
    background = ArmyBlack,
    surface = ArmySurfaceDark,
    onBackground = ArmyTextDark,
    onSurface = ArmyTextDark
)

private val LightScheme = lightColorScheme(
    primary = ArmyForest,
    onPrimary = Color.White,
    secondary = ArmyOlive,
    background = ArmyLightBg,
    surface = ArmyLightSurface,
    onBackground = ArmyTextLight,
    onSurface = ArmyTextLight
)

@Composable
fun ArmyConnectTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        content = content
    )
}
