package com.armyconnect.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class ArmyConnectApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_SERVICE,
                    "ARMY CONNECT Background Sync",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Keeps encrypted connection active with your ARMY CONNECT dashboard"
                }
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ALERT,
                    "Find My Device & Transfers",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Alerts for Find My Device alarms and incoming file transfers"
                }
            )
        }
    }

    companion object {
        const val CHANNEL_SERVICE = "army_connect_service"
        const val CHANNEL_ALERT = "army_connect_alert"
    }
}
