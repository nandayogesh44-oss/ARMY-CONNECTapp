package com.armyconnect.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.armyconnect.app.ArmyConnectApp
import com.armyconnect.app.MainActivity
import com.armyconnect.app.data.SecurePrefs
import com.armyconnect.app.features.DeviceDataProvider
import com.armyconnect.app.network.ArmyApiClient
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.io.File
import kotlin.math.min
import kotlin.math.pow

class ConnectForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var prefs: SecurePrefs
    private var webSocket: WebSocket? = null
    private var telemetryJob: Job? = null
    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null
    private var reconnectAttempt = 0
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile
    private var lastTransportTag: String? = null

    override fun onCreate() {
        super.onCreate()
        prefs = SecurePrefs(this)
        registerNetworkWatcher()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notif = buildNotification("Connected to ARMY CONNECT")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notif)
        }

        when (intent?.action) {
            ACTION_STOP -> {
                stopAlarm()
                reconnectJob?.cancel()
                webSocket?.close(1000, "User stopped service")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SYNC_ALL -> {
                scope.launch {
                    if (prefs.approved) syncAllAllowedData()
                }
                return START_STICKY
            }
            ACTION_STOP_RING -> {
                stopAlarm()
                return START_STICKY
            }
        }

        connectWebSocket()
        return START_STICKY
    }

    private fun registerNetworkWatcher() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        connectivityManager = cm
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val transport = resolveTransportTag(cm.getNetworkCapabilities(network))
                val changed = lastTransportTag != null && lastTransportTag != transport
                lastTransportTag = transport
                if (prefs.isPaired() && (!_connectionState.value || changed)) {
                    addEventLog("Internet active ($transport) — reconnecting relay")
                    forceReconnectNow()
                }
            }

            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                val transport = resolveTransportTag(caps)
                if (lastTransportTag != null && lastTransportTag != transport) {
                    lastTransportTag = transport
                    if (prefs.isPaired()) {
                        addEventLog("Switched network to $transport — refreshing connection")
                        forceReconnectNow()
                    }
                } else {
                    lastTransportTag = transport
                }
            }

            override fun onLost(network: Network) {
                _connectionState.value = false
                addEventLog("Network lost — waiting for internet connectivity")
                scheduleReconnect()
            }
        }
        networkCallback = cb
        runCatching { cm.registerNetworkCallback(req, cb) }
    }

    private fun resolveTransportTag(caps: NetworkCapabilities?): String = when {
        caps == null -> "Offline"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        else -> "Internet"
    }

    private fun forceReconnectNow() {
        reconnectJob?.cancel()
        reconnectAttempt = 0
        scope.launch {
            connectWebSocket()
        }
    }

    @Synchronized
    private fun connectWebSocket() {
        val token = prefs.deviceToken ?: return
        val base = prefs.serverUrl.trimEnd('/')
        val wsBase = base.replaceFirst("https://", "wss://").replaceFirst("http://", "ws://")
        val url = "$wsBase/ws?role=device&token=$token"

        reconnectJob?.cancel()
        webSocket?.cancel()
        val req = Request.Builder().url(url).build()
        webSocket = ArmyApiClient.http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                reconnectAttempt = 0
                _connectionState.value = true
                addEventLog("Encrypted WebSocket connected worldwide")
                startHeartbeatLoop()
                if (prefs.approved) {
                    startTelemetryLoop()
                    scope.launch {
                        syncAllAllowedData()
                        val ice = ArmyApiClient.fetchIceServers(prefs.serverUrl, token)
                        val hasTurn = ice.any { it["urls"]?.toString()?.startsWith("turn") == true }
                        addEventLog(
                            if (hasTurn) "NAT Traversal ready (STUN + TURN)"
                            else "NAT Traversal ready (Public STUN)"
                        )
                    }
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleIncomingMessage(text)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                _connectionState.value = false
                telemetryJob?.cancel()
                heartbeatJob?.cancel()
                addEventLog("Disconnected ($code): $reason")
                if (code != 4005 && code != 4002) {
                    scheduleReconnect()
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                _connectionState.value = false
                telemetryJob?.cancel()
                heartbeatJob?.cancel()
                addEventLog("Connection retry: ${t.message ?: "Network change"}")
                scheduleReconnect()
            }
        })
    }

    private fun scheduleReconnect() {
        if (!prefs.isPaired()) return
        if (reconnectJob?.isActive == true) return
        val delayMs = min(15_000L, (2_000.0 * 2.0.pow(reconnectAttempt.toDouble())).toLong())
        reconnectAttempt = min(reconnectAttempt + 1, 4)
        reconnectJob = scope.launch {
            delay(delayMs)
            if (isActive && !_connectionState.value && prefs.isPaired()) {
                connectWebSocket()
            }
        }
    }

    private fun startHeartbeatLoop() {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(20_000)
                if (_connectionState.value) {
                    sendWs(mapOf("type" to "ping"))
                }
            }
        }
    }

    private fun startTelemetryLoop() {
        telemetryJob?.cancel()
        telemetryJob = scope.launch {
            while (isActive) {
                if (prefs.approved) {
                    val telemetry = DeviceDataProvider.collectTelemetry(this@ConnectForegroundService)
                    sendWs(mapOf("type" to "device:telemetry", "payload" to telemetry))
                }
                delay(15_000)
            }
        }
    }

    private fun handleIncomingMessage(raw: String) {
        val mapType = object : TypeToken<Map<String, Any?>>() {}.type
        val msg: Map<String, Any?> = runCatching { ArmyApiClient.gson.fromJson<Map<String, Any?>>(raw, mapType) }.getOrNull() ?: return
        val type = msg["type"]?.toString() ?: return

        when (type) {
            "connected" -> {
                val serverApproved = msg["approved"] as? Boolean
                if (serverApproved != null) {
                    prefs.approved = serverApproved
                    _approvedState.value = serverApproved
                }
            }
            "device:approved" -> {
                prefs.approved = true
                _approvedState.value = true
                addEventLog("Device approved by dashboard")
                startTelemetryLoop()
                scope.launch { syncAllAllowedData() }
            }
            "device:force_disconnect" -> {
                prefs.clearPairing()
                _approvedState.value = false
                _connectionState.value = false
                reconnectJob?.cancel()
                addEventLog("Disconnected remotely by dashboard")
                stopSelf()
            }
            "clipboard:set" -> {
                if (!prefs.approved) return
                val content = msg["content"]?.toString().orEmpty()
                if (content.isNotEmpty()) {
                    CoroutineScope(Dispatchers.Main).launch {
                        DeviceDataProvider.setClipboard(this@ConnectForegroundService, content)
                    }
                    addEventLog("Clipboard received from PC")
                }
            }
            "command" -> {
                if (!prefs.approved) return
                val commandId = msg["commandId"]?.toString()
                val command = msg["command"]?.toString().orEmpty()
                @Suppress("UNCHECKED_CAST")
                val payload = msg["payload"] as? Map<String, Any?> ?: emptyMap()
                handleCommand(commandId, command, payload)
            }
        }
    }

    private fun handleCommand(commandId: String?, command: String, payload: Map<String, Any?>) {
        scope.launch {
            var ok = true
            var extraPongAt: Long? = null
            when (command) {
                "device:ping" -> {
                    extraPongAt = System.currentTimeMillis()
                }
                "ring:start" -> startAlarm()
                "ring:stop" -> stopAlarm()
                "location:request" -> {
                    val telemetry = DeviceDataProvider.collectTelemetry(this@ConnectForegroundService)
                    sendWs(mapOf("type" to "device:telemetry", "payload" to telemetry))
                    addEventLog("Location telemetry refreshed")
                }
                "files:list" -> {
                    val targetPath = payload["path"]?.toString()
                        ?: Environment.getExternalStorageDirectory().absolutePath
                    val entries = DeviceDataProvider.listStorageEntries(targetPath) +
                        DeviceDataProvider.queryMediaEntries(this@ConnectForegroundService)
                    val token = prefs.deviceToken
                    if (!token.isNullOrBlank()) {
                        ArmyApiClient.postJson(
                            prefs.serverUrl,
                            "/api/device/files/sync",
                            token,
                            mapOf("entries" to entries)
                        )
                    }
                    addEventLog("Synced ${entries.size} storage/media entries")
                }
                "files:pull" -> {
                    val filePath = payload["path"]?.toString().orEmpty()
                    val token = prefs.deviceToken
                    if (filePath.isNotEmpty() && !token.isNullOrBlank()) {
                        ok = ArmyApiClient.uploadFile(prefs.serverUrl, token, File(filePath))
                        addEventLog(if (ok) "Uploaded requested file" else "File pull failed")
                    } else {
                        ok = false
                    }
                }
                "sms:send" -> {
                    val address = payload["address"]?.toString().orEmpty()
                    val body = payload["body"]?.toString().orEmpty()
                    ok = DeviceDataProvider.sendSms(this@ConnectForegroundService, address, body)
                    addEventLog(if (ok) "Sent SMS to $address" else "SMS send permission missing")
                }
                else -> addEventLog("Received command: $command")
            }

            if (commandId != null) {
                val resPayload = buildMap<String, Any?> {
                    put("ok", ok)
                    if (extraPongAt != null) put("pongAt", extraPongAt)
                }
                sendWs(
                    mapOf(
                        "type" to "command:result",
                        "commandId" to commandId,
                        "payload" to resPayload
                    )
                )
            }
        }
    }

    private fun syncAllAllowedData() {
        if (!prefs.approved) return
        val token = prefs.deviceToken ?: return
        val server = prefs.serverUrl

        val media = DeviceDataProvider.queryMediaEntries(this)
        if (media.isNotEmpty()) {
            ArmyApiClient.postJson(server, "/api/device/files/sync", token, mapOf("entries" to media))
        }

        val contacts = DeviceDataProvider.queryContacts(this)
        if (contacts.isNotEmpty()) {
            ArmyApiClient.postJson(server, "/api/device/contacts/sync", token, mapOf("contacts" to contacts))
        }

        val sms = DeviceDataProvider.querySms(this)
        if (sms.isNotEmpty()) {
            ArmyApiClient.postJson(server, "/api/device/sms/sync", token, mapOf("messages" to sms))
        }

        val calls = DeviceDataProvider.queryCallLogs(this)
        if (calls.isNotEmpty()) {
            ArmyApiClient.postJson(server, "/api/device/calls/sync", token, mapOf("calls" to calls))
        }
        addEventLog("Synced media, contacts, SMS, and call history")
    }

    private fun startAlarm() {
        stopAlarm()
        addEventLog("Find My Device alarm triggered")
        runCatching {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                }
                play()
            }
        }
        runCatching {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            val pattern = longArrayOf(0, 500, 300, 500, 300)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            }
        }
    }

    private fun stopAlarm() {
        runCatching { ringtone?.stop() }
        ringtone = null
        runCatching { vibrator?.cancel() }
        vibrator = null
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, ArmyConnectApp.CHANNEL_SERVICE)
            .setContentTitle("ARMY CONNECT")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopAlarm()
        networkCallback?.let { cb ->
            runCatching { connectivityManager?.unregisterNetworkCallback(cb) }
        }
        reconnectJob?.cancel()
        heartbeatJob?.cancel()
        telemetryJob?.cancel()
        webSocket?.close(1000, "Service destroyed")
        scope.cancel()
        _connectionState.value = false
        if (instanceRef === this) instanceRef = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.armyconnect.app.START"
        const val ACTION_STOP = "com.armyconnect.app.STOP"
        const val ACTION_SYNC_ALL = "com.armyconnect.app.SYNC_ALL"
        const val ACTION_STOP_RING = "com.armyconnect.app.STOP_RING"

        private val _connectionState = MutableStateFlow(false)
        val connectionState = _connectionState.asStateFlow()

        private val _approvedState = MutableStateFlow(false)
        val approvedState = _approvedState.asStateFlow()

        private val _eventLogs = MutableStateFlow<List<String>>(emptyList())
        val eventLogs = _eventLogs.asStateFlow()

        @Volatile
        private var instanceRef: ConnectForegroundService? = null

        fun sendWs(payload: Map<String, Any?>) {
            val socket = instanceRef?.webSocket ?: return
            socket.send(ArmyApiClient.gson.toJson(payload))
        }

        fun addEventLog(entry: String) {
            val stamped = "${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())} · $entry"
            _eventLogs.value = (listOf(stamped) + _eventLogs.value).take(30)
        }
    }

    init {
        instanceRef = this
    }
}
