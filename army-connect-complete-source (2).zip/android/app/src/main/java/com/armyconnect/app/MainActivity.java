package com.armyconnect.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
